/*
 * IOexpender.h
 *
 */

#ifndef IOEXPENDER_H_
#define IOEXPENDER_H_

void CloseRelay1 (void);
void OpenRelay1 (void);
void CloseRelay2 (void);
void OpenRelay2 (void);

#endif /* IOEXPENDER_H_ */
