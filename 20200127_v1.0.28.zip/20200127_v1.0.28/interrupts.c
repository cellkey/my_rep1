#include "define.h"
#include <string.h>

BYTE NoRecDataU0Cnt;
BYTE NoDataRecCnt;
char TicksCount;
char cntr = 0;
char NumsCount[4];
char ListBuf1[17];
char ListBuf2[17];
char ListBufCount1;
char ListBufCount2;
unsigned int Keep_Alive_timer = 600;

BYTE bPORT = 0;

bit RING_PULSE_ACTIVE = FALSE;    //modem RING signal
bit  DIGITAL_IN_ACTIVE = FALSE;
bit  BOTTON_ACTIVE = FALSE;
bit UpdateSession = FALSE;
bit KeepAliveMsgNeeded = FALSE;

extern eeprom char eFLAGS_STSTUS;
extern eeprom int MIN_LIMIT[MAX_SEN_NUM];

extern BYTE NextByteIndex;
extern char readClockBuf[];             //buffer for data reading from clock
extern char ComBuf[MAX_TX_BUF_LEN];
extern char RxUart0Buf[MAX_RX_BUF_LEN];

extern BYTE BytesToSend;
extern unsigned int rx0_buff_len;

extern BYTE ModemResponse;
extern BYTE mainTask;
extern BYTE nInt1Fired;

extern  char Timer0_Ticks;
extern int time1_count;
extern BYTE modemCurTask;
extern BYTE modemCurSubTask;
extern int TimeLeftForWaiting;

extern bit Message_Recieved;
extern bit Modem_Message_Recieved;
extern bit longAnswerExpected;
extern bit overFlow;
extern int heat_time;
extern int ServerResponseTimeOut;
extern bit timer1_count_session;
extern bit bWaitForModemAnswer;
extern bit bNeedToWait4Answer;
extern   bit UnitWaked;
extern bit ConnectedToServer;
extern bit Found200;         //if server com ended OK
extern bit  ServerComOn;
extern bit ModemIsOn ;
extern bit PumpActivated;
extern bit BLE_connected;
extern   bit CONTINUOUS_RELAY; 
extern bit BUF1_FULL;
extern bit BUF2_FULL;
extern bit Buf1_Read;
extern bit Buf2_Read;
extern bit ListUpdateNeeded;

extern unsigned int nMaxWaitingTime;
extern unsigned int BLE_RX_count;

extern unsigned int cpuWakeTimeCnt;
extern char rx_buffer1[];

extern unsigned int rx_rd_index1,rx_counter1;    //rx_wr_index1,
extern char WakeTest;




// Timer 0 overflow interrupt service routine
interrupt [TIM0_OVF] void timer0_ovf_isr(void)
{
      
        NoRecDataU0Cnt++;
        if (NoRecDataU0Cnt > Timer0_Ticks)   //7
        {       
                if(rx0_buff_len > 5)              
                {
                    DISABLE_TIMER0();
                    RxUart0Buf[rx0_buff_len] = '\0';
                    bWaitForModemAnswer = FALSE;
                    Modem_Message_Recieved = TRUE;
                    longAnswerExpected = 0;
                    TCNT0 = 0x0;   //Timer Period: 35 ms - timer clok 7.2khz 
               }
               else
               {
                   rx0_buff_len = 0; 
                   TCNT0 = 0x0; 
               }  
        }

}


// TCNT1H=0x4C;
//TCNT1L=0x00;

interrupt [TIM1_OVF] void timer1_ovf_isr(void)
{
// Reinitialize Timer1 value
//    TCNT1H=0xFE98 >> 8;
//    TCNT1L=0xFE98 & 0xff;  
    
    TCNT1H=0xFD;    //0.1 sec at 7200 hz clock
    TCNT1L=0x1F;

    if(heat_time > 0)
    {
         heat_time--;
 //        cpuWakeTimeCnt++;
//         if (cpuWakeTimeCnt > 60000)
//         cpuWakeTimeCnt = 0;          
    } 
	if(Keep_Alive_timer > 0)
	{
		Keep_Alive_timer--;
		if(Keep_Alive_timer == 0) 
        {
	     	KeepAliveMsgNeeded = TRUE;        
        }
	}
    if(timer1_count_session == TRUE)
    {
       if(time1_count > 0)
       time1_count--;                  
    }  

    if ((bWaitForModemAnswer) && (TimeLeftForWaiting > 0))
    {
        TimeLeftForWaiting--; 
        

    }

//
//     if ((ConnectedToServer == TRUE) && (ServerResponseTimeOut > 0))
//    {
//         ServerResponseTimeOut--;
//    } 
    
     
 }
//// Timer1 output compare A interrupt service routine - EVERY 10 MiLi SECOND
//interrupt [TIM1_COMPA] void timer1_compa_isr(void)
//{
//   // BYTE i;
//    //reset next interupt
//    nextCompare += 0x0168;
//    OCR1AH = (unsigned char)(nextCompare >> 8  )& 0xFF;       // add high byte of 0x168 (0x1) to the high byte
//    OCR1AL = (unsigned char) (nextCompare) & 0xFF;            // add low byte of 0x168 (0x68) to the low byte
//
//    if(heat_time > 0)
//    {
//         heat_time--;
//         cpuWakeTimeCnt++;
//         if (cpuWakeTimeCnt > 60000)
//         cpuWakeTimeCnt = 0;
//    }
//
//    if ((bWaitForModemAnswer) && (TimeLeftForWaiting > 0))
//    {
//        TimeLeftForWaiting--;
//    }
//
//
//     if ((ConnectedToServer == TRUE) && (ServerResponseTimeOut > 0))
//    {
//         ServerResponseTimeOut--;
//    }  
//      if(RING_PULSE_ACTIVE )
//       {
//           LED1_ON;  
//          RING_PULSE_ACTIVE = FALSE;
//       }      
//       else
//       {
//            LED1_OFF; 
//             RING_PULSE_ACTIVE = TRUE;
//       }           
// 
//}


// Timer2 overflow interrupt service routine
interrupt [TIM2_OVF] void timer2_ovf_isr(void)
{

        NoDataRecCnt++;
        if (NoDataRecCnt > TicksCount)       //35 mili sec period per tick- = 400 milisec quiet period
        {
                    
              Message_Recieved = TRUE;
              DISABLE_TIMER2();
              LED1_OFF;  
//              LED2_ON;  
           //   TURN_LED2_TOGGLE();
              rx_buffer1[rx_counter1] = '\0';
        }  
                      
}
 //LASU - modem uart
// USART1 Receiver interrupt service routine
//interrupt [USART0_RXC] void usart0_rx_isr(void)
//{
//    BYTE LastRxByte;
//    char status;
//    status = UCSR0A;
//    LastRxByte = UDR0;       //read uart data register
//////===============================
//   _putchar1(LastRxByte);      //debug inputs
//////==============================
//
//
//    if ((status & (FRAMING_ERROR | PARITY_ERROR | DATA_OVERRUN))==0)
//    {
//        //when getting answer for post what we need is end of data-not the begining so when reach to MAX_TX_BUF_LEN - start rewrite on the buffer from the begining.
//        // the rx0_buff_len represent last index data got into it.
//
////        if(ServerComOn == TRUE)
////        {
////              if(LastRxByte == ']')   //look for patern like [2] as start of update file
////              {
////                        UpdateSession = TRUE;
////                         rx0_buff_len = 0;
////                          Modem_Message_Recieved = FALSE;
////              }
//
////            else
////             if(LastRxByte == '{')   //look for 200{
////             {
////
////                if   (RxUart0Buf[rx0_buff_len - 3] == '2')
////                {
////
////                      RxUart0Buf[0] = '2';
////                      RxUart0Buf[1] = '0';
////                      RxUart0Buf[2] = '0';
////                       RxUart0Buf[3] = '{';
////                      rx0_buff_len = 4;
////                      longAnswerExpected = FALSE;
////                      Found200 = TRUE;
////
////                }
////
////             }
////              else  RxUart0Buf[rx0_buff_len++] = LastRxByte;
////        }
////        else 
//         RxUart0Buf[rx0_buff_len++] = LastRxByte;
//
////        if (longAnswerExpected)
////        {
////            if(rx0_buff_len >= MAX_RX0_BUF_LEN)
////            {
////                overFlow = 1;
////                rx0_buff_len = 0;
////                #asm("wdr")
////            }
////        }
//
//       //  UDR1 = LastRxByte;  //monitor
//         ENABLE_TIMER0();
//    }
//    NoRecDataU0Cnt = 0;
//
//
//}

// USART0 Receiver interrupt service routine - addapted for FOTA
interrupt [USART0_RXC] void usart0_rx_isr(void)
{
    BYTE LastRxByte;
    char status;
    status = UCSR0A;
    LastRxByte = UDR0;       //read uart data register

    if ((status & (FRAMING_ERROR | PARITY_ERROR | DATA_OVERRUN))==0)
    {
        //when getting answer for post what we need is end of data-not the begining so when reach to MAX_TX_BUF_LEN - start rewrite on the buffer from the begining.
        // the rx0_buff_len represent last index data got into it.

        if(UpdateSession == TRUE)
        {
			
               if( LastRxByte == ':')
			   {
                   cntr++;         //: counter 
				  
			   }

               if(!BUF1_FULL)  //filling RxUart0Buf
               {
                   if( cntr == 2)  //got second : - complete current row 
                   {
                           BUF1_FULL = TRUE;    //buffer full - can be written to memory
                           Buf1_Read = FALSE;   //buf1 not written yet
                           BUF2_FULL = FALSE;   //make buf2 avail for next row
                        
						   ListBufCount2 = 0;   //start the second buf now
                           cntr = 1;   //counting ':'. 
							// LED1_ON;
                   }
                   else 
				   {
					     if(LastRxByte != ':')
					     ListBuf1[ListBufCount1++] =  LastRxByte;
						// UDR1 = LastRxByte; 
				   }
              }

              else if(!BUF2_FULL)  //500 ticks
             {
                   if( cntr == 2)
                   {
                           BUF2_FULL = TRUE;
                           Buf2_Read = FALSE;
                           BUF1_FULL = FALSE;
                           ListBufCount1 = 0;    //ok here..
                           cntr = 1;
                   }
                   else  
				   {
					    if(LastRxByte != ':')
					    ListBuf2[ListBufCount2++] =  LastRxByte;
				   }
             }
        }
        else if(ServerComOn == TRUE)                 
        {       
                if(LastRxByte == '{')   //look for 200{
             {
                    if (RxUart0Buf[rx0_buff_len - 3] == '2')
                    {
                              RxUart0Buf[0] = '2';
                              RxUart0Buf[1] = '0';
                              RxUart0Buf[2] = '0';
                              rx0_buff_len = 3;
                              longAnswerExpected = FALSE;
                              Found200 = TRUE;
                    }

             } 
             else
              if((LastRxByte == '0') && ( RxUart0Buf[rx0_buff_len - 3] == ' ') && (RxUart0Buf[rx0_buff_len - 4] == '1' )) //look for got HTTP 1.1 200 or 400 ? 500?
              {
                 
                         if( RxUart0Buf[rx0_buff_len - 2]== '2')                         
                           Found200 = TRUE;
//                          else 
//                           Server_Error_msg = TRUE;
                  
              }
               
               if((LastRxByte == 'N') && ( RxUart0Buf[rx0_buff_len - 1] == 'E') && (RxUart0Buf[rx0_buff_len - 2] == 'O' )) //look for OPEN
               {
	               
	            
	               Found200 = TRUE;//???????????????
	             	               
               }
            
                                                   
                  //look for pattern   <ABCD>[1]
				  
			  else if(ListUpdateNeeded == TRUE)   //start receiving file from server
			  {
                   if(LastRxByte == ']')   //look for patern like [2] as start of update file
                   {
                        if   (RxUart0Buf[rx0_buff_len - 2] == '[')   //pattern   <ABCD>[1]  <rosCount>[1]
                        {
                        
                               UpdateSession = TRUE; 
                            
                             //  RxUart0Buf[0] = '[';
                             //  RxUart0Buf[1] = RxUart0Buf[rx0_buff_len-1];  //get file type: 1,2,3                                                             
                            
                               NumsCount[0] = RxUart0Buf[rx0_buff_len-7]; //char 1   save number of rows (numbers) received in file header
                               NumsCount[1] = RxUart0Buf[rx0_buff_len-6]; //char 2
                               NumsCount[2] = RxUart0Buf[rx0_buff_len-5]; //char 3
                               NumsCount[3] = RxUart0Buf[rx0_buff_len-4]; //char 4
                               UDR1 = LastRxByte;  //show on monitor
                             //  rx0_buff_len = 2;  //
							   rx0_buff_len = 0;  //                              
                               cntr = 0;
                          
                         
                        }
                   }
				   
			  }
              else if(LastRxByte == 'C')    //look for NO CARRIER msg
              {
//                  if( RxUart0Buf[rx0_buff_len - 2] == 'O' )
//                  got_NO_CARRIER = TRUE;
              }
               
            //   if(rx0_buff_len < MAX_RX0_BUF_LEN)  //dont allow over flow           
              RxUart0Buf[rx0_buff_len++] = LastRxByte;
              
        }
        else RxUart0Buf[rx0_buff_len++] = LastRxByte;   //collect regular RX data

        if(UpdateSession == FALSE)  //dont show when update file received
         {
            UDR1 = LastRxByte;   //show on monitor

         }   

         ENABLE_TIMER0();
    }
    NoRecDataU0Cnt = 0;

}

//BLE module
// USART1 Receiver interrupt service routine
interrupt [USART1_RXC] void usart1_rx_isr(void)
{
    char status,data;


    status = UCSR1A;
    data = UDR1; 
    
        if ((status & (FRAMING_ERROR | PARITY_ERROR | DATA_OVERRUN)) == 0)
        {     
                            
                 if (rx_counter1 < RX_BUFFER_SIZE1)  //300 - not over flow!!!!!!!!
                 rx_buffer1[rx_counter1++] = data;                  
             
                 if(CONTINUOUS_RELAY) BLE_RX_count++;                                                                                      
        }  
       NoDataRecCnt = 0;
       ENABLE_TIMER2();  
      //  LED1_ON; 
}


// External Interrupt 0 service routine for wind speed
interrupt [EXT_INT0] void ext_int0_isr(void)
{
   
}

// External Interrupt 1 service routine // water meter
interrupt [EXT_INT1] void ext_int1_isr(void)
{
    nInt1Fired = TRUE;
   // PRR &= 0x00;
}

// External Interrupt 2 service routine  // clock int
interrupt [EXT_INT2] void ext_int2_isr(void)
{          
       
            DISABLE_CLOCK_INT();          
            DISABLE_PA2_INT();                 
            WakeTest = 2;     
            mainTask = TASK_WAKEUP;
}

// Pin change 0-7 interrupt service routine
//porta.2 = RING pulse
interrupt [PC_INT0] void pin_change_isr0(void)
{
         bPORT  = PINA;   //save port status for inspection
    
      //  PCMSK0 = 0;
     //   DISABLE_PA2_INT();
    //    DISABLE_CLOCK_INT(); 
           
      //   LED1_ON; 
      //   delay_ms(30);
   
        if((bPORT & 0x04) == 0)    ////RING low pulse  
        {

               RING_PULSE_ACTIVE = TRUE;           
               DISABLE_PA2_INT();
               DISABLE_PA0_INT();  
               
                ENABLE_RX_INT_UART0();  //allow rx from modem
               
            //   timer1_count_session = TRUE;   //check timing
            //   time1_count = 100;
              
        }   
  
        
  
        
       LED1_OFF;       
}


// Pin change 8-15 interrupt service routine
//portb.6 = magnetic SW
interrupt [PC_INT1] void pin_change_isr1(void)
{
   //  char port;

       bPORT  = PINB;      //save port status

    //   DISABLE_PB6_INT();
   //    DISABLE_PA6_INT();
   //    DISABLE_PC6_INT();
       DISABLE_CLOCK_INT();


        if(bPORT & 0x40)     //Magnetic SW or Cover SW activated by user
       {
        
           mainTask = TASK_WAKEUP;

           WakeTest = 8;


        }

}   

interrupt [PC_INT2] void pin_change_isr2(void)
{
     //   DISABLE_PC2_INT();
         delay_ms(30);
         bPORT  = PINC; 
          if((bPORT & 0x04) == 0)
          {
                 BOTTON_ACTIVE = TRUE;
            //   LED2_ON; 
            //    TURN_LED2_TOGGLE();
          }  
     
}

void TransmitBuf(char iPortNum)
{

    BYTE num = BytesToSend;     //global var  
    char data;

	NextByteIndex = 0;	// reset for Tx    
    
//    if (iPortNum == 0)
//    while (bWaitForModemAnswer == TRUE); //wait until rx0 end  
    
	if (iPortNum == 0)
    {
        while(BytesToSend-- )
        {   
            data = ComBuf[ NextByteIndex++ ];
            // wait for UART's shift register to finish sending byte
		    while(( UCSR0A & DATA_REGISTER_EMPTY)==0);
            UDR0 = data;//
          //  UDR1 = data;  //monitor????
        }
        rx0_buff_len = 0;
     

        if(ConnectedToServer == TRUE)      //ver 54
        {
             ServerResponseTimeOut = 120;
           //  #asm ("wdr");
        }

    }
    if ((iPortNum == 1) || (iPortNum == 0))
    {

        BytesToSend = num;
        NextByteIndex = 0;	// reset for Tx

        while(BytesToSend-- )
        {
            while ((UCSR1A & DATA_REGISTER_EMPTY)==0);
            UDR1 = ComBuf[ NextByteIndex++];// send next byte..

        }
      
        rx_counter1 = 0;

    }

	NextByteIndex = 0;//prepare for Rx
  //  ModemResponse = NO_ANSWER;

    if (iPortNum == 0)
    {
	    TimeLeftForWaiting = nMaxWaitingTime;    //TimeLeftForWaiting decremented in comp int timer 1
        NoRecDataU0Cnt = 0;
        ModemResponse = NO_ANSWER;

        if (bNeedToWait4Answer == TRUE)
        {
              bWaitForModemAnswer = TRUE; 
              Modem_Message_Recieved = FALSE;
        }
        else
            bWaitForModemAnswer = FALSE;

    }

  

}
