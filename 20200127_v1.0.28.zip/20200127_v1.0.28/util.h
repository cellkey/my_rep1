/*
 * util.h
 *
 *  Created on: Feb 23, 2013
 *      Author: boaz
 */

#ifndef UTIL_H_
#define UTIL_H_
#include <stdint.h>

void GetEncryptedData(unsigned int data,  char * encrypted);
unsigned long GetRandom(void);
uint8_t bin2bcd (uint8_t bin);
uint8_t bcd2bin (uint8_t bcd);

#endif /* UTIL_H_ */
