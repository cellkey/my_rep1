//#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "define.h"
#include "uart.h"

void  ReadAndSaveComboSensor(void);
int Read_485_Sensor(char SensAddress);

int iLastMsr[MAX_SEN_NUM];
char SensorDataType[MAX_SEN_NUM] = {0, 0, 0, 0, 0, 0, 0, 0}; //holding data type: 0 = value as is, 1 = 4-20  mA, 2 = digital

char SDI_Combo_index;
char SensorAtAlertStatus;
int DataAtAlertStatus;
char SensorBackToNormalAlertNeeded;

bit SDI_EC_MEASURED = FALSE;
bit SDI_PH_MEASURED = FALSE;
bit SDI_TMP_MEASURED = FALSE;
bit BackToNormalAlertEnabled = FALSE;
bit BackToNormalAlertNeeded = FALSE;
bit QuickSensorsCheckNeeded = FALSE;
bit IsAlertNeeded=0;
bit IsAlertActivated ;
bit PumpActivationNeeded;
bit WLV_OVF = FALSE;
bit SDI_Data_Saved ;
bit NotStable =FALSE;
//bit SENS4_20 = FALSE;

extern  int time0_count;
extern char readClockBuf[];
extern void rtc_get_timeAll(char *clockBuf);
extern void MUX_SDI12_00(void);
extern bit PumpActivated;
extern bit bDemoMode;
extern BYTE mainTask;
extern BYTE bMonitorConnected;
extern int SDI_TEMP_DATA;
extern unsigned int SDI_EC_DATA;
extern unsigned int SDI_PH_DATA;
extern int SDI_ORP_DATA;
extern int SDI_SM_DATA;
extern  bit BackToNormalAlertActivated;
extern bit timer0_session;
#pragma keep+
eeprom unsigned int logger_id  @0x28;
eeprom unsigned int logger_id = 7;

eeprom unsigned char NumSensors @0x18;
eeprom unsigned char NumSensors = 1;     //IF MONITOR NEEDED FOR SENSORS INSERTING PUT 0 AS VALUE

eeprom signed char ADCMux[MAX_SEN_NUM ] @0x10;
eeprom signed char ADCMux[MAX_SEN_NUM ] = { -1, -1, -1, -1, -1, -1, -1, -1};

eeprom BYTE PortIndex[MAX_SEN_NUM ]  @0x08;
eeprom BYTE PortIndex[MAX_SEN_NUM ]  = {1, 2, 3, 4, 0, 0, 0, 0};

eeprom BYTE SensorType[MAX_SEN_NUM ] @0x00;
eeprom BYTE SensorType[MAX_SEN_NUM ]= {0, 0, 0, 0, 0, 0, 0, 0};

eeprom BYTE IOType[MAX_IO_TYPES] @0x19;
eeprom BYTE IOType[MAX_IO_TYPES]= {1, 2, 3, 5, 4, 6, 7};  //1-EC, 2-TEMP, 3-PH, 5-WL

eeprom char unique_id[ MAX_SEN_NUM ] @0x20 ;
eeprom char unique_id[ MAX_SEN_NUM ] = {1,2,3,4, 5,6,7,8}; //sensors id



eeprom int MIN_LIMIT[MAX_SEN_NUM] @0x30;
eeprom int MIN_LIMIT[MAX_SEN_NUM] = {MIN_INT, MIN_INT, MIN_INT, MIN_INT, MIN_INT, MIN_INT, MIN_INT, MIN_INT};
eeprom int MAX_LIMIT[MAX_SEN_NUM] @0x40;
eeprom int MAX_LIMIT[MAX_SEN_NUM] = {MAX_INT, MAX_INT,MAX_INT,MAX_INT, MAX_INT, MAX_INT, MAX_INT, MAX_INT};
eeprom int PUMP_MIN_LIMIT[MAX_SEN_NUM] @0x50;
eeprom int PUMP_MIN_LIMIT[MAX_SEN_NUM] = {MIN_INT, MIN_INT,MIN_INT, MIN_INT, MIN_INT, MIN_INT, MIN_INT, MIN_INT};
eeprom int PUMP_MAX_LIMIT[MAX_SEN_NUM] @0x60;
eeprom int PUMP_MAX_LIMIT[MAX_SEN_NUM] = {MAX_INT, MAX_INT, MAX_INT, MAX_INT, MAX_INT, MAX_INT, MAX_INT, MAX_INT};
//eeprom float C1 = 0.00000000297;
//eeprom float C2 = 0.00000737;
//eeprom float C3 = 0.00669;
//eeprom float C4 = 1.92;
eeprom int HS_offset_value @0x70; //use this value for offset calibration (in 10 mili_grams, 500 = 5Kg)
//eeprom int HS_offset_value = 0; //use this value for offset calibration (in 10 mili_grams, 500 = 5Kg)
eeprom int HS_cal_value @0x72; //use this value as a gain multiplier (100 = 1.00)

//eeprom int HS_cal_value = 100; //use this value as a gain multiplier (100 = 1.00)

eeprom char ePUMP_HEAT_TIME @0x2E;
eeprom char ePUMP_HEAT_TIME = 90;
//char PUMP_HEAT_TIME;
//eeprom int eOption3;
//eeprom int eOption4;
eeprom char eBackToNormalAlertEnabled @0x0112;
eeprom char eBackToNormalAlertEnabled = TRUE;
eeprom char eRelay1Enabled  @0x0113;
eeprom char eRelay1Enabled = TRUE;
eeprom char eRelay2Enabled  @0x0114;
eeprom char eRelay2Enabled = TRUE;
eeprom char eTimeZone  @0x0115;
eeprom char eTimeZone = 12;   //Summer
extern eeprom char eFLAGS_STSTUS;
extern eeprom  unsigned int eECTresholdVal;
#pragma keep-
extern char FlagsStatus;


extern  void PCmessage( char *message );
//extern void LED2_OFF(void);
//extern void LED2_ON(void);
extern void CloseRelay2 (void);
//extern void OpenRelay2 (void);
extern void twiInit (void);
//extern unsigned char GetStatusReg(unsigned char mask);
extern void SetStatusReg(unsigned char mask, unsigned char val);
extern void  SetTimer1_10ms(void);


//BYTE pinB0 = 0;
extern bit bEndOfMeasureTask;
extern bit bExtReset;
extern bit Relay1Enabled;
extern bit Relay2Enabled;
//extern char  flagsStatus;
extern BYTE msrCurTask;
extern BYTE objToMsr;
extern BYTE msrAlertFlag;
extern BYTE OutOfLmtCnt[MAX_SEN_NUM];
extern BYTE OutOfLmtCntPump[MAX_SEN_NUM];
extern BYTE AlertStatus[MAX_SEN_NUM];
extern int heat_time;
extern int SensorResult;       //save the measuring result into variable
extern int measure_time;
extern int iVoltage;
extern unsigned int time_in_minutes;     //time from day start in ninutes
extern unsigned int nextCompare;
extern unsigned int wndSpdPulseCnt;
//extern unsigned int wtrPulseCnt;
extern unsigned int cpuWakeTimeCnt;
extern char  QuickMsrCount;

#ifdef DebugMode
extern char ComBuf[MAX_TX_BUF_LEN];
#endif DebugMode





void SensorPowerOn()
{
//    if (SensorType[objToMsr] == EC)     //danny
//        return;

//    #ifdef DebugMode
//    SendDebugMsg("\r\nPowerOn port");
//    PrintNum(PortIndex[objToMsr]);
//    #endif DebugMode
    if(objToMsr == PUMP)
    return;

    switch (PortIndex[objToMsr])    //PortIdex eeprom address 0x47
    {
        case 1:
            PORTB.1 = 1;   //open voltage switch for sensor 4-20mA at 1
        break; 
        
        case 2:
            PORTD.5 = 1;   //power sensor 2
        break;
//        case 3:
//            PORTD.7 = 1;
//        break;
//        case 4:
//            PORTB.1 = 1;
//        break;
//        case 5:
//             PORTA.7 = 1;
//            break;

        default:

                #ifdef DebugMode
                SendDebugMsg("\r\nCheck EEPROM -Port Index Not Valid");
                PrintNum(PortIndex[objToMsr]);
                 SendDebugMsg("\r\nobjTomsr = \0");
                 PrintNum((long)objToMsr);
                #endif DebugMode
                  mainTask = TASK_SLEEP;

             break;
    }

}

void SensorPowerOff()
{
    switch (PortIndex[objToMsr])
    {
        case 1:
           PORTB.1 = 0; 
        break;
//        case 2:
//            PORTD.6 = 0;
//        break;
//        case 3:
//            PORTD.7 = 0;
//        break;
//        case 4:
//            PORTB.1 = 0;
//        break;
//
//        case 5:
//             PORTA.7 = 0;
//            break;

        default:
        break;
    }
  //   VOLTAGE_MULTIPLIER_OFF();
}

void InitAdc(void)
{


    //  analog inputs init
    if( objToMsr < 6)      //no pump
    {
       PRR_EN_ADC();           // allow adc in PRR
       ENABLE_ADC();
        switch (PortIndex[objToMsr])
        {
            case 1:
                DDRA.0 = 0;
                PORTA.0 = 0;
            break;
//            case 2:
//
//                DDRA.1 = 0;
//                PORTA.1 = 0;
//            break;
//            case 3:
//                DDRA.2 = 0;
//                PORTA.2 = 0;
//            break;
//            case 4:
//                DDRA.3 = 0;
//                PORTA.3 = 0;       //Danny
//            break;

//            case 5:
//                DDRA.4 = 0;
//                PORTA.4 = 0;       //Danny
//                break;
//            case 6:
    //            wndSpdPulseCnt = 0; //reset wind speed pulse counter
    //            cpuWakeTimeCnt = 0;  //resettime counter
           break;

            default:
        }


        switch (PortIndex[objToMsr])
        {
            case 1:
//                DDRB.1 = 1;     // analog 1 power
//                PORTB.1 = 0;
            break;
//            case 2:
//                DDRD.6 = 1;     // analog 2 power
//                PORTD.6 = 0;
//            break;
//            case 3:
//                DDRD.7 = 1;     // analog 3 power
//                PORTD.7 = 0;
//            break;
//            case 4:
//                DDRB.1 = 1;     // analog 4 power
//                PORTB.1 = 0;
//            break;
//
//            case 6:
//            case 7:
//
//            break;

            default:
        }
  }
}
//values are in 1/10 sec
void SetSensorHeatTime()
{
    switch (SensorType[objToMsr])
    {    
         case FAKE_SENS:
              heat_time = 0 ;
         break; 
         
        case AT:
        case ST5:
            heat_time = 10 ;
        break;

        case AH:
            heat_time = 100;
        break;


        case PH:     //3      PH kando
               heat_time = 120;
        break;
        case WLV:     //5      Level kando
           heat_time = 80;    //15 sec for kando  090316
        break;
        case WLV_PULSTAR:
             heat_time = 30;  //1 sec
        break;
 case MICRO_FLOW:
               heat_time = 40;
        break;

        
        case  WL_NIVELCO:
               heat_time = 200;  //20 sec 
        break;  
          case  SM_4_20:         //Elchanani
               heat_time = 30;
        break;
case PURE_4_20: 
              heat_time = 0;

        break;

         case EC_K0:        //4   EC-5-C-2 kando
         case EC_K:        // 7   EC-5-C-1
              heat_time = 100;
         break;

        case TNS:
        case LT:
            heat_time = 30;
        break;

        case TIR:

             heat_time = 5;
        break;

        case HS10:

               heat_time = 20; //30    Danny for 4-20  sens check
        break;

        case GS1:
             heat_time = 30;
        break;

           case H2S:      //37
             heat_time = 250;  //1 sec
        break;

      
        case COMBO_5TE:        //sdi sensor 5TE
              heat_time = 30;  //2 sec
         break;

        default:
            heat_time = 0;
    }

}

int AnalyzeSensorRealValue(int AtoDSensResult)
{
  //  float TempResult, TempResult1, TempResult2, TempResult3;
    int sr;
 //   unsigned int mVolt_differance;
  //  unsigned long percentValue;

//    #ifdef DebugMode
//    SendDebugMsg("\r\nRaw data= ");
//    PrintNum((long)AtoDSensResult);
//    #endif DebugMode

    switch (SensorType[objToMsr])
    {

//
//        case AT:
//        case ST5:
//        case AT_B:
//
//             if(SensorType[objToMsr] == AT_B)
//             AtoDSensResult/=10;     //Danny - for boaz's sensor
//
//            //if first measuring failed - try again
//            if ((AtoDSensResult > 700) || (AtoDSensResult < -200) || (AtoDSensResult == -5))
//            {
//               AtoDSensResult = w1_SensRead(); //read out temp. again
//            }
//            if ((AtoDSensResult >700) || (AtoDSensResult <-200) || (AtoDSensResult == -5))
//            {
//                sr = 0;
//            }
//            else
//                sr = AtoDSensResult;
//        break;

        // 4-20mA sensors
        case  EC_K0:
        case  EC_K:
        case PH:  //kando PH-  4-20mA
        case WLV:    //kando water level-  4-20mA
        case MICRO_FLOW:  
        case WLV_PULSTAR:
        case H2S:

               sr =  AtoDSensResult;
                if( sr <= 400)
                sr = 400;       //fixed 030816

                 SensorDataType[objToMsr] = 1; //mark as 4-20mA

       case  SM_4_20:
 case PURE_4_20:     
                 sr =  AtoDSensResult;
                 if( sr < 400)
                 sr = 400;
        break;

          case  WL_NIVELCO:
                      sr =  AtoDSensResult;
                      if( sr < 50)
                      sr = 50;
                 SensorDataType[objToMsr] = 1; //mark as 4-20mA
        break;  
        
        case FAKE_SENS: 
               sr = AtoDSensResult;
        break;

         // Kandu's SDI  sensors
         case EC_SDI12:
         case TMP_SDI12:
         case PH_SDI12:

                      sr = AtoDSensResult;  // temp mult by 10. server ve to divide by 10
//                    #ifdef DebugMode
//                    SendDebugMsg("\r\nAnalyze SDI Sensor val  ");
//                    PrintNum(sr);
//                      #endif DebugMode

         break;

//
 //---------------------------New by Danny--------------------
        case HS10:
        case TNS:
        case GS1:
        case DW_LE:  //kando water existance 319117
        case MATIC:     //Kando float sensor

                 sr =  AtoDSensResult;
         break;
  //----------------------------------------------------------
         case AH: //Air Humidity
//            //calculate sensor real value
//            AtoDSensResult = (AtoDSensResult - 400) / 15;
//            sr = AtoDSensResult;
//            if (objToMsr > 0)
//                //check min/max value (temp > 50 or < 0) using the temp. sensor results
//                if((iLastMsr[objToMsr - 1] > 0) && (iLastMsr[objToMsr-1] < 500))//if 1w read ok
//                {
//                    //calculate measuring according to out temp.
//                    airTmp = iLastMsr[objToMsr-1] / 10;
//                    //calculate the const value
//                    percentValue = ((long)airTmp * 44) / 10;
//                    percentValue = (10305 + percentValue) / 100;
//                    //aprocsimated formula
//                    sr =  (((long)AtoDSensResult * 100) / percentValue);
//                }
//            //check min & max values
//            if (sr < 0)
//                sr = 0;
//            if (sr > 100)
//                sr = 100;
             sr = AtoDSensResult * 2;    //Danny 010116 Calc %H on server = (data-825)/3
       break;



      case TIR:  // radiation
            //if it is out of range, send to eeprom the low or high table value.
            if(AtoDSensResult < 0)
            {
                sr = 0;
                break;
            }
           else if(AtoDSensResult > 1260)
            {
                sr = 1260;
                break;
            }

            // measuring is in range
//            mVolt_differance = (((unsigned int)AtoDSensResult) * 10);
//            mVolt_differance = mVolt_differance / 33;
//            sr = (mVolt_differance * 10);

              sr = AtoDSensResult;      // calc on server
        break;

       }

//    PrintNum(sr);
//    #endif DebugMode
    return sr;
}

BYTE GetSensorType()
{
   return SensorType[objToMsr];

}

BYTE GetSensorIOType()
{

     return IOType[objToMsr];       //changed 261015 - new eeprom and data block order
}




BYTE SendAlerts()
{
    int i, res = FALSE;


    for (i = SENSOR1; i < NumSensors; i++)
    {
//             if (AlertStatus[i] == ALERT_BACK_NORMAL)
//             res = TRUE;

            if (AlertStatus[i] == TRHRESHOLD_CROSSED)
  //          if (OutOfLmtCnt[i] >= 2)
            {
                res = TRUE;
             //   OutOfLmtCnt[i] = 0;
            }
            else
            {
                AlertStatus[i] = ALERT_WAIT;
//                #ifdef DebugMode
//                SendDebugMsg("\r\nAlert Wait.\r\n\0 ");      //demo
//                #endif DebugMode
             }
    }

    if(PumpActivationNeeded == TRUE)          //demo
    res = TRUE;

    return res;
}

//void CheckMeasurmentsLimits_()
//{
//    int i = 0;
//    int count = 0;// counter to check if alert is over
//    char ZeroCount = 0;
//    // if during external reset - do not check limits
////    if (bExtReset == TRUE)
////        return;
//
//
//    for (i = SENSOR1; i < NumSensors; i++)
//    {
//        switch (AlertStatus[i])
//        {
//            case ALERT_WAIT:
//
//                if (((iLastMsr[i] < MIN_LIMIT[i]) || (iLastMsr[i] > MAX_LIMIT[i])) && (iLastMsr[i] > 0))
//                {
//                     OutOfLmtCnt[i]++;
//                     msrAlertFlag = 1;
//                      #ifdef DebugMode
//                     if(iLastMsr[i] > MIN_LIMIT[i])
//                     {
//                          SendDebugMsg("\r\nMMX_LIMIT ");
//                          PrintNum(MAX_LIMIT[i]);
//                     }
//                     else
//                     {
//                           SendDebugMsg("\r\nMIN_LIMIT ");
//                           PrintNum(MIN_LIMIT[i]);
//                     }
//
//                       SendDebugMsg("\r\niLast data= ");
//                      PrintNum(iLastMsr[i]);
//                      SendDebugMsg("\r\nOut Of Lmt Cnt ");
//                      PrintNum(i);
//                      PrintNum(OutOfLmtCnt[i]);
//                      #endif DebugMode
//
//                     if(OutOfLmtCnt[i]== pALERT_DELAY +1)
//                     {
//                          AlertStatus[i] = TRHRESHOLD_CROSSED; // check for pumping
//                          IsAlertNeeded = TRUE;  //check flag at  IsTimeToConnectGPRS() general.c
//                        //  WaitNextHour = FALSE;
//                        SensorAtAlertStatus = i;            //300715
//                     }
//
//                    if ((iLastMsr[i] < PUMP_MIN_LIMIT[i]) || (iLastMsr[i] > PUMP_MAX_LIMIT[i]))
//                    {
//                            OutOfLmtCntPump[i]++;
//
//                            if(OutOfLmtCntPump[i] > pALERT_DELAY)
//                           {
//                                 if(PumpActivated == FALSE)
//                                 {
//                                     if(Relay2Enabled == TRUE)
//                                    {
//                                          PumpActivationNeeded = TRUE;      //demo
//                                          #ifdef DebugMode
//                                          SendDebugMsg("PumpActivationNeeded = TRUE-1\r\n\0 ");
//                                          #endif DebugMode
//                                    }
//                                  }
//                           }
//                    }
//                }
//                else if((OutOfLmtCnt[i] > 0) && (iLastMsr[i] > 0))
//                {
//                   OutOfLmtCnt[i]--;
//                   if (i == SensorAtAlertStatus)
//                   SensorBackToNormalAlertNeeded = i;      //sensor that alerted before
//                 }
//
//            break;
//
//            case TRHRESHOLD_CROSSED:
//
//                if ((iLastMsr[i] < MIN_LIMIT[i]) || (iLastMsr[i] > MAX_LIMIT[i])) //if over TH check Pump TH
//                {
//
//                        if ((iLastMsr[i] < PUMP_MIN_LIMIT[i]) || (iLastMsr[i] > PUMP_MAX_LIMIT[i]))
//                        {
//                            if(Relay2Enabled == TRUE)
//                            {
//                                if ( PumpActivated == FALSE)
//                                {
//                                      PumpActivationNeeded = TRUE;      //demo
//                                        #ifdef DebugMode
//                                        SendDebugMsg("PumpActivationNeeded = TRUE-2\r\n\0 ");
//                                       #endif DebugMode
//                                 }
//                            }
//                        }
//                 }
//                 else
//                 {
//                        OutOfLmtCnt[i]--;            //value not over TH now-back to normal
//                    //    msrAlertFlag = 0;
//                    //    AlertStatus[i] =  ALERT_WAIT; //boaz?
//                 }
//            break;
//        }
//    }  //for i
//
//     for (i = SENSOR1; i < NumSensors; i++)
//     {
//            if(OutOfLmtCnt[i] == 0)
//            {
//               count++;
//               OutOfLmtCntPump[i] = 0;
//               AlertStatus[i] =  ALERT_WAIT;
//             }
//
//     }
//
//    if(count == NumSensors)   //no more bad results
//    {
//
//             msrAlertFlag = 0;
//             SendDebugMsg("\r\nNo Treshold passed..\r\n\0 ");
//
//             if(BackToNormalAlertEnabled == TRUE)      //300715
//             if(IsAlertActivated == TRUE)
//             BackToNormalAlertNeeded = TRUE;
//
//         //    IsAlertActivated = FALSE;   //M1
//
//    }
//
//}

void CheckMeasurmentsLimits()
{
    int i = 0;
    int count = 0;// counter to check if alert is over
    char ExceptionFound = 0 ;
    char Str[70];



    for (i = SENSOR1; i < NumSensors; i++)
    {
        switch (AlertStatus[i])
        {
            case ALERT_WAIT:

              if((SensorDataType[i]!= 1) ||(( SensorDataType[i] == 1) && (iLastMsr[i] > 400  )))  //WL 400 not exception
              {
             //   SENS4_20 = FALSE ;
                if (((iLastMsr[i] < MIN_LIMIT[i]) || (iLastMsr[i] > MAX_LIMIT[i])) && (iLastMsr[i] > 0))
                {
                     if( OutOfLmtCnt[i] < 3)
                     OutOfLmtCnt[i]++;
                     msrAlertFlag = 1;

                     if((OutOfLmtCnt[i] < 3) && (ExceptionFound == 0))
                     {
                         ExceptionFound = 1;
                         QuickSensorsCheckNeeded = TRUE;
                     }


                      #ifdef DebugMode
                     if(iLastMsr[i] > MIN_LIMIT[i])
                     {
                           SendDebugMsg("\r\nMAX_LIMIT ");
                            PrintNum(MAX_LIMIT[i]);
                     }
                     else
                     {
                            SendDebugMsg("\r\nMIN_LIMIT ");
                            PrintNum(MIN_LIMIT[i]);

                     }
                             SendDebugMsg("\r\niLast data= ");
                             PrintNum(iLastMsr[i]);

                      SendDebugMsg("\r\nOver Treshold Count- Sen ");
                      PrintNum((long)i+1);
                      PrintNum(OutOfLmtCnt[i]);
                      #endif DebugMode


                        if ((iLastMsr[i] < PUMP_MIN_LIMIT[i]) || (iLastMsr[i] > PUMP_MAX_LIMIT[i]))
                       {

                            SendDebugMsg("Pump Exception measured ..\r\n\0 ");
                            OutOfLmtCntPump[i]++;

                            if(OutOfLmtCnt[i] > OutOfLmtCntPump[i])  //if second measure has pump vlue start counting again
                            OutOfLmtCnt[i] = OutOfLmtCntPump[i];

                            if(OutOfLmtCntPump[i] > pALERT_DELAY)
                           {

                                  QuickSensorsCheckNeeded = FALSE;

                                  if(((SensorType[i]) == WLV) || (SensorType[i] == WLV_PULSTAR))
                                  {
                                      if(WLV_OVF == FALSE)
                                       {
                                            WLV_OVF = TRUE;   //flag for alert it  WLV_OVF_FLAG
                                            FlagsStatus =  eFLAGS_STSTUS;
                                            SetStatusReg( WLV_OVF_FLAG  , WLV_OVF_FLAG  );
                                            eFLAGS_STSTUS = FlagsStatus;
                                             SendDebugMsg("WL over flow measured ..\r\n\0");
                                        }

                                  }
                                   else  if(Relay2Enabled == TRUE)
                                   {
                                             if(PumpActivated == FALSE)
                                             {
                                                if ((eECTresholdVal == 0) || ((iLastMsr[0]> eECTresholdVal) && (eECTresholdVal > 0))) //EC value larger than Tresh
                                                {
                                                    PumpActivationNeeded = TRUE;      //demo
                                              //     FlagsStatus |= (1 << PUMP_ACTIVATION_NEEDED);
                                                  FlagsStatus =  eFLAGS_STSTUS;
                                                   SetStatusReg( PUMP_ACTIVATION_NEEDED , PUMP_ACTIVATION_NEEDED );
                                                  eFLAGS_STSTUS = FlagsStatus;
                                                  #ifdef DebugMode
                                                  SendDebugMsg("Pump Activation Needed ..\r\n\0 ");
                                                  #endif DebugMode
                                             }
                                         }
                                     }
                              }


                   }

                     if(OutOfLmtCnt[i]== pALERT_DELAY +1)
                     {
                           OutOfLmtCntPump[i] = 0;    //rest pump counter if go to alert
                           QuickSensorsCheckNeeded = FALSE;
                           AlertStatus[i] = TRHRESHOLD_CROSSED;
                           if(IsAlertActivated == FALSE)
                           {
                               IsAlertNeeded = TRUE;  //check flag at  IsTimeToConnectGPRS() general.c

                               FlagsStatus =  eFLAGS_STSTUS;
                               SetStatusReg( IS_ALERT_NEEDED ,IS_ALERT_NEEDED);
                               eFLAGS_STSTUS = FlagsStatus;
                           }
                           SensorAtAlertStatus = i;            // sensor with exception 300715
                           DataAtAlertStatus = iLastMsr[i];       //data

                     }


                }
                //normal data - handle it
                else if(OutOfLmtCnt[i] > 0)
                {

                      OutOfLmtCnt[i]--;

                      #ifdef DebugMode
                    //   SendDebugMsg("\r\nSensor Is Back-To-Normal after 1 or 2 exceptions..\r\n\0 ");
                      sprintf(Str, "Sensor %d Is Back-To-Normal after 1 or 2 exceptions..\r\n\0", i + 1 );
                      UART_WriteMsg(Str);
                      #endif DebugMode

                      if (i == SensorAtAlertStatus)
                      SensorBackToNormalAlertNeeded = i;      //sensor that alerted before  ??????
                 }
              }
             break;

              case TRHRESHOLD_CROSSED:
                      #ifdef DebugMode
                       SendDebugMsg("\r\nPost Alert State..\r\n\0 ");
                      #endif DebugMode
                 if((SensorDataType[i]!= 1) ||(( SensorDataType[i] == 1) && (iLastMsr[i] > 400  ))) //WL 400 not exception  //WL 400 not exception
              {
                //   SENS4_20 = FALSE ;
                  if ((iLastMsr[i] < MIN_LIMIT[i]) || (iLastMsr[i] > MAX_LIMIT[i])) //if over TH check Pump TH
                  {
                         if(OutOfLmtCnt[i] < 3)
                         OutOfLmtCnt[i]++;
                         QuickSensorsCheckNeeded = FALSE;    //post alert - no quick measure any more

                         if ((iLastMsr[i] < PUMP_MIN_LIMIT[i]) || (iLastMsr[i] > PUMP_MAX_LIMIT[i]))
                        {
                               if(OutOfLmtCntPump[i] < ( pALERT_DELAY + 1))//alert made but mot for bottol
                               {

                                     msrAlertFlag = 1;

                                     if(PumpActivated == FALSE)
                                     {
                                             QuickSensorsCheckNeeded = TRUE;

                                             QuickMsrCount = 0;
                                             OutOfLmtCntPump[i]++;
                                             SendDebugMsg("\r\n Pump Treshold crossed- Sen ");
                                             PrintNum((long)i+1);
                                             PrintNum(OutOfLmtCntPump[i]);
                                      }

                               }
                               else  //3 measures done
                               {

                                      QuickSensorsCheckNeeded = FALSE;

                                      if(((SensorType[i]) == WLV) || (SensorType[i] == WLV_PULSTAR))
                                     {
                                           if(WLV_OVF == FALSE)
                                           {
                                                WLV_OVF = TRUE;   //flag for alert it  WLV_OVF_FLAG
                                                FlagsStatus =  eFLAGS_STSTUS;
                                                 SetStatusReg( WLV_OVF_FLAG  , WLV_OVF_FLAG  );

                                                 IsAlertNeeded = TRUE;  //check flag at  IsTimeToConnectGPRS() general.c
                                                 SetStatusReg(IS_ALERT_NEEDED , IS_ALERT_NEEDED );
                                                 eFLAGS_STSTUS = FlagsStatus;
                                                  SendDebugMsg("WL over flow measured ..\r\n\0 ");
                                            }
                                       }

                                       else  if(Relay2Enabled == TRUE)   //pump allowed
                                       {
                                             if ((eECTresholdVal == 0) || ((iLastMsr[0] > eECTresholdVal) && (eECTresholdVal > 0))) //EC value larger than Tresh
                                             {
                                                   if(PumpActivated == FALSE)
                                                   {

                                                          PumpActivationNeeded = TRUE;      //demo
                                                          FlagsStatus =  eFLAGS_STSTUS;
                                                          SetStatusReg( PUMP_ACTIVATION_NEEDED , PUMP_ACTIVATION_NEEDED );
                                                          eFLAGS_STSTUS =  FlagsStatus;
                                                           SendDebugMsg("\r\n Post Alert - Pump needed..!\r\n\0");
                                                   }
                                             }
                                       }
                                        else
                                        {
                                                  IsAlertNeeded = TRUE;  //check flag at  IsTimeToConnectGPRS() general.c
                                                   FlagsStatus =  eFLAGS_STSTUS;
                                                   SetStatusReg(IS_ALERT_NEEDED , IS_ALERT_NEEDED );
                                                   eFLAGS_STSTUS = FlagsStatus;
                                                     SendDebugMsg("\r\n Post Alert - Pump  New alert needed..!\r\n\0");
                                        }
                                           SensorAtAlertStatus = i;            // sensor with exception 300715
                                           DataAtAlertStatus = iLastMsr[i];       //data

                                }
                           }

                 }
                 else   //post alert - no over treshold measured
                 {
                        if((OutOfLmtCnt[i] >= 3) || ( OutOfLmtCntPump[i] >= 3))
                        QuickMsrCount = 0;  //allow quick measure if data back to normal

                        OutOfLmtCnt[i]--;
                        OutOfLmtCntPump[i]--;

                        //value not over TH now- start back to normal
                        if(IsAlertActivated == TRUE)
                       {
                               if(QuickMsrCount < 3)
                               QuickSensorsCheckNeeded = TRUE;   //after alert, if data is normal check every minute 3 times
                              SendDebugMsg("\r\nSystem is in  Back-To-Normal Process..\r\n\0 ");
//                               sprintf(Str, "Sensor %d Is in Back-To-Normal Process..\r\n\0", i + 1 );
//                               UART_WriteMsg(Str);

                       }

                  }

                  }
               break;   // case TRHRESHOLD_CROSSED:
            }
    }  //for i

     for (i = SENSOR1; i < NumSensors; i++)
     {
            if(OutOfLmtCnt[i] == 0)
            {
               count++;
                OutOfLmtCntPump[i] = 0;
               AlertStatus[i] =  ALERT_WAIT;
            }
            SensorDataType[i] = 0;  //reset data types
     }

    if((count == NumSensors) &&  (IsAlertActivated == TRUE))    //050517 --  &&  (IsAlertActivated == TRUE)
     {
             msrAlertFlag = 0;

             SendDebugMsg("\r\nNo more Over_Treshold Measured..\r\n\0 ");

             QuickSensorsCheckNeeded = FALSE;
              QuickMsrCount = 0;
             if(BackToNormalAlertEnabled == TRUE)      //300715
             {
                     if(IsAlertActivated == TRUE)    //if after alert session
                     {
                          BackToNormalAlertActivated = FALSE;
                          BackToNormalAlertNeeded = TRUE;    //all sensors OK. alert it
                          if( WLV_OVF == TRUE)
                          {
                               WLV_OVF = FALSE;
                               FlagsStatus =  eFLAGS_STSTUS;
                               SetStatusReg(WLV_OVF_FLAG , 0);
                               eFLAGS_STSTUS =  FlagsStatus;
                          }

                          SendDebugMsg("\r\nActivate Back_To_Normal Alert ..\r\n\r\n\0 ");
                     }

             }
             else SendDebugMsg("\r\nBack_To_Normal Alert is Disabled..!\r\n\r\n\0 ");
          //   IsAlertActivated = FALSE;   //M1

    }

 }

//void CheckMeasurmentsLimits()
//{
//    int i = 0;
//    char buf[4];
//    int tmpData;
//
//     #ifdef DebugMode
//        SendDebugMsg("\r\nCheck limits.\r\n\0 ");      //demo
////     PrintNum(iLastMsr[i]);
//      #endif DebugMode
//
//    // if during external reset - do not check limits
////    if (bExtReset == TRUE)                          //Demo Ddanny
////        return;
//    for (i = SENSOR1; i < NumSensors; i++)
//
//        switch (AlertStatus[i])
//        {
//        tmpData =  iLastMsr[i];
//
//          #ifdef DebugMode
//                  SendDebugMsg("\r\nAlertStatus ");      //demo
//             //    PrintNum(i);
//                 PrintNum(tmpData);
//              #endif DebugMode
//
//             tmpData =  iLastMsr[i];
//            case ALERT_WAIT:
//                if ((tmpData < MIN_LIMIT[i]) || (tmpData > MAX_LIMIT[i]))
//                {
//
//                 #ifdef DebugMode
//                  SendDebugMsg("\r\nCross limits 1 ");      //demo
//                //  PrintNum(i);
////                  PrintNum(iLastMsr[i]);
//                 #endif DebugMode
//
//                    OutOfLmtCnt[i]++;
//                    AlertStatus[i] = TRHRESHOLD_CROSSED;
//                    msrAlertFlag = 1;
//                    PumpActivationNeeded = TRUE;               //demo
//                    #ifdef DebugMode
//                     if(i == 0) SendDebugMsg("\r\nSensor Temp- out of limit. Value= ");      //demo
//                     else if(i == 1)  SendDebugMsg("\r\nSensor PH- out of limit. Value=  ");
//                     else if(i == 2)  SendDebugMsg("\r\nSensor EC- out of limit. Value=  ");
//                     PrintNum(iLastMsr[i]);
//                    #endif DebugMode
//                }
//                  #ifdef DebugMode
//                  else
//                  SendDebugMsg("\r\nNo Limit crossed 1 ");      //demo
//             //    PrintNum(AlertStatus[i]);
//                #endif DebugMode
//
//            break;
//            case TRHRESHOLD_CROSSED:
//                if ((iLastMsr[i] < MIN_LIMIT[i]) || (iLastMsr[i] > MAX_LIMIT[i]))
//                {
//                    OutOfLmtCnt[i]++;
//                    msrAlertFlag++;
//                    PumpActivationNeeded = TRUE;
//
//                 #ifdef DebugMode
//                 SendDebugMsg("\r\nThreshold Cross  ");      //demo
//              // PrintNum(i);
//                 #endif DebugMode
//
////                    if(i < 3)                      //Danny - to be completed............
////                    {
////                         k = i * 11;                                          //demo
////                         cpu_e2_to_MemCopy( buf, &unique_id[k*4], 4);   //copy snsor id
////                         MemCopy_to_cpu_e2(buf, &Option_1[k*11],4);    //and write to eep recording buffer
////                         k+=4;
////                         MemCopy_to_cpu_e2(clockBuf, &Option_1[k*11],5);
////                         k += 5;
////                        add value
////                   }
//                 #ifdef DebugMode
//                     if(i == 0) SendDebugMsg("\r\nSensor Temp- out of limit. Value= ");      //demo
//                     else if(i == 1)  SendDebugMsg("\r\nSensor PH- out of limit. Value=  ");
//                     else if(i == 2)  SendDebugMsg("\r\nSensor EC- out of limit. Value=  ");
//                     PrintNum(iLastMsr[i]);
//                  #endif DebugMode
//                }
//                  #ifdef DebugMode
//                  else
//                  SendDebugMsg("\r\nNo Limit crossed 2 ");      //demo
//               //  PrintNum(AlertStatus[i]);
//                #endif DebugMode
//            break;
////            case ALERT_SHOT:
////                if ((iLastMsr[i] > MIN_STRIP[i]) || (iLastMsr[i] < MAX_STRIP[i]))
////                {
////                    AlertStatus[i] = ALERT_BACK_NORMAL;
////                     PumpActivationNeeded = FALSE;           //demo
////                }
////
////            break;
//        }
//}



void StartHeat()
{
//    #ifdef DebugMode
//    SendDebugMsg("\r\nStart heat ");    //Danny
//    PrintNum(objToMsr);
//   #endif DebugMode
//     V33_PWR_ON();   //enable 3.3V to entire board

    if (objToMsr == BATTERY)
    {
        //BATT_CHECK_POWER_ON(); //ToDo    Danny
//         #ifdef DebugMode
//        SendDebugMsg("\r\nActivate Battery test..\r\n\0 ");
//        #endif DebugMode

        BatLevel_ON();


    }
  
    else
    {
      
         delay_ms(2);
//         VOLTAGE_MULTIPLIER_ON();  //Creacell - voltage mult switch on- POWERING SENSORs
         if((SensorType[objToMsr] == WLV) || (SensorType[objToMsr] == WLV_PULSTAR))
         delay_ms(2000);        //LOAD CAP 241116
         else delay_ms(1000);
         SensorPowerOn();
     }

}

void InitAdcForBatt(void)
{
    // Analog Comparator initialization
    // PortA analog inputs init

      DDRA.1= 0;        
      PORTA.1 = 0;

}

void StartMeasure()
{
//    #ifdef DebugMode
//    SendDebugMsg("\r\nstart msr ");
//    PrintNum(objToMsr +1);
//    #endif DebugMode
   unsigned int hTime;


    heat_time = 0;
    PRR_EN_ADC();

    if (objToMsr == BATTERY)
    {
        heat_time = BATTERY_HEAT_TIME;    //1 sec of waiting
    }
    else  if (objToMsr == PUMP)
    {
         hTime = ePUMP_HEAT_TIME ;
          hTime *= 10;
          heat_time =  hTime;    // sec to 1/10 sec

          #ifdef DebugMode
          SendDebugMsg("Pump time: \r\n\0 ");
         PrintNum(heat_time / 10);
         #endif DebugMode
    }
    else  SetSensorHeatTime();

   //set timer int for 100 mili sec periods
     SetTimer1_10ms();
    if (objToMsr == BATTERY)
        InitAdcForBatt();

    else if ((objToMsr != PUMP) /*&& (SensorType[objToMsr])*/)    //if PUMP no need for adc
    {
        InitAdc(); //init the cpu a2d port

    }
       //read the rtc
   //   rtc_get_timeAll (readClockBuf);     //read it at wakeup proc
     //set the measuring timing (from day start) into measure_time variable
      measure_time = time_in_minutes;      //   time_in_minutes = Hour * 60 + minutes
      StartHeat();
      delay_ms(10);
}

void ReadSensor()
{
    int curSensResult = 0;
   unsigned int tResult = 0;
    int tResult1 = 0;
    int ok,i;   
     BYTE sensor_type; 
//   #ifdef DebugMode
//    SendDebugMsg("\r\nRead Sensor ");
//    PrintNum(objToMsr);
//   #endif DebugMode

     sensor_type = (BYTE)SensorType[objToMsr]; 
     if (objToMsr == PUMP)
     {
         SensorResult = 0;
         return;
     }
    if (objToMsr == BATTERY)
    {
      //  PORTC.2 = 1;
        SendDebugMsg("\r\nMeasure Battery..\r\n\0 ");        
        SensorResult = AnalogSensRead();
        return;
    }
    switch (SensorType[objToMsr])
    {
//        case SM:
//        case TMP:   //old sensors combination NO_MSR: danny
//             curSensResult = 0;
//        break;

//        case AT:
//        case ST5:
//        case AT_B:
//        #ifdef DebugMode
//          SendDebugMsg("\r\nMeasure Temp\r\n\0 ");
//         #endif DebugMode
//         curSensResult = w1_SensRead();
//        break;

        case AH:
        case TIR:
//        case LT:
        case HS10:
        case TNS:
        case GS1:
                 curSensResult = AnalogSensRead();   //Danny
        break;   
        
        case FAKE_SENS: 
               curSensResult = 250;
        break;

        case DW_LE:    //read PA.6. if high water exist
                   curSensResult = 0;
                  if(PINA.6 == 1)
                  {
                      delay_ms(100);
                      if(PINA.6 == 1)
                         curSensResult = 10;
                  }
                  if(curSensResult == 10)
                  SendDebugMsg("\r\nWater Exist Sensor: Water Flow..!\r\n\0 ");
                  else
                   SendDebugMsg("\r\nWater Exist Sensor: No Water..\r\n\0 ");

        break;

         case MATIC:     //Kando water exist floating sensor. if see 1 , sensor is floating
                   curSensResult = 0;

                    delay_ms(5);
                   if(PINA.1 == 1)
                   {
                      delay_ms(500);
                      if(PINA.1 == 1)
                         curSensResult = 10;
                   }
                  if(curSensResult == 10)
                  SendDebugMsg("\r\nWater Flows..!\r\n\0 ");
//                  else
//                   SendDebugMsg("\r\n No Water..\r\n\0 ");


         break;

         case EC_K0:     //Kando EC
         case PH:        //PH
         case EC_K:

                  curSensResult = AnalogSensRead();   //Danny
                  if  (curSensResult < 400)
                       curSensResult = 400;       //protect from too low val
          break;


           case  SM_4_20:
           case H2S:

                  curSensResult = AnalogSensRead();   //Danny
                  if  (curSensResult > 2000)
                  {
                       delay_ms(500);
                       curSensResult = AnalogSensRead();   //try again - sensor unstable
                  }
                  if  (curSensResult < 400)
                       curSensResult = 400;       //protect from too low val

             //    SENS4_20 = TRUE;
                 SensorDataType[objToMsr] = 1; //mark as 4-20mA
              break;
  case WLV:
     
     case WLV_PULSTAR:
     case MICRO_FLOW:
     case PURE_4_20:
  
                       i = 0;
                      time0_count = 200;   //1100mS  max for next do loop
                      timer0_session = TRUE;  //for timer2 operation
                      ENABLE_TIMER0();          //3600 Hrz clock
                     while  ((( tResult = AnalogSensRead()) < 360) && (time0_count > 0)); //wait for sensor react

//                     SendDebugMsg("\r\ntimer= \0 ");
//                     PrintNum((long)time0_count);

                  if (tResult >= 360)     //if ouput less than 300- abort
                  {
                          delay_ms(100);
                            curSensResult = AnalogSensRead();
                          time0_count = 200;
                      do
                        {
                             delay_ms(100);
                            tResult = AnalogSensRead();
                            tResult1 =  curSensResult - tResult;
                            if ((tResult1 < 5) && (tResult1 > -5))  //+-5 accuracy
                            i++;
                            else i = 0;
                            curSensResult = tResult;
                        }
                       while ((i < 3) && (time0_count > 0));


//                          SendDebugMsg("\r\ntimer= \0 ");
//                           PrintNum((long)time0_count);
                  }
                  else
                  {
                       if(sensor_type == WLV_PULSTAR)
                       SendDebugMsg("Measuring MASSA WL failed..\r\n\0");
                       else  if(sensor_type == WLV)
                       SendDebugMsg("Measuring WLV failed..\r\n\0");
                        else  if(sensor_type == MICRO_FLOW)
                       SendDebugMsg("Measuring MICRO_FLOW failed..\r\n\0");
                    
                       else   SendDebugMsg("Measuring PH failed..\r\n\0");
                  }

                    DISABLE_TIMER0();
                   timer0_session = FALSE;

                  if  (curSensResult < 400)
                       curSensResult = 400;       //protect from too low val
                  SensorDataType[objToMsr] = 1; //mark as 4-20mA
          break;

          case  WL_NIVELCO:

                       i = 0;
                      time0_count = 200;   //1100mS  max for next do loop
                      timer0_session = TRUE;  //for timer2 operation
                      ENABLE_TIMER0();          //3600 Hrz clock
                     while  ((( tResult = AnalogSensRead()) < 40) && (time0_count > 0)); //wait for sensor react

//                     SendDebugMsg("\r\ntimer= \0 ");
//                     PrintNum((long)time0_count);

                  if (tResult >= 40)     //if ouput less than 300- abort
                  {
                          delay_ms(100);
                            curSensResult = AnalogSensRead();
                          time0_count = 200;
                      do
                        {
                             delay_ms(100);
                            tResult = AnalogSensRead();
                            tResult1 =  curSensResult - tResult;
                            if ((tResult1 < 5) && (tResult1 > -5))  //+-5 accuracy
                            i++;
                            else i = 0;
                            curSensResult = tResult;
                        }
                       while ((i < 3) && (time0_count > 0));


//                          SendDebugMsg("\r\ntimer= \0 ");
//                           PrintNum((long)time0_count);
                  }
                  else
                  {                                             
                       SendDebugMsg("Measuring WLV_NIVELCO failed..\r\n\0");                    
                  }

                        DISABLE_TIMER0();
                        timer0_session = FALSE;

                       if  (curSensResult < 50)
                           curSensResult = 50;       //protect from too low val
                       SensorDataType[objToMsr] = 1; //mark as 4-20mA
          break;

//#ifdef RS485_ACTIVE

//          case COMBO4_485:
//
//                  SDI_Combo_index = objToMsr;   //not implemented yet -keep base index of combo sensors
//                  SDI_Data_Saved = FALSE;
//                 SDI_EC_MEASURED = FALSE ;
//                 SDI_PH_MEASURED = FALSE;
//                 i = 0;
//
//  SendDebugMsg("Measuring Ponsel MODBUS sensors..\r\n\0");
//                 SendDebugMsg("\r\nMeasure EC + TEMP\r\n\0");
//
//                 do{
//
//                          ok =  Read_485_Sensor(S485_EC_ADDRESS);  //param 1: address;  param 2: 1=temp, 2=EC
//                          if(ok)
//                          {
//
//                                        SendDebugMsg("\r\nRead EC + TEMP OK\r\n\0 ");
//                                        NotStable = FALSE;
//
//                                        SDI_EC_MEASURED = TRUE;
//                                        SDI_TMP_MEASURED = TRUE;
//
//                          }
//                          else
//                          {
//                                //  SendDebugMsg("\r\nRead EC Failure\r\n\0 ");
////                                   SDI_EC_DATA = (int)0x8000;    //error  0xFF01
////                                   SDI_TEMP_DATA = (int)0x8000;    //error  0xFF01
//                                   SDI_EC_MEASURED = FALSE;
//                                   delay_ms(700);
//                                    i++;
//                          }
//
//                      }
//                      while ((SDI_EC_MEASURED == FALSE) && (i < 2)); //allow 2 loops
//
//                       if(i == 2)
//                         {
//
//                                 SDI_EC_DATA = (int)0x8000;         //error  0xFF01
//                                 SDI_TEMP_DATA = (int)0x8000;    //error  0xFF01
////                               SendDebugMsg("\r\nRead EC- i=2\r\n\0 ");
//                         }
//
//                      //PH also
//
//                       i = 0;
//                        SendDebugMsg("\r\nMeasure PH + ORP\r\n\0");
//                       do{
//
//                               delay_ms(500);
//                               ok =  Read_485_Sensor(S485_PH_ADDRESS);  //read PH and ORP
//                              if(ok)
//                              {
//
//                                  if (SDI_PH_DATA < 0)      //semnsor sfault 9998
//                                  {
//                                       NotStable = TRUE;
//                                       SDI_PH_MEASURED = FALSE;    //try again
//                                       i++;
//                                       SendDebugMsg("\r\nPH data not stable..\r\n\0 ");
//                                       SDI_PH_MEASURED = FALSE;
//                                  }
//                                   else
//                                   {
//                                        SendDebugMsg("\r\nRead PH + ORP OK\r\n\0 ");
//                                        NotStable = FALSE;
//                                        SDI_PH_MEASURED = TRUE;
//                                    }
//                              }
//                              else
//                             {
////                                     SDI_PH_DATA = (int)0x8000;//-254;    //error  0xFF01
////                                     SDI_ORP_DATA =(int)0x8000;
//
//                                     delay_ms(700);
//                                     i++;
//                              }
//
//                         }
//                         while ((SDI_PH_MEASURED == FALSE)  && (i < 2)); //allow 2 loops
//
//                         if(i == 2)
//                         {
//
//                                //     SendDebugMsg("\r\nRead PH- i=2\r\n\0 ");
//                                     SDI_PH_DATA = (int)0x8000;//-254;    //error  0xFF01
//                                     SDI_ORP_DATA =(int)0x8000;
//
//                         }
//                         timer0_session = FALSE;
//
//                         return;
//          break;
//
//          case COMBO_EC_485:
//
//                    i = 0;
//                   SendDebugMsg("\r\nMeasure EC + TEMP (MODBUS)\r\n\0");
//
//                 do{
//
//                          ok =  Read_485_Sensor(S485_EC_ADDRESS);  //param 1: address;  param 2: 1=temp, 2=EC
//                          if(ok)
//                          {
////                                   if(SDI_EC_DATA == 1249 )      //semnsor sfault 9998/8
////                                   {
////                                       NotStable = TRUE;
////                                       SDI_EC_MEASURED = FALSE;    //try again
////                                       i++;
////                                       SendDebugMsg("EC data not stable..\r\n\0 ");
////                                   }
////                                   else
//                                   {
//                                            SendDebugMsg("\r\nRead EC + TEMP OK\r\n\0 ");
//                                            NotStable = FALSE;
//
//                                            SDI_EC_MEASURED = TRUE;
//                                            SDI_TMP_MEASURED = TRUE;
//                                   }
//                          }
//                          else
//                          {
//                                   SDI_EC_MEASURED = FALSE;
//                                   delay_ms(700);
//                                    i++;
//                          }
//
//                      }
//                      while ((SDI_EC_MEASURED == FALSE) && (i < 2)); //allow 2 loops
//
//                       if(i == 2)
//                         {
//
//                                 SDI_EC_DATA = (int)0x8000;         //error  0xFF01
//                                 SDI_TEMP_DATA = (int)0x8000;    //error  0xFF01
////                               SendDebugMsg("\r\nRead EC- i=2\r\n\0 ");
//                         }
//                         timer0_session = FALSE;
//                         return;
//          break;
//
//          case  COMBO_PH_485:
//                   i = 0;
//                        SendDebugMsg("\r\nMeasure PH + ORP  (MODBUS)\r\n\0 ");
//                       do{
//
//                               delay_ms(500);
//                               ok =  Read_485_Sensor(S485_PH_ADDRESS);  //read PH and ORP
//                              if(ok)
//                              {
//
//                                  if (SDI_PH_DATA < 0)      //semnsor sfault 9998
//                                  {
//                                       NotStable = TRUE;
//                                       SDI_PH_MEASURED = FALSE;    //try again
//                                       i++;
//                                       SendDebugMsg("\r\nPH data not stable..\r\n\0 ");
//                                  }
//                                   else
//                                   {
//                                        SendDebugMsg("\r\nRead PH + ORP OK\r\n\0 ");
//                                        NotStable = FALSE;
//                                        SDI_PH_MEASURED = TRUE;
//                                    }
//                              }
//                              else
//                             {
////                                     SDI_PH_DATA = (int)0x8000;//-254;    //error  0xFF01
////                                     SDI_ORP_DATA =(int)0x8000;
//
//                                     delay_ms(700);
//                                     i++;
//                              }
//
//                         }
//                         while ((SDI_PH_MEASURED == FALSE)  && (i < 2)); //allow 2 loops
//
//                         if(i == 2)
//                         {
//
//                                //     SendDebugMsg("\r\nRead PH- i=2\r\n\0 ");
//                                     SDI_PH_DATA = (int)0x8000;//-254;    //error  0xFF01
//                                     SDI_ORP_DATA =(int)0x8000;
//
//                         }
//                         timer0_session = FALSE;
//
//                         return;
//          break;
//
////#else  //RS485_ACTIVE
//
//
//       //--------SDI12 -----------------
//
//
//
//         case COMBO4_SDI12:     // 12  EC + TEMP +PH    (Ponsel..!)
//                 SDI_Combo_index = objToMsr;   //not implemented yet -keep base index of combo sensors
//                  SDI_Data_Saved = FALSE;
//                 SDI_EC_MEASURED = FALSE ;
//                 SDI_PH_MEASURED = FALSE;
//                 i = 0;
//
//                         #ifdef DebugMode
//                         SendDebugMsg("Measure EC + TEMP.\r\n\0 ");
//                        #endif DebugMode
//                 do{
//
//
//                          ok = SD12_Sensors_Read(SDI_EC_ADDRESS);  //param 1: address;  param 2: 1=temp, 2=EC
//                          if(ok)
//                          {
//
//                                 if(SDI_EC_DATA == 1249 )      //semnsor sfault 9998/8
//                                 {
//                                       NotStable = TRUE;
//                                       SDI_EC_MEASURED = FALSE;    //try again
//                                       i++;
//                                       SendDebugMsg("EC data not stable..\r\n\0 ");
//                                  }
//                                  else
//                                  {
//                                           #ifdef DebugMode
//                                           SendDebugMsg("\r\nRead EC + TEMP READ OK\r\n\0 ");
//                                           #endif DebugMode
//                                            NotStable = FALSE;
//
//                                            SDI_EC_MEASURED = TRUE;
//                                            SDI_TMP_MEASURED = TRUE;
//
//                                  }
//
//                          }
//                          else
//                          {
//                                //  SendDebugMsg("\r\nRead EC Failure\r\n\0 ");
//                                   SDI_EC_DATA = (int)0x8000;    //error  0xFF01
//                                   SDI_TEMP_DATA = (int)0x8000;    //error  0xFF01
//
//                                   delay_ms(700);
//                                    i++;
//                          }
//
//                      }
//                      while ((SDI_EC_MEASURED == FALSE) && (i < 2)); //allow 2 loops
//
//                       if(i == 2)
//                         {
//
//                                 SDI_EC_DATA = (int)0x8000;         //error  0xFF01
//                                 SDI_TEMP_DATA = (int)0x8000;    //error  0xFF01
////                               SendDebugMsg("\r\nRead EC- i=2\r\n\0 ");
//                         }
//
//                      //PH also
//
//                       i = 0;
//                        SendDebugMsg("\r\nMeasure PH + ORP\r\n\0 ");
//                       do{
//
//                               delay_ms(500);
//                               ok = SD12_Sensors_Read(SDI_PH_ADDRESS);  //read PH and ORP
//                              if(ok)
//                              {
//
//                                  if (SDI_PH_DATA < 0)      //semnsor sfault 9998
//                                  {
//                                       NotStable = TRUE;
//                                       SDI_PH_MEASURED = FALSE;    //try again
//                                       i++;
//                                       SendDebugMsg("\r\nPH data not stable..\r\n\0 ");
//                                  }
//                                   else
//                                   {
//                                        SendDebugMsg("\r\nRead PH + ORP OK\r\n\0 ");
//                                        NotStable = FALSE;
//                                       SDI_PH_MEASURED = TRUE;
//
//                                    }
//                              }
//                              else
//                              {
//                                     SDI_PH_DATA = (int)0x8000;//-254;    //error  0xFF01
//                                     SDI_ORP_DATA =(int)0x8000;
//
//                                     delay_ms(700);
//                                     i++;
//                              }
//
//                         }
//                         while ((SDI_PH_MEASURED == FALSE)  && (i < 2)); //allow 2 loops
//
//                         if(i == 2)
//                         {
//
//                                //     SendDebugMsg("\r\nRead PH- i=2\r\n\0 ");
//                                     SDI_PH_DATA = (int)0x8000;//-254;    //error  0xFF01
//                                     SDI_ORP_DATA =(int)0x8000;
//
//                         }
//                         timer0_session = FALSE;
//
//                         return;
//         break;
//
//          case COMBO2_EC_SDI12:   //11 EC + temp only
//
//                 SDI_Combo_index = objToMsr;   //not implemented yet -keep base index of combo sensors
//                  SDI_Data_Saved = FALSE;
//                 i = 0;
//                 do{
//
//                          #ifdef DebugMode
//                          SendDebugMsg("\r\nMeasure EC + TEMP (Ponsel)\r\n\0 ");
//                          #endif DebugMode
//                          ok = SD12_Sensors_Read(SDI_EC_ADDRESS);  //param 1: address;  param 2: 1=temp, 2=EC
//                          if(ok)
//                          {
//                                 SDI_EC_MEASURED = TRUE;
//                                 SDI_TMP_MEASURED = TRUE;
//                                 #ifdef DebugMode
//                                 SendDebugMsg("EC + TEMP OK\r\n\0 ");
//                                 #endif DebugMode
//                          }
//                          else
//                          {
//
//
//
//                                     SDI_EC_DATA = (int)0x8000;    //error  0xFF01
//                                     SDI_TEMP_DATA = (int)0x8000;    //error  0xFF01
//
//                               delay_ms(500);
//                               i++;
//                          }
//
//                      }while ((SDI_EC_MEASURED == FALSE) && (i < 2)); //allow 2 loops
//                       return;
//             break;
//
//           case  COMBO2_PH_SDI12:
//                  SDI_Combo_index = objToMsr;   //not implemented yet -keep base index of combo sensors
//                  SDI_Data_Saved = FALSE;
//                 i = 0;
//                 do{
//                            if( SDI_PH_MEASURED == FALSE)
//                            {
//                               ok = SD12_Sensors_Read(SDI_PH_ADDRESS);  //param 1: address;  param 2: 1=temp, 2=EC
//                              if(ok)
//                              {
//
//                                   SDI_PH_MEASURED = TRUE;
//                                   SDI_TMP_MEASURED = TRUE;
//                                   #ifdef DebugMode
//                                   SendDebugMsg("\r\nPH + TEMP OK\r\n\0 ");
//                                   #endif DebugMode
//                              }
//                              else
//                              {
//
//
//                                      SDI_PH_DATA = (int)0x8000;   //-254;    //error  0xFF01
//                                      SDI_TEMP_DATA = (int)0x8000;
//                                       SDI_ORP_DATA = (int)0x8000;
//
//
//                                  delay_ms(500);
//                                  i++;
//                              }
//                            }
//                         }while ((SDI_PH_MEASURED == FALSE) && (i < 2)); //allow 2 loops
//                          timer0_session = FALSE;
//                         return;
//
//           break;

//  #endif

           case  COMBO_5TE:
                       i = 0;
                       SDI_Data_Saved = FALSE;

                        #ifdef DebugMode
                        SendDebugMsg("\r\nMeasure 5TE COMBO\r\n\r\n\0 ");
                        #endif DebugMode
                       do{

                          ok = SD12_Sensors_Read(SDI_5TE_ADDRESS);  //param 1: address;  param 2: 1=temp, 2=EC
                          if(ok)
                          {
                                 SDI_EC_MEASURED = TRUE;
                                 SDI_TMP_MEASURED = TRUE;
                                 #ifdef DebugMode
                                 SendDebugMsg("\r\nMeasured EC + TEMP OK\r\n\0 ");
                                 #endif DebugMode
                          }
                          else
                          {
                               SET_SDI12_RX_DIRECTION();
                               delay_ms(1000);
                               i++;
                          }

                      }while ((SDI_EC_MEASURED == FALSE) && (i < 2)); //allow 2 loops

                      if(SDI_EC_MEASURED == FALSE)
                      {
                                #ifdef DebugMode
                                 SendDebugMsg("\r\nNo Response from Sensor!\r\n\0 ");
                                 #endif DebugMode
                               SDI_EC_DATA = (int)0x8000;    //error  0xFF01
                               SDI_TEMP_DATA = (int)0x8000;    //error  0xFF01
                      }
                      return;
        break ;


        default:
    }
    //calculate sensor real value

    SensorResult = AnalyzeSensorRealValue(curSensResult);
}

void EndHeat()
{
   // ADCSRA &= ~(1<<ADEN);

    if (objToMsr == BATTERY)
    {
       // BATT_CHECK_POWER_OFF(); //ToDo
//         #ifdef DebugMode
//        SendDebugMsg("\r\nShut Battery test..\r\n\0 ");
//        #endif DebugMode
        BatLevel_OFF();             //Danny
     }
  
    else
    {
     //   V33_PWR_OFF();              //creacell V3-
      //  VOLTAGE_MULTIPLIER_OFF();
        SensorPowerOff();             //shut sensor sw

    }
    DISABLE_ADC();
//    ENABLE_UART0();    //re-enable uart1 - for monitor.
}

BYTE GetNextMsrTask()
{
    switch (msrCurTask)
    {
        case TASK_NONE:
            msrCurTask = TASK_MSR_START_HEAT;
        break;

        case  TASK_MSR_START_HEAT:
            if (heat_time == 0)
            {
                msrCurTask = TASK_MSR_READ;
            }
            else
                return WAIT;
        break;

        case TASK_MSR_READ:
            msrCurTask = TASK_MSR_SAVE; //TASK_MSR_END_HEAT;

        break;

        case TASK_MSR_SAVE:

            msrCurTask = TASK_NONE;  //

            if (objToMsr == BATTERY)
                bEndOfMeasureTask = TRUE;

            else if (objToMsr == PUMP)
               //  mainTask = TASK_SLEEP;    //return to sleep mode
                bEndOfMeasureTask = TRUE;

            else
            {
                // go to next sensor
                objToMsr++;

                // if finished last sensor - declare end of task
                if (objToMsr >= NumSensors)
                {
                    CheckMeasurmentsLimits();     //check limits and if true
                    bEndOfMeasureTask = TRUE;
                }
                else
                {

                        SendDebugMsg("\r\nMeasuring Sensor:  ");
                        PrintNum((long)objToMsr + 1);
                         msrCurTask = TASK_NONE;
                         delay_ms(100);      // if continue to msr next prob - wait a while
                }


            }
        break;
        default:
    }
    return CONTINUE;
}

void MeasureMain()
{
    long l;

    if (GetNextMsrTask() == WAIT)
    {
        return;
    }
//    MUX_SDI12_00();
    switch (msrCurTask)
    {
        case  TASK_MSR_START_HEAT: 
            //    SendDebugMsg("StartMeasure() \r\n\0 ");
                StartMeasure();          //demo - including StartHeat() - put on pump
        break;

        case TASK_MSR_READ:
                              
            //   SENS4_20 = FALSE ;
                 ReadSensor();                
                 EndHeat();

        break;

        case TASK_MSR_SAVE:
            //disable interrupts

         

             if (objToMsr == PUMP)
             break;

            else if (objToMsr == BATTERY)
            {
               // iVoltage = SensorResult;  
                
                l = (long)SensorResult * 47;  //was 47
                iVoltage = l / 10;
                iVoltage += l % 10;

                SendDebugMsg("\r\nBATTERY= ");
                PrintNum(iVoltage); 
              
            }
            else
            {

                iLastMsr[objToMsr] = SensorResult;   
                
                #ifndef GEVIM_ALERT_UNIT
                   SaveMeasurments();   //no saving for Gevim alert system
                 #endif      
             //   
                #asm ("sei")
            }
        break;
        default:

    }
}
// read and save SDI COMBO3 combination of sensors EC, Temp, PH
void ReadAndSaveComboSensor(void)
{

    char   tmp_objToMsr;

             tmp_objToMsr = objToMsr;
             ReadSensor();   //read conbo- all 3 data available when done

            if((SensorType[tmp_objToMsr] == COMBO4_SDI12) || (SensorType[tmp_objToMsr] == COMBO2_EC_SDI12)\
            || (SensorType[tmp_objToMsr] == COMBO_5TE)|| (SensorType[tmp_objToMsr] == COMBO4_485)||(SensorType[tmp_objToMsr] == COMBO_EC_485) )
            {
                    iLastMsr[objToMsr] = SDI_EC_DATA;
                    SensorResult  = SDI_EC_DATA;
                    SaveMeasurments();
                    if( SDI_EC_DATA == 0x8000)
                    SendDebugMsg("saved EC DATA \r\n\0 ");
                    else
                     SendDebugMsg("saved EC DATA (divided by 8!)\r\n\0 ");


                    objToMsr++;    //point to temp data
                    SensorResult  = SDI_TEMP_DATA;
                    iLastMsr[objToMsr] = SDI_TEMP_DATA;
                    SaveMeasurments();

                    SendDebugMsg("saved TEMP DATA\r\n\0 ");


                     if(SensorType[tmp_objToMsr] == COMBO_5TE)
                     {
                            objToMsr++;    //SM data
                            iLastMsr[objToMsr] = SDI_SM_DATA;
                            SensorResult  = SDI_SM_DATA;
                            SaveMeasurments();
                             SendDebugMsg("saved SM DATA\r\n\0 ");
                     }

                    if((SensorType[tmp_objToMsr] == COMBO4_SDI12)|| (SensorType[tmp_objToMsr] == COMBO4_485)) //indluding PH

                    {
                            objToMsr++;    //go to PH as well
                             iLastMsr[objToMsr] = SDI_PH_DATA;
                            SensorResult  = SDI_PH_DATA;
                            SaveMeasurments();
                           #ifdef DebugMode
                            SendDebugMsg("saved PH DATA\r\n\0 ");
                            #endif DebugMode

                             objToMsr++;       //point to orp
                             SensorResult  = SDI_ORP_DATA;
                             iLastMsr[objToMsr] = SDI_ORP_DATA;
                             SaveMeasurments();
                            #ifdef DebugMode
                             SendDebugMsg("saved ORP DATA\r\n\0 ");
                            #endif DebugMode

                    }

             }
             else if((SensorType[tmp_objToMsr] == COMBO2_PH_SDI12)||(SensorType[tmp_objToMsr] == COMBO_PH_485)) //No EC, save Temp, PH , ORP only,
             {
//
                //   objToMsr++;
                   iLastMsr[objToMsr] = SDI_PH_DATA;
                   SensorResult  = SDI_PH_DATA;
                   SaveMeasurments();
                    SendDebugMsg("saved PH DATA\r\n\0 ");


                    objToMsr++;       //point to orp
                    SensorResult  = SDI_ORP_DATA;
                    iLastMsr[objToMsr] = SDI_ORP_DATA;
                    SaveMeasurments();
                     SendDebugMsg("saved ORP DATA\r\n\0 ");
//
             }
              SDI_Data_Saved = TRUE;
}

void InitCombDef()
{
    BYTE i;

    NumSensors = 0;
    for (i = 0; i < MAX_SEN_NUM; i++)
    {
        ADCMux[i] = -1;
        PortIndex[i] = 0;
        SensorType[i] = 0;
        MIN_LIMIT[i] = MIN_INT;
        MAX_LIMIT[i] = MAX_INT;
    }

    for (i = 0; i < MAX_IO_TYPES; i++)
        IOType[i]= 0;

//    useExtInt1 = FALSE;
    // todo - is needed?
//    for (int i = 0; i < MAX_SEN_NUM * 4; i++)
//        unique_id[i] = 0;   //sensors id
}

//BYTE SetSensorCombination(BYTE *newCmb)
//{
//    BYTE i, tmp = 0;
//    //NumSensors = 0;
//    //init all vars refer to combination definition
//    InitCombDef();
//
//    for (i = 0; i < MAX_IO_TYPES; i++)
//    {
//        if (newCmb[i] != 0)
//        {
//            PortIndex[tmp] = i+1;
//            if (newCmb[i] == EC)
//            {
//                if (tmp > 6)
//                    return FALSE;
//                ADCMux[tmp] = -1;
//                ADCMux[(int)tmp+1] = -1;
//                ADCMux[(int)tmp+2] = -1;
//                SensorType[tmp] = EC;
//                SensorType[(int)tmp+1] = SM;
//                SensorType[(int)tmp+2] = TMP;
//                tmp += 3;
//            }
//            else
//            {
//
//                    if (i < 6)
//                    ADCMux[tmp] = i;
//                    SensorType[tmp] = newCmb[i];
//                tmp += 1;
//            }
//        }
//    }
//
//    // if type definition is ok -
//    NumSensors = tmp;            //add num of sensors added
//    for (i = 0; i < MAX_IO_TYPES; i++)
//        IOType[i] = newCmb[i];
//
//    return TRUE;
//}

 void ResetPumpFlags(void)
{
       char i;

                PumpActivated = FALSE;
                PumpActivationNeeded = FALSE;
                IsAlertNeeded = FALSE;

                FlagsStatus =  eFLAGS_STSTUS;
                SetStatusReg( PUMP_ACTIVATION_NEEDED | IS_ALERT_NEEDED | PUMP_ACTIVAED | IS_ALERT_ACTIVATED | WLV_OVF_FLAG , 0);
                eFLAGS_STSTUS =  FlagsStatus;

                msrAlertFlag = 0;
                for (i = SENSOR1; i < NumSensors; i++)
                {
                     OutOfLmtCnt[i] = 0;
                     OutOfLmtCntPump[i] = 0;
                     AlertStatus[i] = ALERT_WAIT;
                }
                #ifdef DebugMode
                SendDebugMsg("\r\nPump Reset ..\r\n\0");
                #endif DebugMode

}


