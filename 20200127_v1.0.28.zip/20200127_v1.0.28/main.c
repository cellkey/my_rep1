/*******************************************************
This program was created by the
CodeWizardAVR V2.60 Standard
Automatic Program Generator
� Copyright 1998-2012 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Project : Crecell Logger
Version : 9.4.0.0
Date    : 27/01/2013
Author  : Dan G
Company : Creacell
Comments:


Chip type               : ATmega644P
Program type            : Application
AVR Core Clock frequency: 3.686400 MHz
Memory model            : Small
External RAM size       : 0
Data Stack size         : 512
*******************************************************/
#include <stdlib.h>
#include <stdio.h>
#include "define.h"
#include "vars.h"
#include "uart.h"
#include "util.h"
#include "sms.h"


//extern eeprom char unique_id[]; //sensors id

//------------Program version ------------------

// flash  char RomVersion[2] = {0x01,0};   //  92
 flash unsigned char fw_version[] = "1.0.28";

//------------------------------------------------



extern int twiWriteReg(const uint8_t addr, const uint8_t reg, const uint8_t data);

extern void RTC_RESET(void);
extern int twiReadExtMemN(char block,const unsigned int InternalAddr, char n, char *pdata);
extern void SendSModemString(unsigned char *bufToSend, BYTE bufLen);
extern void SetTimer1_100ms(void);

extern unsigned int SetRelayVars(char relay,char op);
extern void SetAlarmTiming1(unsigned int NewVal);
//extern void RTCPwrDwn (void);
extern unsigned char GetStatusReg(unsigned char mask);
extern void SetStatusReg(unsigned char mask, unsigned char val);
extern char RTC_Update_by_Modem(void);
extern void  BlueToothMain(void);
extern char Set_BLE_Name(void);
extern void CloseRelay1(void);
extern void OpenRelay1(void) ;
extern void OpenRelay2(void);
extern void CloseRelay2(void) ;
extern  void BLE_RESET(void);
extern unsigned int RxUpdateFile(void);
extern char Set_BLE_Name(void);


//extern void LED2_OFF(void);
extern char gYear;
//extern  char LoopsCount;
extern BYTE BLECurTask;
extern unsigned int Keep_Alive_timer;

extern bit ModemRepeatNeeded;
extern bit ConnectedToServer;

extern bit TWIerrON;
extern bit ModemIsOn ;
extern bit UnitWaked;
extern bit SearchServerDataBase;
extern bit Open_Session_On;
extern bit RING_PULSE_ACTIVE;
extern char encrypted_data[10]; ; 


extern char ModemRepeatCount;
extern int ServerResponseTimeOut;
extern char TicksCount;
extern char UNIT_TYPE;
//extern unsigned int UsersQuantity;

extern eeprom unsigned int eUsersQuant;
extern eeprom char eFLAGS_STSTUS;
extern eeprom unsigned int elogger_id;
extern eeprom Schedular_table op_timing[6]; 
extern eeprom Relay_table Relay_vars[2];
extern eeprom  char eUnit_Name[];

extern void SetModemPwrOff();

char Str3[30];
char Str2[7];

char UnitIDstring[17];
unsigned long rnd, *random;
char WakeTest = 0;
char AlarmTiming, i;
char WDactive = FALSE;
char UNIT_NAME[11];   //holds unit name for further usage
unsigned int Uid;
unsigned int Next_Wake_Min;

char QuickMsrCount;
char  FlagsStatus;

bit PumpActivated;

bit IsAlertNeeded;
bit IsAlertActivated;

//====================main==================================================
void main(void)
{
  //  char clockBuf[7];
    int check;
    char i,j; 
  
    char STR[25];
//    unsigned long rnd;     
 //bit PwrOnRst = FALSE;
    // Global enable interrupts
   

	#asm ("wdr"); 		//reset the watchdog timer
//    WATCHDOG_ENABLE(); 	//set the watchdog
    //~~~~~~~~~~~check the startup reason~~~~~~~~~~~~~
    //the MCUSR should be set to 0x00 at the PowerDownSleep() function

   Relay_vars[0].relay_indx = 1;
   Relay_vars[1].relay_indx = 2; 
          
    bExtReset = FALSE;
    bReset = FALSE;
    WDactive = FALSE;
   
    check = 0;
    // Reset Source checking
    if (MCUSR & (1<<PORF)) //poweron reset
    {
        //  bReset = TRUE;   //if power on reset put modem to work 
      //   PwrOnRst =TRUE; 
         check = 1;
    }
    else if (MCUSR & (1<<EXTRF))     //ext. res
   {

             ModemRepeatNeeded = FALSE;
              ModemRepeatCount = 0;
             bExtReset = TRUE;     //no need to power mmodem  
              check = 2;
   }
    else if (MCUSR & (1<<WDRF))      //WATCH DOG RESET
    {
             WDactive = TRUE;
              check = 3;
    }

	MCUSR = 0x00; //reset the reset source flags to 0
      
    InitProgram();

//    LED1_ON;      //led
 
//   LED1_OFF;;
//    V33_PWR_ON();
//    delay_ms(10);
   

//     SendDebugMsg("\r\nWait, System Is In RESET Process...\r\n\0");
    //------------------IO Exp------------------------------
    SendDebugMsg("reset cause code: \0");  
    PrintNum((long)check) ; 
   

 //----------------------------------------------------

//   OpenRelay1();
//    delay_ms(1000); 
//     CloseRelay1(); 
//   
//   delay_ms(1000);
//   OpenRelay2();
//  delay_ms(1000); 
//   CloseRelay2();  
//  
  CloseRelay1();
  CloseRelay2();  
  

      if(WDactive == TRUE)
      {
          SendDebugMsg("WD activated..!\r\n\0");
          WDactive = FALSE;
      } 
      if( bExtReset == TRUE )
       SendDebugMsg("Ext. reset activated..!\r\n\0");
      
    delay_ms(100);

  SendDebugMsg("-----------------------------\r\n\0");
   SendDebugMsg("\r\nEazyGate by Creacell..\r\n\0"); 
    i=0;  
     while((eUnit_Name[i] != '#')&&(i<10))
     UNIT_NAME[i] = eUnit_Name[i++];   //eeprom addres 0x01B0 
     UNIT_NAME[i] = '\0';
     
       sprintf(STR,"UNIT ID: %s\r\n\0",UNIT_NAME); //set string to write to ext eeprom); 
       UART1_WriteMsg(STR);  //debug     
     
              
   for(i = 0; i< 6; i++)
   Str2[i] = fw_version[i];
   Str2[6] = '\0';
 
   sprintf(Str3,"Firmware version: %s\n\r\0",Str2);
   UART1_WriteMsg(Str3); 


    SendDebugMsg("-----------------------------\r\n\0");
 
    
    QuickMsrCount = 0;
     
  //check arm status after reset
     Message_Recieved =  FALSE; 
     Modem_Message_Recieved = FALSE;  
 //---------------------------------------------------     
     i = 0; 
     j = 2;
     while(eUnit_Name[i] != '#')
     { 
       UnitIDstring[i++] = eUnit_Name[j++]; //load name without cr  
      
     } 
     UnitIDstring[i] = '\0'; 
     rnd = atol(UnitIDstring) ;  //convert the name string to long int
     random = &rnd;                  
     GetEncryptedData((unsigned long)random, encrypted_data);   //load   encrypted_data with expected application string-check in SMS.c 
     
     Set_BLE_Name();    //set unit type as well  
 //=====================================================    
    LED1_OFF;   
    TicksCount = 12;  
  
	 
//	 BLE_RESET_ON; 
//	check = RxUpdateFile();
//	if(check) 
//	  SendDebugMsg("\r\nMain() - List updated successfully..\r\n\0");
	 
	 
   
      if(UNIT_TYPE == MODEM_UNIT)
      {
           SearchServerDataBase = TRUE;  //test server controling the list
           Init_Modem_Vars(); 
            ModemRepeatCount = 0;
         //  BLE_RESET_ON;   
            SendDebugMsg("\r\nEazyGate - Modem unit..\r\n\0");  
           delay_ms(2000);   
       }    
      else 
      { 
         mainTask = TASK_BLUETOOTH;          
          BLECurTask = TASK_NONE; 
          BLE_RESET_OFF;   
          DISABLE_UART0();  //no modem-no need 
           Modem_Message_Recieved = FALSE; 
          DISABLE_PA2_INT();    //ring puls disabled
          SendDebugMsg("\r\nEazyGate - BLE unit..\r\n\0");  
      }    
  
 //  SendDebugMsg("\r\nEazyGate ready..\r\n\0");
        #asm("sei");  
 //------------------------  main loop     ----------------------------------------------------   
 
    while (1)      
    {
        switch (mainTask)
        {      
        
               case TASK_BLUETOOTH : 
                               
                  BlueToothMain();

               break;
          //-------------------------------------------------------------------------------       
                case TASK_MODEM:   
                                                                                                
                   ModemMain();                    

                 if( toDoList == DO_BLE ) 
                 {  
                    #asm("sei");
                    toDoList = DO_NONE;
                    mainTask = TASK_BLUETOOTH; 
                     if(Open_Session_On == TRUE)   //relay active- get into waiting loop for period expired
                     {
                         BLECurTask =  TASK_BLE_USER_MSG_OK; //close relay when heat time=0  
                       //  heat_time = 80;         //relay period - 8 sec
                     }    
                     else 
                        BLECurTask = TASK_NONE; 
                        
                        ENABLE_RX_INT_UART1();
                        SendDebugMsg("return to BLE..\r\n\0 ");                     
             
                         BLE_RESET_OFF; 
                         delay_ms(200);
                         Modem_Message_Recieved = FALSE;                 
                         RING_PULSE_ACTIVE = FALSE;  
                         ENABLE_PA2_INT();    //RING  ----------
//                         if(Keep_Alive_timer > KeepAlivePeriod)
                         Keep_Alive_timer = KeepAlivePeriod;
                 }   
                
                 
                break; //case TASK_MODEM
    //-------------------------------------------------------------------------------------
            case TASK_SLEEP:
                      
                   //    if(Arm_Pending == FALSE) //if true rtc count down timer is on
                       {                                                                
                            AlarmTiming = 60; //Otopus_interval;// MEASURE_INTERVAL*6;   //now 5 min                                       
                            SetAlarmTiming1(AlarmTiming);      //Danny added - test every minute  
                       } 
                    //    else SendDebugMsg("Wake by Countdown timer..\r\n\0 ");                     
                       PowerDownSleep();
                      
                break; //case TASK_SLEEP

            case TASK_WAKEUP:

//                WakeUpProcedure();
             break;

            default:
               mainTask = TASK_BLUETOOTH;
        }

      
        #asm ("wdr"); 		//reset the watchdog timer
    }
}
