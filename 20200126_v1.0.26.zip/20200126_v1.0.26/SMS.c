 //SMS.c   Check all procedures...!
 // Modified for Sony-Erricson protocol  
 
//#include <Mega324.h> 
#include <delay.h>
#include <string.h>
#include <bcd.h>
//#include "vars.h"

#include  "define.h"
#include  "sms.h"

#define USER_TYPE 15 //index of type location in buffer
#define USER_ADMIN 'A'   //put scii number
#define USER_USER  'U'
#define USERS_COUNT 10     //octapus
#define BLE_USERS_COUNT 100
#define NumBufLen   16
#define BLE_Num_Len 12    //9 digits of phone num
#define BLE_Mem_Buf_Len 32   //ext mem record lengh
#define EXT_MEM_LIST_BASE_ADDRESS 0  //list start at address 0
#define MEM_BANK0 0
#define MEM_BANK1 1
#define TIMING_DATA_OFFSET 13   //timing byte offset from start of user rcord in ext mem
#define BLE_USER_TYPE_OFFSET 12 
#define LOG_REC_COUNT 300
#define LOG_REC_LENGH 32
#define LOG_BASE_ADD  0xDA80   //end of bank 0
#define LOG_END_ADD   LOG_BASE_ADD+ LOG_REC_LENGH*LOG_REC_COUNT (0x10000)



 void SendMsgBySMS(unsigned char code);  
 unsigned char IsNumAllowed( char *Num,unsigned char Length );
 unsigned char ComparNums( char *Num1, eeprom  char *Num2,unsigned char Length);
 unsigned char CheckPassWord(void); 
 void SMSsend( char *phoneNum ,  char *message,  char *message1); 
 void  SetAdminPhoneNum (char *Num,  eeprom  char *Address, unsigned char DataLengh);
 void Clean_buf( char *buf, unsigned char lengh);
 void Monitor_message(flash  char *message ); 
  
char CallerIdBuf[14];
char AdminNumberBuf[14];
char provider[10];
char csq[3];
char SMSdataBuf[SMS_DATA_BUF_LEN];  //32
char CurrentNumber[17];
char CellNumLn = 13;
char key;
char PWindex;
unsigned int UsersQuantity;
unsigned int ExtMemUsersQuantity;

char Relays_Stat;
unsigned int BatLevel;
unsigned int ArmDelay;
unsigned int ExtMemReadAddress;
unsigned int ExtMemWriteAddress;

bit mPWactive = FALSE;
bit SentByAdmin;
bit  SuperUser = FALSE; 
bit Input_Active;
bit RelayEmergAct = FALSE; 
bit OPEN_SESSION = FALSE;
bit CLOSE_SESSION = FALSE;
bit CONTINUOUS_RELAY = FALSE; 

eeprom  char eUnit_Name[17]  @0x01B0;
eeprom  char eUnit_Name[17] = {'U','N','I','T','_','1','#','0','0','0','0','0','0','0','0','0','0'};
eeprom  char  emPassWord[6]   @0x01C2;                                                     
eeprom  char  emPassWord[6] = {'f','c','5','w','o','1'};           //master PW - for development
eeprom  char  euPassWord[6]   @0x01C9;
eeprom  char  euPassWord[6]   = {'1','2','3','4','5','6'};           //user PW storage location 
eeprom  char  euPassWord_old[6]  @0x01D0;
eeprom  char  euPassWord_old[6]  = {'1','2','3','4','5','6'};            // location for old Pw 
eeprom unsigned int  eUsersQuant    @0x01D7; 
eeprom unsigned int  eUsersQuant = 0;
eeprom unsigned int  eExtMemUsersQuant    @0x01D9; 
eeprom unsigned int  eExtMemUsersQuant = 0;
eeprom unsigned int  eLogIndex    @0x01DB;     //log current index make the address
eeprom unsigned int  eLogIndex;

eeprom Relay_table Relay_vars[2] @0x01E0;   //12 bytes struct
eeprom Relay_table Relay_vars[2] = {{1,255,0,0,0,0,0,0,0},{2,255,0,0,0,0,0,0,0}}; 

clock_params Cur_Time;   //date/time struct


eeprom relay_emergency Relay_Emerge[2] @0x240;
eeprom relay_emergency Relay_Emerge[2] = {{0x00,0x00},{0x00,0x00}};
eeprom Schedular_table op_timing[6]    @0x0200;  //10 bytes struct
eeprom Schedular_table op_timing[6] = {{0x01,0x7F,1,31,1,6,18,2,0,20},{0x02,0x7F,1,31,1,6,18,2,10,20},\
                                       {0x04,0,0,0,0,0,1,31,1,0x7F}, {0x08,0,0,0,0,0,1,31,1,0x7F},\
                                       {0x10,0,0,0,0,0,1,31,1,0x7F}, {0x20,0,0,0,0,0,1,31,1,0x7F}};   




extern void UART0_WriteMsg( char *InStr);
extern void UART1_WriteMsg( char *InStr);
extern unsigned int AnalogSensRead();
extern void BIN2STR(unsigned int BinData, char *str);
extern void ShowHexString(unsigned char *message, char Lengh);
extern unsigned char  GetStatusReg(unsigned char mask);
extern void SetStatusReg(unsigned char mask, unsigned char val);
extern int twiWriteExtMemN(char block, unsigned int addr, unsigned char n, char *pdata);
extern int twiReadExtMemN(char block,const unsigned int InternalAddr, char n, char *pdata);
extern  char twiReadEEP1byte(char block,  unsigned int InternalAddr );
extern void Get_Provider(char *str);
extern void Get_CSQ(char *str);
extern char Set_BLE_Name(void);
//-----------rutines------------------------------------
extern void CloseRelay1 (void);
extern void OpenRelay2 (void);
extern void OpenRelay1 (void);
extern void CloseRelay2 (void);
extern void BatLevel_ON(void);
extern void BatLevel_OFF(void);
extern  void BLE_RESET(void);
extern unsigned char ChkNodemRespons(char flash *str1,char flash *str2, unsigned char timeout);
//----------bits-------------------------------------- 
extern bit Modem_Message_Recieved;
extern bit bWaitForModemAnswer;
extern bit BLE_connected;
extern bit EncriptedValOK;
extern bit MODEM_GOT_IP;

extern eeprom char eUsersNumArray[] ;
extern eeprom unsigned int elogger_id;
extern eeprom char eFLAGS_STSTUS;

extern char RxUart0Buf[MAX_RX_BUF_LEN];
extern char rx_buffer1[];
extern unsigned int rx0_buff_len;
extern char ComBuf[];
extern int TimeLeftForWaiting;
extern char  FlagsStatus;
extern  unsigned int rx_counter1;
extern char encrypted_data[10];
extern char UNIT_NAME[11];
extern char TicksCount;



//#define LOG_REC_COUNT 300
//#define LOG_REC_LENGH 32
//#define LOG_BASE_ADD  0xDA80
//#define LOG_END_ADD   LOG_BASE_ADD+ LOG_REC_LENGH*LOG_REC_COUNT (0xFFFF)
void  UpdateLog(char *num , clock_params *pCur_Time)
{
     unsigned int LogAddress,CurrentLogIndx ;      
     char logBuf[32],i; 
     
     for(i = 0; i < 32; i++)
     logBuf[i] = '0';
     
     Monitor_message ("Write log..\r\n\0");  
     
    
    
    
//     sprintf(logBuf, "%s%x%x%x%x%x\r\n\0",num,pCur_Time->year,pCur_Time->month,pCur_Time->day,pCur_Time->hour,pCur_Time->minute); 
      sprintf(logBuf, "%s",num);   
     logBuf[BLE_Num_Len+1] = pCur_Time->year;
     logBuf[BLE_Num_Len+2] = pCur_Time->month;
     logBuf[BLE_Num_Len+3] = pCur_Time->day;
     logBuf[BLE_Num_Len+4] = pCur_Time->hour;
     logBuf[BLE_Num_Len+5] = pCur_Time->minute; 
               
//     ShowHexString(logBuf,15);   
     
     CurrentLogIndx =  eLogIndex;     //read value from eeprom
     LogAddress = LOG_BASE_ADD + (CurrentLogIndx * LOG_REC_LENGH);  //set address to write to
   
     twiWriteExtMemN(MEM_BANK0, LogAddress,LOG_REC_LENGH ,logBuf);  //log it  
//     
//      twiReadExtMemN(MEM_BANK0, LogAddress,LOG_REC_LENGH ,logBuf);  //debyg  
//     ShowHexString(logBuf,32);  
     
       if(CurrentLogIndx < LOG_REC_COUNT)
       CurrentLogIndx++;  //increment  if not yet at top
    else 
       CurrentLogIndx = 0; // else fold and point to the begining of log again -circular buffer  
       eLogIndex = CurrentLogIndx;   //save to eeprom  
      
}

void ShowLog(unsigned int count)
{
      unsigned int LogAddress,CurrentLogIndx ;  
      unsigned int indx = 0 ; 
      char num[BLE_Num_Len+1];      
      char logBuf1[5]; 
       char logBuf2[15]; 
       char str[35];
     //  char i;  
       
  
    Monitor_message (":reply:Show LOG:\r\n\0");    
     CurrentLogIndx =  eLogIndex;     //read value from eeprom  
    
         
     do{
         if(CurrentLogIndx == 0) 
          CurrentLogIndx = LOG_REC_COUNT;  //
          CurrentLogIndx--;    
                        
          LogAddress = LOG_BASE_ADD + (CurrentLogIndx * LOG_REC_LENGH);  //set address to read from          
          twiReadExtMemN(MEM_BANK0, LogAddress,LOG_REC_LENGH-19 ,num);  //read num+atribute 10 chars 
//          ShowHexString(num,10);  //
       
             twiReadExtMemN(MEM_BANK0, LogAddress+BLE_Num_Len+1,LOG_REC_LENGH-27 ,logBuf1);  //read date/time 5 chars
             twiReadExtMemN(MEM_BANK0, LogAddress+BLE_Num_Len+6,LOG_REC_LENGH-18 ,logBuf2);  //read name    17 chars    
             
//              ShowHexString(logBuf1,5);
              
             //check application expectation for format of string
             sprintf(str,"%s-%02d/%02d/%02d-%02d:%02d-\r\n\0",num,logBuf1[0],logBuf1[1],logBuf1[2],logBuf1[3],logBuf1[4]);  
             UART1_WriteMsg(str);  //debug              
             indx++;  
                 
      }while( indx < count);  
      
        Monitor_message ("End LOG.:end:\r\n\0");
}

char SearchList4Num(char *num)
{
     char *ptr; 
     char BufToCompar[]={0,0,0,0,0,0,0,0,0,0};
     char STR[40]; 
     int  indx;
     
       ptr = NULL; 
       indx = 0;   
       
      ptr = strrchr(num,'S');     //is super user - unit owner 
  //      if(ptr != NULL) 
      if(num[12] == 'S')  
       {     
           ExtMemReadAddress =  EXT_MEM_LIST_BASE_ADDRESS; 
           UsersQuantity = 0; 
           Monitor_message ("Super user Num..\r\n\0"); 
           SuperUser = TRUE;
           return 1; 
       }   
       while((ptr == NULL) && (indx < UsersQuantity))  //loop thru all numbers to find if num in list already
        {   
               ExtMemReadAddress = EXT_MEM_LIST_BASE_ADDRESS + (int)(indx * BLE_Mem_Buf_Len);  //get num start addreess at eeprom  
                                                                                                                                                               
               twiReadExtMemN(MEM_BANK0,ExtMemReadAddress+5,BLE_Num_Len-5, BufToCompar);    //read num from ext mem    
                                                                                                                                                                                                                                                                   
               ptr = strstr(num,BufToCompar);  //compare nums
               if(ptr != NULL)                       //number exist- no need to add
               {                                             
                     sprintf(STR,"Num in list at address %x\r\n\0",ExtMemReadAddress); //set string to write to ext eeprom); 
                     UART1_WriteMsg(STR);  //debug  
                     
                     twiReadExtMemN(MEM_BANK0,ExtMemReadAddress,BLE_Num_Len+1, num);    //read num from ext mem with attribute for log 
                  
                     return 1;                                                 
               }
               else                          
               indx++ ;
        }  
         Monitor_message ("New Num...\r\n\0");
        return 0;
}


char CheckTiming(unsigned int userStartAdd)
{
      char  dows; 
      unsigned int baseOffset, CurrentMinutes,usCurrentMinutes,ueCurrentMinutes; 
      char userTiming[9];               //0= dow 1=s year,2=s month, 3=s day, 4=e year, 5=e month, 6=e day,7=s hour, 8=e hour
      int tmp1;
      
       Monitor_message ("Check user timing..\r\n\0");
      
      tmp1 =  (int)Cur_Time.hour * 60; 
      CurrentMinutes = tmp1 + Cur_Time.minute; 
      baseOffset = userStartAdd + TIMING_DATA_OFFSET;  //point to timing byte
                       
      twiReadExtMemN(MEM_BANK0,baseOffset,9, userTiming);   //read timig data of user from ext mem  
  //     ShowHexString(userTiming,9);
           
      dows = userTiming[0];  //get timig byte - if 0 no limit  
//      PrintNum((long)dows);
      if(dows == 0)   //no limit-abort
      return 1;
      else          //check if request in in time
      {    
        
          usCurrentMinutes = (int)userTiming[7] * 60 + 0;          //make hours as minutes from midnight
          ueCurrentMinutes = (int)userTiming[8] * 60 + 0;   
                                                 
          if(dows & (1<<(Cur_Time.dow-1)))  //if day of week ok continue  
          {
            if((Cur_Time.year >= userTiming[1]) &&  (Cur_Time.year < userTiming[4]+1))  //if year  ok 
            {
               if((Cur_Time.month >= userTiming[2]) &&  (Cur_Time.month < userTiming[5]+1))  //if month  ok  
               {
                   if((Cur_Time.day >= userTiming[3]) &&  (Cur_Time.day < userTiming[6]+1))  //if day of month  ok
                  {                        
                  
                      if( usCurrentMinutes < ueCurrentMinutes)           //if start hour earlier than end hour
                      {
                            if(( CurrentMinutes >= usCurrentMinutes ) && (CurrentMinutes < ueCurrentMinutes+1))
                            return 1;                         //all checks ok
                      } 
                      else   //period pass midnight
                      {
                             if(( CurrentMinutes >= usCurrentMinutes ) || (CurrentMinutes < ueCurrentMinutes+1)) 
                             return 1;
                      }
                  } 
               }  
            }      
         }
                                                                                                                                                                         
      }
     return 0;
}

 void Monitor_message(flash  char *message )
{

       	unsigned char i = 0;
	 
        while (message[i] != '\0')         
        {
	           while ((UCSR1A & DATA_REGISTER_EMPTY) == 0);  // wait for data to be transmitted
               UDR1 = message[i++];
        }
    //    RX1intEN;  // allow getting response from modem.

}
 int CnvrtStr2Bin (char *str, unsigned int *p)
{
        int val = 0;
        char MINUS = 0; 
        unsigned int indx;  
        
        indx = *p;
          while((str[indx] != ',') &&  (str[indx] != ']') && (str[indx] != '}')) // , or ] or } are end of value','
          {
                if(str[indx] == '-')
                {
                   MINUS = 1;
                }
                else
                {
                    val *= 10;
                    val += (str[indx] - 0x30);
                }
                  indx++;
          } 
          *p = indx;
          if(MINUS == 1)
          return (val * -1);
          return val;

}

char ReadReceivedSMS(void)
{
    char CMGR[] = "AT+CMGR=1\r\n\0"; 
    
    char *ptr;
     
   
 //    DTR_LOW; //modem alive 
     delay_ms(100);  
     Modem_Message_Recieved = FALSE; 
     bWaitForModemAnswer = TRUE; 
     rx0_buff_len = 0; 
     
//     Clean_buf( RxUart0Buf, 250);


     UART0_WriteMsg(CMGR);       //read SMS text from modem memory
     delay_ms(1000);  
     
   
     if(Modem_Message_Recieved == TRUE)   //debug
     {
//          for(i=0;i<rx0_buff_len;i++)   //  +CMTI: "SM",1 
//          _putchar1( RxUart0Buf[i]); 
//          _putchar1('@');
//          _putchar1('\r');
//          _putchar1('\n'); 
     }
     else
     {       
         return 0;
     }  
     
     ptr = strstrf( RxUart0Buf, "CMGR"); 
     if(ptr == NULL)
     {
         Monitor_message ("CMGR not found!\r\n\0"); 
         return 0; 
     } 
 //    else PrintNum((long)(ptr-RxUart0Buf));
//     k =(ptr-RxUart0Buf); 
//       for(i=k;i<rx0_buff_len;i++)   //  +CMTI: "SM",1 
//          _putchar1( RxUart0Buf[i]); 
     return 1;             
}

  void DelSMS(void)
 {
      char SMSdelete[] = "AT+CMGD=1,4\r\n\0";   //del all SMS in prefered srorage

    //  Monitor_message ("Del SMS..\r\n\0");
      UART0_WriteMsg(SMSdelete);
      delay_ms(500);

 }  
 
 void Clean_buf( char *buf, unsigned char lengh)
{
    unsigned char i;     
    for(i =0; i< lengh ; i++) 
    buf[i] = '\0';
   
 } 
 
 void eep_MemCopy( char eeprom* from,  char *to,  unsigned char length)
{
	unsigned char i;
    	
	for(i = 0; i < length; i++)
		to[i] = from[i];	
}  

//   void eePROMWrite (unsigned char data ,unsigned int address)
//  {
//      unsigned char WriteEN;
//      unsigned int eAddress;
//     
//      eAddress = address;
//      while ((WriteEN = (EECR & 0x02)) == 0x02); //wait while EEWE not cleared yet 
//    
//      EEARL = (unsigned char) (eAddress );   //eprom address registers
//      EEARH = (unsigned char) ((eAddress >> 8) & 0x01);
//      
//      EEDR = data;    //eprom data register
//      #asm 
//        cli          //no interrupts, please
//      #endasm
//      EECR = 0x04;    // EEMWE = 1
//      EECR = 0x06;   // and also EEWE 
//      #asm 
//        sei 
//      #endasm          
//     #asm ("WDR");     //reset WD
//    
//   } 
   
     //set a new user password at eprom but save old one first
   unsigned char PassWordSet( char *buf)
 {
    unsigned char i,j,; 
    unsigned char tmpBuf[SMS_PW_LEN];
    unsigned char tmpPWbuf[SMS_PW_LEN]; 
    
   //first, save cuurent PW at new location 
   for(j = 0;j < SMS_PW_LEN; j++) 
   {  
      tmpPWbuf[j] = euPassWord[j];  //copy current PW from eeprom
      euPassWord_old[j] = euPassWord[j]; //write old PW to new eeprom loc  
      tmpBuf[j] =  euPassWord_old[j]; 
   } 
  
   i = 0;
   while((tmpPWbuf[i] == tmpBuf[i]) && (i <SMS_PW_LEN)) 
   i++;    
   if (i != SMS_PW_LEN)                   
   {    
       Monitor_message ("PassWord saving failed!\r\n\0"); 
        return 0;
   }
      //saving OK, can write new PW      
    for(j=0;j < SMS_PW_LEN; j++)  
    euPassWord[j] = buf[j];      // write the new PW to a temp buffr      
    
    i = 0;
    while((buf[i] == euPassWord[i]) && (i <SMS_PW_LEN)) 
    i++;    
           
    if (i == SMS_PW_LEN)   //saving OK - sending SMS for ack
    {            
          return 1;  
    }
     else
     {  
         Monitor_message ("PW update failed - restore old !\r\n\0"); //debbug  
         for(j=0;j < SMS_PW_LEN; j++)  
         euPassWord[j] =  euPassWord_old[j];      // restore old PW 
         return 0;
     } 
   }  
   
  void SendNumAsString(long val)
{
    char s[6];
    BYTE i = 0;
    long tVAL;


    tVAL = val;
    if (tVAL < 0)
    {
         _putchar1('-');
        tVAL *= -1;
    }

    do
    {
        s[i++] = (char)(tVAL % 10);
        tVAL = tVAL / 10;
    }
    while (tVAL > 0);
    for (; i > 0; i--)
    _putchar0(s[i-1] + 48); 
    
//     _putchar0('\n');
//     _putchar0('\r');
}
//---------------------------------------------------------------------------------------

//+CMT: "+972522784873","","20/01/03,09:06:14+08"
//..123456{"L"}  
 char CheckSMSMsg(char source)    //source: 0=SMS 1=BLE
  {    
  
     //  eeprom unsigned char *EE_ptr;  //eeprom pointer
      unsigned char i,j,k,success;//, NumLength;    // DataLengh,    
      char STR[40];  
   //   char NameBuf[20];   
      int  DataLengh,CurrentIndex, gIndex;        
      char *ptr;           
        
      bit  PW_OK, KeyFound ;
            
      mPWactive = FALSE;
      key = 0xFF; 
      
      UsersQuantity = eUsersQuant; //get value from eeprom
     
      
          
     //----------collect CALLER ID -SMS sender number  ------------------  
  
         ptr = strstrf( RxUart0Buf, "CMT");    //part of received string
         if(ptr == NULL)
         {
              Monitor_message ("SMS caller id not found!\r\n\0"); 
              return 0;
         } 
         else 
         {
             k = (ptr - RxUart0Buf);  //k points to start of token "CMT"  
             i = k+7;               //i point to first digit of number 972......
             k = i + 13;            //k point to end of caller id
             j=0;
             while ((RxUart0Buf[i] != '"') && (i < k))    // collect SMS sender ID 
             CallerIdBuf[j++] = RxUart0Buf[i++]; 
             CallerIdBuf[j]  = '\0';
          //   NumLength = j;  
             
              UART1_WriteMsg(CallerIdBuf);  //debug
         }
            
  //---------------------------------------------------------------------------                 

    k=40;
    while ((RxUart0Buf[k++]!= '\n') && (k < 95));   // look for  end of line - data is ahead  
    if(k == 95)
    {
             Monitor_message ("SMS parsing problem..Abort.\r\n\0"); 
             return 0;  
    }
                 
   //   now pick PW, code and data                                                               
       PW_OK = CheckPassWord();  //check for valid PW stored in eeprom           
       if(!PW_OK)
       {              
             Monitor_message ("Wrong PassWord..\r\n\0"); 
        }                   
       else   Monitor_message ("\r\nPassWord OK\r\n\0");  
           
     //   PW_OK = TRUE; no PW!!!!!!!!!!!!!!!!!!!
        
        if((!PW_OK) && (mPWactive == FALSE)) 
        {    
            if(source == 0)
            SendMsgBySMS(5);  //ack sensdr and admins that wrong pw sent  
            else
             Monitor_message ("PW problem..Abort.\r\n\0"); 
             return 0;  
        } 
        
           
      k = PWindex+5;         //k point to char following pw  
      j = 0;  
      
      while((RxUart0Buf[k] != '{') && (j < 3))   
      {
          k++;   j++;        
      }  
      if(j==3)                      
      {                                       
            Monitor_message ("Syntax problem..Abort.\r\n\0"); 
             if(source == 0)
            SendMsgBySMS(3);                                  
            return 0;              
      } 
//         CurrentIndex = k ;                               
     	 j = 0; 
       
         do
         {   //collect data into buffer        
             SMSdataBuf[j++] = RxUart0Buf[k++]; 
                                   
          }
        while((RxUart0Buf[k] != '}') && (j < SMS_DATA_BUF_LEN));
        
          
        if(k == SMS_DATA_BUF_LEN)
        {
             Monitor_message ("SMS parsing problem..Abort.\r\n\0"); 
             return 0;  
        }  
        else
         {      
               SMSdataBuf[j] = '}';
               success = TRUE;
               Monitor_message ("RX valid..\r\n\0");
         }   
      
          DataLengh = j+1; 
        
          
          for(j=0;j<DataLengh;j++)
          _putchar1(SMSdataBuf[j]);    //debug
          _putchar1('\r');
         _putchar1('\n');  
         delay_ms(100);

     if(success == TRUE)
    {            
         gIndex = 0; //CurrentIndex;  
         do
          {    
                               
                KeyFound = FALSE; 
                while((KeyFound == FALSE) && (SMSdataBuf[gIndex] != '}') && (gIndex < DataLengh ))  //look for key-"x" until end of jason  
                { 
                   if((SMSdataBuf[gIndex] == '"') && (SMSdataBuf[gIndex+2] == '"'))   //key fund 
                   {               
                       KeyFound = TRUE;
                   }
                   else
                   gIndex++;
                     
                }
              
                if(KeyFound == TRUE)       //key found
                {   
                                                
                      gIndex++;                    //skip " - point to a key val                              
                      key = SMSdataBuf[gIndex];           //key known now  
                      sprintf(STR, "key= %c\r\n\0",key);  
                      UART1_WriteMsg(STR); 
                                                  
                            
                             switch (key)            //check the char
                             { 
                                  case 'L':
                                                                         
                                  break; 
                                  
                                  case 'S':
                                       SendMsgBySMS(201);  //send SMS to server
                                  break;
                             } 
                               

                 } 
                 else  success = FALSE;
                gIndex++;
          }while((SMSdataBuf[gIndex] != '}') && ( gIndex < DataLengh) && (KeyFound == FALSE));
      
      
    }  
     return success;
 }         
        
 //+CMT: "+972546377944",,"10/11/08,17:52:52+8",145,4,0,8,"+97254120032",145,21  
 //+CMGR: "REC READ","+972522784873","","19/07/01,09:03:27+12" .fc5wo1,8,!   
 //08\11\2010  updated for coded SMS reading  
  
 char CheckMessage(char source)    //source: 0=SMS 1=BLE
  {    
  
     //  eeprom unsigned char *EE_ptr;  //eeprom pointer
      unsigned char i,j,k,m,success;//, NumLength;    // DataLengh,    
      char BufToCompar[13],STR[40], UserTimingArr[20],tmp[25];  
   //   char NameBuf[20];   
      int  DataLengh,CurrentIndex, gIndex,int_val;        
      char *ptr;           
        
      bit  PW_OK,NumInList, KeyFound ;
//      char Str3[30];
//      char Str2[10]; 
    
            
      mPWactive = FALSE;
      key = 0xFF; 
      CurrentIndex = 0; 
      UsersQuantity = eUsersQuant; //get value from eeprom
      NumInList = FALSE; 
      
     
      OPEN_SESSION = FALSE;
      CLOSE_SESSION = FALSE;
       
     //----------collect CALLER ID -SMS sender number  ------------------  
     if(source == 0)
     {
         ptr = strstrf( RxUart0Buf, "READ");    //part of received string
         if(ptr == NULL)
         {
              Monitor_message ("caller id not found!\r\n\0"); 
              return 0;
         } 
         else 
         {
             k = (ptr - RxUart0Buf);  //k pointer to start of token "READ"  
             i = k+8;               //i point to first digit of number 972......
             k = i + 13;            //k point to end of caller id
             j=0;
             while ((RxUart0Buf[i] != '"') && (i < k))    // get SMS sender ID 
             CallerIdBuf[j++] = RxUart0Buf[i++]; 
             CallerIdBuf[j]  = '\0';
          //   NumLength = j;  
             
            //  UART1_WriteMsg(CallerIdBuf);  //debug
         }
     }            
  //---------------------------------------------------------------------------                 

//    k=40;
//    while ((RxUart0Buf[k++]!= '\n') && (k < 95));   // look for  end of line - data is ahead 
                 
       //now pick PW, code and data                                                               
//       PW_OK = CheckPassWord();  //check for valid PW stored in eeprom           
//       if(!PW_OK)
//       {              
//             Monitor_message ("Wrong PassWord..\r\n\0"); 
//        }                   
//       else   Monitor_message ("PassWord OK\r\n\0");  
       
//        if(mPWactive == FALSE)   //if not mPW check caller id -mPW allowed always
//        { 
//            success = IsNumAllowed(CallerIdBuf, NumLength );  //check if sender allowed
//            if(!success)
//            {  
//                  Monitor_message ("Caller not allowed..Abort.\r\n\0");  
//                         
//                  return 0;  
//            }  
//        }
    //    PW_OK = TRUE; //no PW!!!!!!!!!!!!!!!!!!!
        
//        if((!PW_OK) && (mPWactive == FALSE)) 
//        {    
//            if(source == 0)
//            SendMsgBySMS(5);  //ack sensdr and admins that wrong pw sent  
//            else
//             Monitor_message ("PW problem..Abort.\r\n\0"); 
//             return 0;  
//        } 
//        
//      j = PWindex;            
//      k = j+5;         //k point to char following pw  
//      j = 0;
//    //  while((RxUart0Buf[k] != '{') && (j < 3))
//       while((rx_buffer1[k] != '{') && (j < 3))
//      {
//          k++;
//          j++;
//      }  
//      if(j==3)                      
//      {     
//                                  
//            Monitor_message ("Syntax problem..Abort.\r\n\0"); 
//             if(source == 0)
//            SendMsgBySMS(3);                                  
//            return 0;              
//      } 
                                        
     	 j = 0; 
         k = 0;
         do
         {   //collect data into buffer        
            //  SMSdataBuf[j++] = RxUart0Buf[k++]; 
               SMSdataBuf[j++] = rx_buffer1[k++];                            
          }
      //    while((RxUart0Buf[k] != '}') && (j < SMS_DATA_BUF_LEN));
          while((rx_buffer1[k] != '#') && (j < rx_counter1)); 
          
         if(rx_buffer1[k] == '#')   //string not complete !! abort 
         {
            success = TRUE;
//             Monitor_message ("RX valid..\r\n\0");
         }   
         else
         {
            success = FALSE; 
            Monitor_message ("RX NOT valid..\r\n\0");
          }                    
          DataLengh = j; 
        
          
//          for(j=0;j<DataLengh;j++)
//          _putchar1(SMSdataBuf[j]);    //debug
//          _putchar1('\r');
//         _putchar1('\n');  
//         delay_ms(500);
//------------------------new code---------------------------------------------------- 
 //parsing loop of jason string  
  if(success == TRUE)
  {       
  do
   {    
        gIndex = CurrentIndex+1; 
        KeyFound = FALSE; 
        while((KeyFound == FALSE) && (SMSdataBuf[gIndex] != '}') && (gIndex < DataLengh ))  //look for key-"x" until end of jason  
        { 
           if((SMSdataBuf[gIndex] == '"') && (SMSdataBuf[gIndex+2] == '"') && (SMSdataBuf[gIndex+1] != ','))   //key fund 
           {               
               KeyFound = TRUE;
           }
           else
           gIndex++;
             
        }
      
        if(KeyFound == TRUE)       //key found
        {   
                                        
              gIndex++;                    //skip " - point to a key val                              
              key = SMSdataBuf[gIndex];           //key known now  
              sprintf(STR, "key= %c\r\n\0",key);  
                     UART1_WriteMsg(STR); 
                                          
//               if((UsersQuantity == 0) && (key == 'S'))  //add first number to list               
//                SentByAdmin = TRUE;    //first time setting     
                                                 
//                if(SentByAdmin == TRUE)  //admin's
                 {   
//                     sprintf(STR, "Sent By Admin\r\n\0");  
//                     UART1_WriteMsg(STR);
                  
               		 switch (key)            //check the char
              		 {    
                        //  Monitor_message ("switch (key).\r\n\0");  
                               
                        //-------------------------------------REMOVE numbers------------------------------------                                                                
                        case 'R':       //remove few numbers   "R":["~~0522784873"]
                           
                             CurrentIndex = gIndex + 3;      //i point to third digit to start with   
                             success = FALSE; 
                             NumInList = FALSE;
                              m = 0;
                             do{                                        
                                    j = 0;                                                                       
                                    CurrentIndex++;                                   
                                    CurrentIndex++; 
                                                                    
                                     do{
                                            CurrentNumber[j++] = SMSdataBuf[CurrentIndex++];  //CurrentNumber = num to add +A or U                                    
                                   
                                      }while ((SMSdataBuf[CurrentIndex] != '"') &&  (SMSdataBuf[CurrentIndex] != ']') && (j < BLE_Num_Len+1)); 
                                     CurrentIndex++;    //point to ',' or ']'     
                                      CurrentNumber[j] = '\0';   
                                              
                                     sprintf(STR, "user to remove: %s\r\n\0",CurrentNumber); //debug);  
                                     UART1_WriteMsg(STR);                                       
                                  
                                       m = SearchList4Num(CurrentNumber);   //loop in list to find location- set ExtMemReadAddress
                                       if(m)  NumInList = TRUE;            //set   ExtMemReadAddress
                                                    
                                       if((NumInList == TRUE) && (ExtMemReadAddress > EXT_MEM_LIST_BASE_ADDRESS))  //number exist and not SUPER USER
                                       {                                             
                                               
                                             sprintf(STR, "Removing Num %s.\r\n\0",CurrentNumber); //debug);  
                                             UART1_WriteMsg(STR);                                              
                                           
                                             if(UsersQuantity > 1)   //first num cant be removed
                                             {   
                                                 UsersQuantity--;  
                                                 if(( ExtMemReadAddress / BLE_Mem_Buf_Len) < UsersQuantity)  //if not last user in list make the noving of upper user
                                                 {
                                                     ExtMemWriteAddress =  ExtMemReadAddress ; //num in list. keep address to overwrite it
                                                     ExtMemReadAddress = (unsigned int)(UsersQuantity  * BLE_Mem_Buf_Len);  //read last user and insert at the new empty loc  
                                                     twiReadExtMemN(MEM_BANK0,ExtMemReadAddress,BLE_Mem_Buf_Len, STR); //get the top user num to move it                                                                                                                                                                                                                                                                                                                                                              
                                                     m = twiWriteExtMemN(MEM_BANK0, ExtMemWriteAddress,BLE_Mem_Buf_Len,STR); //and put it in the removed location 
                                                    
                                                 }
                                                
                                             }
                                             success = TRUE;                                         
                                       }
                                       else if(NumInList == FALSE)
                                        Monitor_message ("Num NOT found in list!\r\n\0");                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
                             }while(SMSdataBuf[CurrentIndex] != ']');     //all numbers removed
                              
                               
                             if(source == 0)   
                               SendMsgBySMS(2);
                        break;  
             //-----------------------------------add------------------------------------------------------           
                        case 'A':             //add users     "A":["522784873A",0,"xdanny"]
                        
                            //  Monitor_message ("Case A..\r\n\0");
                                CurrentIndex = gIndex + 3;      //CurrentIndex point to [ 
                                NumInList = FALSE;    
                                                            
                                  // Monitor_message ("Adding Numbers by BLE..\r\n\0");
                                
//                                 
                                     do{
                                            m = 0;                                                
                                            k = 0;                                                                                     
                                            CurrentIndex++;     //CurrentIndex point to first digit of num 
                                            CurrentIndex++;     //CurrentIndex point to "   
                                            
                                            for(j = 1; j < 14; j++)   //reset timing array  
                                            {                                                                                  
                                                UserTimingArr[j] = 0; 
                                                CurrentNumber[j] = 0;
                                              
                                            }
                                             j = 0;                                                                                      
                                                                                       
                                            do
                                             {
                                                    CurrentNumber[j] = SMSdataBuf[CurrentIndex++];  //CurrentNumber = num to add +A or U  
                                                    j++;                                  
                                             }                                        
                                             while ((SMSdataBuf[CurrentIndex] != '"') &&  (SMSdataBuf[CurrentIndex] != ']') &&  (j < BLE_Num_Len+2)); 

                                           //  k = j;                                  
//                                              sprintf(STR, "User: %s\r\n\0",CurrentNumber); //debug);  
//                                              UART1_WriteMsg(STR); 
                                                                                                                                                                                 
                                        if(j >= BLE_Num_Len )  //number is  complete. continue
                                        {      
                                               m = SearchList4Num(CurrentNumber);      // "A":["522784873A",0,"xdanny"
                                               if(m)  NumInList = TRUE;                                                                           
                                                j = 0;                                           
                                               if(UsersQuantity < BLE_USERS_COUNT )    //new number-add it if list not full
                                               {    
                                                      
                                                         CurrentIndex++;  //skip '"' 
                                                           CurrentIndex++;  //skip ','                                                                                           
                                                         int_val = CnvrtStr2Bin (SMSdataBuf, &CurrentIndex);  //read timming byte - check if need timing data. CurrentIndex++                                                    
                                                         UserTimingArr[j++] = int_val;    //set days timing params                                                                                                            
                                                         
                                                         if(int_val > 0) //if > 0 week days count -read all timing data 
                                                         {   
                                                             for( ; j < 9; j++)  //read timig data, make it bin and fill timing array-
                                                             {                                                                     
                                                                    CurrentIndex++;  //skip ','
                                                                    UserTimingArr[j] = (char)(CnvrtStr2Bin (SMSdataBuf, &CurrentIndex)); //fill timing array- CurrentIndex incremented in CnvrtStr2Bin()
                                                             } 
                                                                                                                                                                                                                                                                                                                                                                                                                  
                                                         }   
                                                       //  else   //no limit data
                                                         {
                                                              if (SMSdataBuf[CurrentIndex] != ']')  //bug super user
                                                              {
                                                                  CurrentIndex++;  //skip ','     "A":["522784873A",0,"xdanny"]   "A":["522784873A",0],"xdanny"]
                                                                  CurrentIndex++;  //skip '"'     point to name                                                             
                                                                 
                                                                   while (SMSdataBuf[CurrentIndex] != '"') 
                                                                   {
                                                                         UserTimingArr[j++] = SMSdataBuf[CurrentIndex++] ; //add name until '"'                                                                                                                       
                                                                   } 
                                                                   CurrentIndex++;  //needed
                                                              }
                                                         } 
                                                          
                                                          
                                                           
                                                      //     ShowHexString(UserTimingArr,j);   //debug timing+name  
                                                           
                                                           m = j;                                                                                                                                                                                                                                     
                                                   
                                                         for(j = 0; j < BLE_Num_Len+1; j++,k++)     //copy name to main STR -  k count chars in buf
                                                             STR[j] = CurrentNumber[j];
                                                                                                                           
                                                         for(j = 0; j < m; j++,k++)
                                                             STR[j+BLE_Num_Len+1] = UserTimingArr[j];  //complete string with timing data and name 
                                                             
                                                          if(k < BLE_Mem_Buf_Len)
                                                          STR[k++] = '#';   //ad end of string char for reading
                                                                                                                                                                                                                        
                                                  //      ShowHexString(STR,k);   //debug  
                                                                                                         
                                                         if(SuperUser) 
                                                         ExtMemWriteAddress  = EXT_MEM_LIST_BASE_ADDRESS; //write it first in mem
                                                                                                              
                                                         else if((NumInList == TRUE) && (ExtMemReadAddress > EXT_MEM_LIST_BASE_ADDRESS ))      //num already in list and not super user -update it
                                                           ExtMemWriteAddress =  ExtMemReadAddress ; //num in list - overwrite it
                                                        else   //new user - add to most top                                                                                                                                                                                                                                               
                                                          ExtMemWriteAddress = EXT_MEM_LIST_BASE_ADDRESS + (unsigned int)(UsersQuantity * BLE_Mem_Buf_Len);  //set addres at upper list to be  writen  
                                                          ExtMemReadAddress = ExtMemWriteAddress;                                                     
                                                          
                                                         
                                                          twiWriteExtMemN(MEM_BANK0, ExtMemWriteAddress,k ,STR);  //write string to mem 
                                                          
                                                          if((NumInList == FALSE) ||(SuperUser == TRUE))                                                                                                                                                                
                                                          UsersQuantity++;   //inc counter when needed
                                                               
                                                          sprintf(STR,"Write to Ext mem. Address: %x\r\n\0",ExtMemWriteAddress); //set string to write to ext eeprom); 
                                                          UART1_WriteMsg(STR);  //debug                                                                                                          
                                                                                                            
//                                                          m = twiReadExtMemN(MEM_BANK0,ExtMemWriteAddress,32 ,tmp);  //debug read it
//                                                           ShowHexString(tmp,16);                                                         
                                                            
                                                            
                                                           if(SuperUser)   //super user added -reset stat reg bit 
                                                            {     
                                                                    SuperUser = FALSE; 
                                                                    FlagsStatus =  eFLAGS_STSTUS; 
                                                                    SetStatusReg(NEW_BLE_UNIT , 0); 
                                                                    eFLAGS_STSTUS =  FlagsStatus;                                                                                                                                                                                                              BLE_RESET();
                                                                  
                                                                    delay_ms(500);    //disconnect by app 
                                
                                                                  //  Set_BLE_Name();                                                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                                                                       
                                                            } 
                                                }
                                               else Monitor_message ("No writing..\r\n\0"); //debug
                                         }
                                         else
                                         {     
                                               CurrentIndex++;
                                               Monitor_message ("Number validity failure..check\r\n\0"); //debug
                                              //repaet needed ????????????????????????????????? 
                                              break;
                                         }
                                                                                                                                                                                                                                                           
                                       }while((SMSdataBuf[CurrentIndex] != ']') && (SMSdataBuf[CurrentIndex+1] != '}' ))  ;     //all numbers added
                                      
                                       success = TRUE;                               
                                       gIndex = CurrentIndex + 1;
                                   
                        break; 
        //----------------------------------------------------------------------------------------------                
                        case 'L':      //show log
                                     CurrentIndex = gIndex + 4;  
                                     int_val = (char)(CnvrtStr2Bin (SMSdataBuf, &CurrentIndex));
                                     ShowLog(int_val); 
                                     success = TRUE ;
                         break; 
                        
                        case 'N':  //  set new unit name      "N":[unit_name]
                                        CurrentIndex = gIndex + 4; 
                                      i = 0;                                    
                                      #asm ("cli")          
                                      while ((SMSdataBuf[CurrentIndex] != ']') && (i < 15)) 
                                      {     
                                           tmp[i] = SMSdataBuf[CurrentIndex];
                                           eUnit_Name[i++] = SMSdataBuf[CurrentIndex++];                                          
                                      }
                                      tmp[i] =  '\0';
                                      eUnit_Name[i++] = '#'; 
                                      eUnit_Name[i] = '\0';                                
                                      #asm ("sei")   
                                      sprintf(STR, "New Unit Name: %s\r\n\0",tmp);  
                                      UART1_WriteMsg(STR); 
                                       success = TRUE ;
                                      
                                      if(source == 0)
                                      SendMsgBySMS(4); 
                                      
                                      
                                 
                        break;  
                        
                        case 'P':       //update PW  "P":[PASWRD]  
                                      CurrentIndex = gIndex + 4; 
                                      i = 0;
                                      while ((SMSdataBuf[CurrentIndex] != ']') && (i < 6)) //collect 8 digit of num to buf to compar
                                      CurrentNumber[i++] = SMSdataBuf[CurrentIndex++];  //CurrentNumber = new pwe
                                      success = PassWordSet(CurrentNumber);   //code match  
                                       if(source == 0)
                                       {
                                          if(success) 
                                           SendMsgBySMS(8);       //ok msg
                                          else 
                                           SendMsgBySMS(9);              //error                                      
                                      }
                        break; 
                        
                        case 'D':    

                         break;  
                        
                        case 'U':      //show users list   
                                      CurrentIndex = gIndex + 4; 
                                      k=0; 
                                   
                                      m = 1;                                   
                                      sprintf(STR, ":reply:Users List-%d users.\r\n\0",UsersQuantity);  
                                      UART1_WriteMsg(STR);                                           
                                      
                                      while(k < UsersQuantity)  //loop thru all numbers to find if num in list already
                                      {   
                                           ExtMemReadAddress = EXT_MEM_LIST_BASE_ADDRESS + ((int)k * BLE_Mem_Buf_Len);  //get num start addreess at eeprom  
                                           m = twiReadExtMemN(MEM_BANK0,ExtMemReadAddress,BLE_Num_Len+1, BufToCompar);
                                           BufToCompar[BLE_Num_Len] = '\0'; 
                                                                                                                                                              
                                           m = twiReadExtMemN(MEM_BANK0,ExtMemReadAddress+BLE_Num_Len+1,19,UserTimingArr);    //read timing+name data  
                                           
                                       //    ShowHexString(UserTimingArr,19);   
                                                                                                                           
                                           if(UserTimingArr[0] == 0)  //no limits  
                                           {   
                                               j = 0; 
                                               m = 1;
                                               while((UserTimingArr[m] != '#') && (j < 19 ))
                                               { 
                                                   tmp[j] = UserTimingArr[m]; 
                                                   j++; 
                                                   m++;
                                               }
                                                                                          
                                               tmp[j] = '\0';                                  
                                               sprintf(STR, "%s,%d,%s\r\n\0",BufToCompar,UserTimingArr[0],tmp);
                                                                                            
                                           
                                           }    
                                           else  //add timing data
                                           { 
                                          
                                                m = 9; 
                                                j = 0;
                                                while((UserTimingArr[m] != '#') && (j < 10 ))  
                                                { 
                                                     tmp[j] = UserTimingArr[m];
                                                     j++;
                                                     m++;
                                                }
                                              
                                                                                                                                         
                                                tmp[j] = '\0';                                          
                                                  sprintf(STR, "%s,%02d,%02d,%02d,%02d,%02d,%02d,%02d,%02d,%02d,%s\r\n\0",BufToCompar,UserTimingArr[0],UserTimingArr[1],UserTimingArr[2],\
                                                  UserTimingArr[3],UserTimingArr[4],UserTimingArr[5],UserTimingArr[6],UserTimingArr[7],UserTimingArr[8],tmp);
                                            
                                           }  
                                           UART1_WriteMsg(STR);                                                                                                                                                                                                                               
                                           k++ ;
                                      } 
                                      sprintf(STR, "Users List-%d users.:end:\r\n\n\0",UsersQuantity);  
                                      UART1_WriteMsg(STR);                                                                             
                               
                        break;  
                        
                        case 'Z':    // set UsersQuantity  "Z":[100]
                                    CurrentIndex = gIndex + 4;  
                                    UsersQuantity = (char)(CnvrtStr2Bin (SMSdataBuf, &CurrentIndex));
                                    eLogIndex = 0;     //debug only - remove for release                                                                   
                                    success = TRUE;
                        break;
                                    
                                                                                     
                    //admin only end
                    } 
                }   //if sent by admin  
              //  else
//                {                     
//                      sprintf(STR, "Sent By user-key %c\r\n\0",key);  
//                      UART1_WriteMsg(STR);
//                }        
                   switch(key)
                   {
                        case 'r':         //close/open relays   "c":[1,1]  close R1, R2                                    
                                      
                                  FlagsStatus =  eFLAGS_STSTUS;
                                  CurrentIndex = gIndex + 4;  
                                    
                                  if(SMSdataBuf[CurrentIndex] == '1') 
                                  {
                                       OpenRelay1();   
                                        SetStatusReg(RELAY1_ON , RELAY1_ON); 
                                        Monitor_message ("Relay1 Closed by SMS..\r\n\0"); //debbug 
                                  }
                                  else   if(SMSdataBuf[CurrentIndex] == '0') 
                                  {
                                      
                                        CloseRelay1();  
                                        SetStatusReg(RELAY1_ON ,0);
                                        Monitor_message ("Relay1 Open by SMS..\r\n\0"); //debbug  
                                  }  
                                      
                                  CurrentIndex += 2;   
                                     
                                  if(SMSdataBuf[CurrentIndex] == '1') 
                                  {
                                       OpenRelay2();  
                                       SetStatusReg(RELAY2_ON , RELAY2_ON);
                                        Monitor_message ("Relay2 Closed by SMS..\r\n\0"); //debbug 
                                  }
                                  else   if(SMSdataBuf[CurrentIndex] == '0') 
                                  {
                                       CloseRelay2(); 
                                       SetStatusReg(RELAY2_ON , 0);
                                       Monitor_message ("Relay2 Open by SMS..\r\n\0"); //debbug 
                                  }                   
                                                                                                                                                                                                                                                             
                                  eFLAGS_STSTUS =  FlagsStatus;   
                                  Relays_Stat =  FlagsStatus & 0x03; // 
                                   if(source == 0)
                                  SendMsgBySMS(1);
                         break;  
                         case 's':    //get unit status   +COPS: 0,0,"Partner",0    +CSQ: 28,0 
//                                     CurrentIndex = gIndex + 4; 
//                                     Get_Provider(provider); 
//                                                                                                          
//                                     delay_ms(1000);
//                                     Get_CSQ(csq); 
//                                     UART1_WriteMsg(csq);  
//                                       
//                                     Relays_Stat = 0;
//                                     FlagsStatus =  eFLAGS_STSTUS;
//                                     if(FlagsStatus & RELAY1_ON)
//                                     Relays_Stat |= RELAY1_ON; 
//                                     if(FlagsStatus & RELAY2_ON)
//                                     Relays_Stat |= RELAY2_ON;     //if both ON Relays_Stat = 0x03 
//                                     PrintNum((long)Relays_Stat); 
//                                     
//                                   BatLevel_ON();
//                               //    BatLevel = AnalogSensRead();  //read battery level
//                                   BatLevel_OFF(); 
//                                   BatLevel = 11980;         //change in new board  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
//                                   SendDebugMsg("Battery val= ");
//                                   PrintNum(BatLevel);  
//                                   
//                                   if(source == 0)                                            
//                                   SendMsgBySMS(10);
                          break;    
                          
                          case 'f':      //check if user in list first time  "f":[546377944] 
                                          CurrentIndex = gIndex + 4; 
                                          for(j = 1; j < 10; j++)   //reset timing array                                          
                                           CurrentNumber[j] = 0;                                              
                                         
                                          j=0;
                                          do
                                          {
                                                CurrentNumber[j] = SMSdataBuf[CurrentIndex++];  //CurrentNumber = num to add +A or U  
                                                j++;                                  
                                          }                                        
                                          while ((SMSdataBuf[CurrentIndex] != ',') &&  (SMSdataBuf[CurrentIndex] != ']') &&  (j < BLE_Num_Len+2)); 
                                         
                                         m = SearchList4Num(CurrentNumber);  //set ExtMemReadAddress
                                         if(m) 
                                         {                                              
                                               m = twiReadExtMemN(MEM_BANK0,ExtMemReadAddress,BLE_Num_Len+1, BufToCompar);
                                               BufToCompar[BLE_Num_Len] = '\0';                                                                                                                                                                                                                                                                                                                                                                                                                                          sprintf(STR, "%s\r\n\0",BufToCompar);                                              
                                               sprintf(STR, "%s\r\n\0",BufToCompar);  //TELL APP THAT USER IN LIST+ITS ATTRIBUTE                                                 
                                          } 
                                         else
                                         {
                                              sprintf(STR, "%sN\r\n\0",CurrentNumber);
                                         }
                                          
                                         UART1_WriteMsg(STR);
                                         success = TRUE ;     
                         break; 
                         
                        
                         
                         case 'c':      //{�c�:[19/09/03-14:28-2] 
                                         CurrentIndex = gIndex + 4; 
                                         Cur_Time.year = ((SMSdataBuf[CurrentIndex]-0x30) * 10) + (SMSdataBuf[CurrentIndex+1]-0x30);    //year                                                           
                                         CurrentIndex += 3;
                                         Cur_Time.month = ((SMSdataBuf[CurrentIndex]-0x30) * 10) + (SMSdataBuf[CurrentIndex+1]-0x30);   //month            
                                         CurrentIndex += 3;
                                         Cur_Time.day = ((SMSdataBuf[CurrentIndex]-0x30) * 10) + (SMSdataBuf[CurrentIndex+1]-0x30);  //day              
                                         CurrentIndex += 3;
                                         Cur_Time.hour = ((SMSdataBuf[CurrentIndex]-0x30) * 10) + (SMSdataBuf[CurrentIndex+1]-0x30);   //hour            
                                         CurrentIndex += 3;
                                         Cur_Time.minute = ((SMSdataBuf[CurrentIndex]-0x30) * 10) + (SMSdataBuf[CurrentIndex+1]-0x30);   //minute             
                                          CurrentIndex += 3;
                                         Cur_Time.dow = (SMSdataBuf[CurrentIndex] - 0x30);  //dow  
                                         
                                          sprintf(STR, "Request time: %02d/%02d/%02d-%02d:%02d-%d\r\n\0",Cur_Time.year,Cur_Time.month,Cur_Time.day,Cur_Time.hour,Cur_Time.minute,Cur_Time.dow);  
                                         UART1_WriteMsg(STR);                      
                                       
                         break;   
                         
                          case 'e':         //encripted value from app "e":[1234567] 
                                        //    Monitor_message ("key = e..\r\n\0");
                                           CurrentIndex = gIndex + 4;             
                                          j=0;
                                          do
                                          {
                                                CurrentNumber[j] = SMSdataBuf[CurrentIndex++];  // 
                                                j++;                                  
                                          }                                        
                                          while ((SMSdataBuf[CurrentIndex] != ',') && (SMSdataBuf[CurrentIndex] != ']') &&  (j < 9)); 
                                          CurrentNumber[j] = '\0';
                                          
//                                            for(i = 0; i< 10; i++)
//                                              Str2[i] = encrypted_data[i];
//                                            Str2[i] = '\0';
//
//                                            sprintf(Str3,"enc: %s\r\n\0",Str2);
//                                            UART1_WriteMsg(Str3);                 
                                          
                                           ptr = strstr(encrypted_data,CurrentNumber);  //compare nums
                                          if(ptr != NULL)  
                                          {                     //encription ok 
                                              success = TRUE; 
                                              EncriptedValOK = TRUE;  
                                            //   Monitor_message ("encription compare OK..\r\n\0"); 
                                          } 
                                          else
                                          {
                                               EncriptedValOK = FALSE;
                                               success = FALSE;  
                                                Monitor_message ("encription compare failed..\r\n\0"); 
                                          }                 
                                           CurrentIndex++;
                                        
                         break; 
                         
                         case 'g':     //open gate request
                                    //  Monitor_message ("key = g..\r\n\0");
                                       CurrentIndex = gIndex + 4;   //move index-enable ending process
                                      if( EncriptedValOK == FALSE)
                                      {
                                          success=FALSE;
                                          break; 
                                      }  
                                      else
                                      {
                                                                                                                                                                                                                                                               
                                           j = 0;                                            
                                           do
                                           {
                                                CurrentNumber[j++] = SMSdataBuf[CurrentIndex++];  //get parameter val-relay index                                    
                                       
                                           }while ((SMSdataBuf[CurrentIndex] != ',') &&  (SMSdataBuf[CurrentIndex] != ']') && (j < 3));                                               
                                         //  CurrentNumber[j] = '\0';   
                                                  
//                                          sprintf(STR, "Used Relay: %s\r\n\0",CurrentNumber); //debug);  
//                                          UART1_WriteMsg(STR);                                       
                                          success = 10 + (CurrentNumber[0]-0x30);// relay index     
                                      }
                                                    
                                        CurrentIndex++;                                                                                                        
                                                                                                                                                      
                         break;    
                         
                           case 'i':     //open gate request - long press
                                       Monitor_message ("key = i..\r\n\0");
                                       CurrentIndex = gIndex + 4;   //move index-enable ending process
//                                      if( EncriptedValOK == FALSE)
//                                      {
//                                          success=0;
//                                          break; 
//                                      }  
//                                      else
                                      {                                                                                                                                                                                                                                                               
//                                           j = 0;                                            
//                                           do
//                                           {
//                                                CurrentNumber[j++] = SMSdataBuf[CurrentIndex++];  //get parameter val-relay index                                    
//                                       
//                                           }while ((SMSdataBuf[CurrentIndex] != ',') &&  (SMSdataBuf[CurrentIndex] != ']') && (j < 3));                                               
                                       //    CurrentNumber[j] = '\0';   
                                                  
//                                          sprintf(STR, "Used Relay: %s\r\n\0",CurrentNumber); //debug);  
//                                          UART1_WriteMsg(STR); 
                                      
                                         //  success=10 + (CurrentNumber[0]-0x30); 
                                            TicksCount = 10;
                                            success=11 ;
                                           OPEN_SESSION = TRUE;
                                           CLOSE_SESSION = FALSE; 
                                            CONTINUOUS_RELAY = TRUE;           
                                      }
                                                    
                                        CurrentIndex++;                                                                                                        
                                                                                                                                                      
                         break;   
                          
                           case 'h':     //close gate request - long press
                                       Monitor_message ("key = h..\r\n\0");
                                       CurrentIndex = gIndex + 4;   //move index-enable ending process
//                                      if( EncriptedValOK == FALSE)
//                                      {
//                                          success=0;
//                                          break; 
//                                      }  
//                                      else
                                      {
                                                                                                                                                                                                                                                               
//                                           j = 0;                                            
//                                           do
//                                           {
//                                                CurrentNumber[j++] = SMSdataBuf[CurrentIndex++];  //get parameter val-relay index                                    
//                                       
//                                           }while ((SMSdataBuf[CurrentIndex] != ',') &&  (SMSdataBuf[CurrentIndex] != ']') && (j < 3));                                               
                                        //   CurrentNumber[j] = '\0';   
                                                  
//                                          sprintf(STR, "Used Relay: %s\r\n\0",CurrentNumber); //debug);  
//                                          UART1_WriteMsg(STR);                                       
                                         //   success = 10 + (CurrentNumber[0]-0x30); 
                                             TicksCount = 10;
                                             success=12; 
                                             OPEN_SESSION = FALSE;
                                             CLOSE_SESSION = TRUE; 
                                             CONTINUOUS_RELAY = TRUE;    
                                      }
                                      CurrentIndex++;                                                                                                   
                                                                                                                                                      
                         break; 
                            
                            
                         case 'p':       
                                         Monitor_message ("Set relays periods..\r\n\0"); 
                                         CurrentIndex = gIndex + 3;  
                                         for(j = 0; j < 2; j++)
                                         {
                                               CurrentIndex++;
                                               #asm("cli");
                                               Relay_vars[j].op_duration = (char)(CnvrtStr2Bin (SMSdataBuf, &CurrentIndex)); 
                                               #asm("sei"); 
                                         }                                                                                                                 
                                         success = CONTINUE;
                         break;  
                         
                        
                         
                        
                                                                                       
                     default:  
                           CurrentIndex = gIndex + 4;
//                            Monitor_message ("No Key found..!\r\n\0");
//                            SendMsgBySMS(3);   //error code
                  
                       break; 
                   }
         }  
//       else  
//          Monitor_message ("Error-No Key found..!\r\n\0");            
                    
   } 
     while((SMSdataBuf[gIndex] != '}') && ( gIndex < DataLengh));     //while not end of string   MAX_RX0_BUF_LEN)
                              
     //     Monitor_message ("End Msg check..\r\n\0"); //debug   Monitor_message ("End adding process..\r\n\0"); //debug 
          
    
       if((key == 'A') || (key == 'R') || (key == 'L') || (key == 'Z'))    //list handling
       {      
              #asm("cli");
              eUsersQuant =  UsersQuantity;   //save to eeprom   
              #asm("sei");
              sprintf(STR, "Current users quantity= %d\r\n\0", eUsersQuant); //get value from eeprom);  
              UART1_WriteMsg(STR);  
       }   
   }  //if success  
  else
  {
            sprintf(STR, "{[RX ERROR]}\r\n\0"); //get value from eeprom);              
            UART1_WriteMsg(STR);                
  }     
       
        if(source == 0) 
        DelSMS();  
        
//         if(success == 0)
//         sprintf(STR, "Current users quantity= %d\r\n\0", eUsersQuant); //get value from eeprom);  
//         UART1_WriteMsg(STR);  
      
         Modem_Message_Recieved = FALSE;  
       
         return success;
 } 
   //==================================================================  
   
   char SendSMS2Server(void)   //callerIdBuf has the target number
   {
         char BufToSend[11];
         char i;
         SendMsgBySMS(201);  //send SMS to server with unit name as data
         
         
   }
                               
   void SendMsgBySMS(unsigned char code)
   {     
        unsigned char i,j ;  
        char Unit_Name[] =		 "UNIT \0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"; 
        char SMS_ERR[] = 		 "SMS - GENERAL ERROR.\0"; 
        char USER_LIST_OK[] =	 "Users List updated.\0";
     //   char UNAME_OK[] =		 "Set Unit Name OK..\0";              //admin nsg
        char PW_OK[] = 		   	"Set PW OK..\0";              //admin nsg 
        char PW_FAIL[] = 	   	"Set PW Failed..!\0";          //admin nsg                    
        char SMS_PW_ERR[] =		 "SMS PW ERROR!\0";     
        char ARM_ON[] =          "UNIT IS ARMED \0";  
        char STR[70];
        char eeprom *EE_ptr; 
        char *ptr;  
        char NumBuf[14]; 
        char tmpBuf[12];
        
        
          #asm ("wdr"); 	
         i=0;
         j=5; 
           while((eUnit_Name[i] != '#') && (i < 17)) 
           {     //load unit name to be sent by next SMS
             
               Unit_Name[j] = eUnit_Name[i++];     //add unit name  
               j++;           
          } 
          
          
        
                 
           switch (code)      
           {
               case 0:
                     
                    
               break;

               case 1:  
                  //  itoa(tmpY,tmpYear);
                   if(Relays_Stat == 0)
                    sprintf(STR, "%s:\rRelays Current State:\rR1 OFF,R2 OFF\r\n\0",Unit_Name); 
                    else  if(Relays_Stat == 1)
                    sprintf(STR, "%s:\rRelays Current State:\rR1 ON,R2 OFF\r\n\0",Unit_Name);
                    else if(Relays_Stat == 2)
                    sprintf(STR, "%s:\rRelays Current State:\rR1 OFF,R2 ON\r\n\0",Unit_Name);
                    else  if(Relays_Stat == 3)
                    sprintf(STR, "%s:\rRelays Current State:\rR1 ON,R2 ON\r\n\0",Unit_Name);
                  
               break; 
                case 2: 
                      if(UsersQuantity == 0)
                      sprintf(STR, "%s:\rList is empty..!\r\n\0",UsersQuantity); 
                      else
                      sprintf(STR, "%s: %s\r%d Users in list.\r\n\0",Unit_Name,USER_LIST_OK,UsersQuantity);  // USER_LIST_OK
               break; 
                case 3:
                     sprintf(STR, "%s: %s\r\n\0",Unit_Name,SMS_ERR);  //sms general error
               break;
               
                case 4:
                      sprintf(STR, "%s:\rSet Unit Name OK\r\n\0",Unit_Name); //set new  name ok                   
               break;  
               case 5:
                     sprintf(STR, "%s: %s\r\n\0",Unit_Name,SMS_PW_ERR);  //sms general error
               break; 
               
                case 7:
                      sprintf(STR, "%s: %s in %d min.\0",Unit_Name,ARM_ON,ArmDelay);  //    //ARM_ON
               break;
              
              
                case 8:
                      sprintf(STR, "%s: %s\r\n\0",Unit_Name,PW_OK); //set new  PW ok                   
               break;  
                case 9:
                      sprintf(STR, "%s: %s\r\n\0",Unit_Name,PW_FAIL); //set new  PW ok  
               break;
             
                case 10: 
                      if(Relays_Stat == 0)
                       sprintf(STR, "%s:\rNetwork: %s\rRSSI: %s\rBAT LEVEL: %d.%dV\rUsers: %d\rR1 OFF,R2 OFF\r\n\0",Unit_Name,provider,csq,BatLevel/1000,BatLevel%1000,UsersQuantity);  // 
                      else  if(Relays_Stat == 1) 
                       sprintf(STR, "%s:\rNetwork: %s\rRSSI: %s\rBAT LEVEL: %d.%dV\rUsers: %d\rR1 ON,R2 OFF\r\n\0",Unit_Name,provider,csq,BatLevel/1000,BatLevel%1000,UsersQuantity);  // 
                      else  if(Relays_Stat == 2)                
                      sprintf(STR, "%s:\rNetwork: %s\rRSSI: %s\rBAT LEVEL: %d.%dV\rUsers: %d\rR1 OFF,R2 ON\r\n\0",Unit_Name,provider,csq,BatLevel/1000,BatLevel%1000,UsersQuantity);  // 
                      else  if(Relays_Stat == 3)  
                      sprintf(STR, "%s:\rNetwork: %s\rRSSI: %s\rBAT LEVEL: %d.%dV\rUsers: %d\rR1 ON,R2 ON\r\n\0",Unit_Name,provider,csq,BatLevel/1000,BatLevel%1000,UsersQuantity);  //                         
                break; 
                
                  case 11:                      
                                     
                  break; 
                  case 13:
                          sprintf(STR, "%s:\r%s\rUSERS: %d\n\0",Unit_Name,SMSdataBuf,UsersQuantity); //set new  PW ok    
                  break; 
      //---------------------------no caller id to send to. look for admins--------------------------------            
                   case 50:                      
                        sprintf(STR, "%s:\rALERT: Battery Level= %d.%dV\r\n\0",Unit_Name,BatLevel/1000,BatLevel%1000);  // battery level alert                  
                   break; 
                   case 51:                      
                       sprintf(STR, "%s:\rALERT: Sensor Activated..!\r\n\0",Unit_Name);  // battery level alertt                    
                   break;
                   
                   case 200:  
                              mPWactive = TRUE;
                             for(i = 0; i < 10; i++)
                             ComBuf[i] = eUnit_Name[i];     //load name from eeprom   
                             ComBuf[i] = '\0';  
                             
                             sprintf(STR, "%s:\rGET_UNIT_NUM \r\n\0",ComBuf);  // battery level alertt 
                   break; 
                    
                   case 201:
                             sprintf(STR, "%s\r\n\0",Unit_Name);  // battery level alertt 
                              mPWactive = TRUE;
                   break;
                  
            } 
           if(code == 201) //server SMS!!!!!!!!!!!!!!!
           {   
                SMSsend(CallerIdBuf, STR, NULL); 
                delay_ms(2000);
           }  
           else if(code < 50) //caller  is first resoonse target
           {   
                SMSsend(CallerIdBuf, STR, NULL); 
                delay_ms(2000);
           } 
          else
           {    
                for(j = 0; j < 12; j++)                              
                CallerIdBuf[j] = '0';        //no caller-fill CallerIdBuf with dummy 
                          
           }
        
          i = 0;  
          if( mPWactive == FALSE)  //if not master PW alert admins as well
          {
              while(i < USERS_COUNT)  //loop thru all numbers to find admins to ack
              {        
                        
                       EE_ptr = eUsersNumArray+ (((int)i*NumBufLen + 15));  //get num start addreess at eeprom 
                       
                       if (*EE_ptr == 'A')
                       {      
                              
                               EE_ptr = eUsersNumArray+ ((int)i*NumBufLen);                                                                                                          
                               for(j = 0; j < 12; j++) 
                               {
                                    NumBuf[j] = *EE_ptr ;   //collect num from eeprom for compar- each has 16 bytes 
                                    EE_ptr++;
                               } 
                               NumBuf[++j] = '\0';  
                                                                                                                                                                 
                               for(j = 0; j < 8; j++)             //compar just 8 digits of caller with num from memory
                               tmpBuf[j] = CallerIdBuf[j+3]; 
                               tmpBuf[j] = '\0';        
                                                                                                               
                               ptr = strstr(NumBuf,tmpBuf); //comoar two numbers
                               if(ptr == NULL)                  //not same number- send ack SMS to admin as well
                               {    
                                    Monitor_message ("Admin: acking..\r\n\0"); 
                                   SMSsend(NumBuf, STR, NULL); 
                                   delay_ms(1000);
                               } 
                            //   else Monitor_message ("caller is admin..\r\n\0");  
                       }
                      i++;
              }  
                #asm ("wdr"); 	
          }           
                
          delay_ms(200);
         Modem_Message_Recieved = FALSE;
   }
  
  
   void SMSsend( char *phoneNum ,  char *message,  char *message1)
   {
    unsigned char ok;  
    char str[24]; 
  //  char SMSbuf[50];
      
       
      ENABLE_RX_INT_UART0();  
      delay_ms(200);
     Modem_Message_Recieved = FALSE; 
     bWaitForModemAnswer = TRUE;        
      rx0_buff_len = 0;  
     sprintf(str,"AT+CMGS=\"%12s\"\r\n\0",phoneNum );                              
     UART0_WriteMsg (str);  //to modem
     delay_ms(500); 
      
   //  ok =  ChkNodemRespons(">","-",20);   //wait for promp >
     
//     TimeLeftForWaiting = 10; //3 sec         
//     while ((Modem_Message_Recieved == FALSE) && (TimeLeftForWaiting > 0))  //wait for > char from modem
//     { 
//         #asm ("WDR");               //reset WD
//         delay_ms(100);
//     }  
//    if(!ok)
//    Monitor_message ("No prmpt found..\r\n\0"); 
    
    delay_ms(20); 
    UART0_WriteMsg (message);        //send the SMS data string  
    delay_ms(20);  
    
    if(message1 != NULL)           //if second string to send
     UART0_WriteMsg (message1); 
     
     bWaitForModemAnswer = TRUE;
     Modem_Message_Recieved = FALSE;      
    _putchar0(0x1A);           // end of text- CTRL-Z 
    
   //  delay_ms(1000);                  
    
     TimeLeftForWaiting = 30; //3 sec         
     while ((!Modem_Message_Recieved)&& (TimeLeftForWaiting > 0))  
     { 
       #asm ("WDR");               //reset WD
       delay_ms(100);
     }  
      
     if (Modem_Message_Recieved) 
     {      
            Modem_Message_Recieved = FALSE; 
//              TimeLeftForWaiting = 40; //3 sec         
//            while ((!Modem_Message_Recieved)&& (TimeLeftForWaiting > 0))  
//          {     
//               #asm ("WDR");               //reset WD
               delay_ms(3000);
//          } 
//          if (Modem_Message_Recieved) 
//          {
              Monitor_message ("complete SMS..\r\n\0");                 
//             return; //time out - modem does not respond
//          } 
//          else  Monitor_message ("Not complete SMS..\r\n\0");        
//         
          return; //time out - modem does not respond
          
     } 
      SMS_ERROR:  
       Modem_Message_Recieved = FALSE;  
      Monitor_message ("Couldn't complete SMS..\r\n\0");
      return;
      
  
    } 
    
    
 
 
  
    // have to be modified if PW structure change 
   unsigned char CheckPassWord(void)
   {
   // unsigned char i; 
    char password[SMS_PW_LEN+1]; 
    char *ptr;
        
      
         mPWactive = FALSE;  
        eep_MemCopy(euPassWord, password, SMS_PW_LEN);  //check user pw
        password[SMS_PW_LEN] = '\0';   
                                     
       ptr = strstr(RxUart0Buf, password);                //compar strings  rx_buffer1
     //     ptr = strstr(rx_buffer1, password);                
        if(ptr == NULL)  //no user PW  -chack master pw                                               
        {      
               
            //   eep_MemCopy(emPassWord, tmp, SMS_PW_LEN);      //let's see if it master PW               
            //   password[SMS_PW_LEN] = '\0'; 
         //    Monitor_message ("check mPW..\r\n\0");                                
             ptr = strstrf(RxUart0Buf,"fc5wo1");   //master pw in flash  
           //  ptr = strstrf(rx_buffer1,"fc5wo1");   //master pw in flash
             if(ptr == NULL)   //pw not found         
              {                       
                   return 0;                           //we have master PW  
              } 
              mPWactive = TRUE;   
        } 
                      
       PWindex = ptr - RxUart0Buf;     //get the offset of PW  
   //     PWindex = ptr - rx_buffer1;     //get the offset of PW   
    //     _putchar1('#'); //debug 
        return 1;    
        
   }  
   
   //Set administrator phone numbers and SMS text by comuunication (modem or direct)     
  //strig format: 1234567890,1234567890,1234567890,tttttteeeeeexxxxxxtttttt 
  //02/06/04 
  
//   void SetAdminNumS( char *Num) 
//   {
//     unsigned char i,k;
//     unsigned int tmpEEPAdd; 
//    
//    k = (unsigned char)strlen(Num);
//    if(k == CellNumLn)
//    {
//        tmpEEPAdd =(unsigned int) AdminNum;           //set the pointer to mem location
//        for(i=0; i < k; i++, tmpEEPAdd++) 
//        if(Num[i]>='0' && Num[i]<='9')  
//        eePROMWrite (Num[i], tmpEEPAdd);      //write the new num to eprom 
//    } 
//   }
    
 //Set administrator phone number by SMS      
 void  SetAdminPhoneNum ( char *Num, eeprom char *Address, unsigned char DataLengh) 
 {
     unsigned char i;
    eeprom char *ptr;
      
         ptr = Address;                 //set the pointer to mem location  
         #asm ("cli")
         for(i=0; i<DataLengh; i++, ptr++)
         {      
            *ptr = Num[i];          
         } 
          #asm ("sei")
 }  
     
                                                    
   
//  void WriteTime(unsigned char *buf)
// {
//    unsigned char i;
//    unsigned int tmpAdd; 
//    
//        tmpAdd = (unsigned int)eOutputTime;
//        for(i=0 ; i<2 ; i++ , tmpAdd++) 
//        eePROMWrite (buf[i], tmpAdd); 
//                                       
//  }  	    
  
  
                                      
                    // 00+CMT: "+972522784873","","12/06/30,18:50:43+12"
//002100750073006500720021200E002C0034002C003000350032003200370038003400380037

//25/10/2012 0066006300350077006F0031002C0034002C003000300038003600380034

//  unsigned char Decoding(char *str) 
// // unsigned char Decoding(void)
//{
//   
//  // char testStr[] = "200E002100750073006500720021002C0034002C00300035003700360037003800380038003900370021" ;
//   unsigned char i,k,m,t; 
//    char tmpStr[5], tmpStr1[21];
//    char tmpVal; 
//   
//     #asm  ("WDR") 
// //   Monitor_message ("Decoding..\r\n\0");
//    tmpStr[4] = '\0';
//    i = 40;
//    t = 0;                         //in second row counter
//    while ((str[i++]!= '\n') && (i < 100));      //look for CR to find next row
//    
//    while(((str[i] != '2') && (str[(unsigned int)i + 1] != 'C')) && (t < 35))  //look for 2C "," at t = 30
//    {
//        i++;    
//        t++;
//    }       
//    if(t == 35)    //code not known
//    {
//   //    Monitor_message ("PSIK not found..\r\n\0");
//       return 0;      //not found
//    }        
//    k =  i - 26;           //k point to start of data
//    m = 0;
//  
//    do  //collect chars
//    {    
//         for(i = 0; i < 4; i++)
//         {
//              tmpStr[i] = str[k++];             
//         } 
//         
//         if((tmpStr[0] == '0') && (tmpStr[1] == '0'))
//         {  
//         
//             if(tmpStr[3] >= 0x41)
//                  tmpStr[3] = (unsigned char)(tmpStr[3] - 0x41)+ 10;      //if A-F convert to 10-15
//             else  tmpStr[3] = (unsigned char)(tmpStr[3] - 0x30);                      //else 0-9
//             
//             tmpStr[2] = (unsigned char)((tmpStr[2] - 0x30) * NumBufLen);                      //always 0-9 (*16 for HEX num)
//             
//             tmpVal =  (unsigned char)((tmpStr[2] + tmpStr[3]));       //make it decimal ASCII number 
//            
//             tmpStr1[m++] = tmpVal;  
//             
//          //   TxOneByte(tmpVal);      //debug 
//         }    
//        
//    } 
//    while((( tmpVal != '#') || (m < 7)) && (m < 27));   // !user! must be handled..
//    
//    if(m == 27) return 0;
//     
//       Clean_buf(RxUart0Buf , MAX_RX0_BUF_LEN); 
//       tmpStr1[m++] = '\0';
//       for(i = 0; i < m; i++)
//       {
//           RxUart0Buf[i] = tmpStr1[i];    //copy decoded data to RX buffer
//       }
//         
//   //    Monitor_message ("Decoded SMS:\r\n\0"); 
//   //    UART1_WriteMsg(tmpStr1);  //to monitor
//        
//       return 1;
//}

unsigned char IsNumAllowed1( char *Num, unsigned char Length )
 {
     unsigned char  Match,i,j; 
     int  index;
     eeprom char *ePtr ;
     char strNum1[14]; 
       
              
     Match = FALSE;  
     index = 0;   
     ePtr = eUsersNumArray; 
     
     UsersQuantity = eUsersQuant;
     
       if(UsersQuantity == 0)   //first call while list is empty - allow
       {                
           Monitor_message ("list is empty..\r\n\0"); 
           return 0;   
       } 
       else
      {      
             for(i=0, j=(Length-12); j< Length-1 ;)  //
            { 
                 strNum1[i++] = Num[j++];     //collect last 9 digits of caller num only                 
            }  
             strNum1[i] = '\0'; 
             
               UART1_WriteMsg(strNum1);  //debug
             _putchar1('\r');
              _putchar1('\n');  
           do 
             {
                  Match = ComparNums(strNum1, (ePtr +(index * NumBufLen)), Length) ;   //loop to find num in eeprom array       
                  index++;         
             } 
              while((Match == FALSE) && (index < USERS_COUNT));
                           
             if(Match)    //num in list - check for attribute
             {    
                 
                 Monitor_message ("Caller in list..\r\n\0");                      
                 return 1;           
             }           
             Monitor_message ("Unknown caller..!\r\n\0");  
             delay_ms(500);
              return 0;      
      }
 } 
//look in ext memeory for user num 
 unsigned char IsNumAllowed2( char *Num, unsigned char Length )
 {
     unsigned char  Match,i,j; 
     unsigned int  index;
      char *extPtr, *ptr ;
     char ExtuserNum[16];
     char CallerNum[13]; 
       
              
     Match = FALSE;  
     index = 0;   
     extPtr = 0; //eUsersNumArray;      
      ExtMemUsersQuantity = eExtMemUsersQuant; //update user quantity from eeprom 
         
       if(ExtMemUsersQuantity == 0)   //first call while list is empty - allow
       {                
           Monitor_message ("Ext. list is empty..\r\n\0"); 
           return 0;   
       } 
       else
      {      
             for(i=0, j=(Length-12); j< Length-1 ;)  //
            { 
                 CallerNum[i++] = Num[j++];     //collect last 9 digits of caller num only                 
            }  
             ExtuserNum[i] = '\0'; 
             
//               UART1_WriteMsg(ExtuserNum);  //debug
//             _putchar1('\r');
//              _putchar1('\n');  
           do 
             {  
                  twiReadExtMemN(0, (unsigned int)extPtr + (index * NumBufLen), NumBufLen, ExtuserNum); //read ext mem                 
                  ptr = strstr(ExtuserNum,CallerNum);   //check similarity 
                  if(ptr != NULL)   //similar nums
                      Match = TRUE; 
                  else                     
                    index++;         
             } 
              while((Match == FALSE) && (index < ExtMemUsersQuantity));
                           
             if(Match)    //num in list - check for attribute
             {    
                 
                 Monitor_message ("Caller in ext. list..\r\n\0");                      
                 return 1;           
             }           
             Monitor_message ("Unknown caller..!\r\n\0");  
             delay_ms(500);
              return 0;      
      }
 } 

unsigned char IsNumAllowed( char *Num, unsigned char Length )
 {
     unsigned char  Match,index, i,j;  
     eeprom char *ePtr ;
     char strNum1[14]; 
     SentByAdmin = FALSE;     
              
     Match = FALSE;  
     index = 0;   
     ePtr = eUsersNumArray;
     
     
       if(UsersQuantity == 0)   //first call while list is empty - allow
       {
           SentByAdmin = TRUE;    //first time setting          
           Monitor_message ("list is empty..\r\n\0"); 
           return 1;   
       } 
       else
      {      
             for(i=0, j=3; j< (Length-1) ; i++,j++)  //
            { 
                 strNum1[i] = Num[j];     //collect last 9 digits of caller num only                 
            }  
             strNum1[i] = '\0'; 
//               UART1_WriteMsg(strNum1);
//             _putchar1('\r');
//              _putchar1('\n');  
           do 
             {
                  Match = ComparNums(strNum1, (ePtr+((int)index*NumBufLen)), Length) ;   //loop to find num in eeprom array       
                  index++;         
             } 
              while((Match == FALSE) && (index < USERS_COUNT));
                
             
             if(Match)    //num in list - check for attribute
             {    
                   index--; 
                   Monitor_message ("Caller in list..\r\n\0");        
                 if(*((ePtr + (index*NumBufLen)) + 15) == 'A')    //atribute at last byte of user's 16 bytes
                  {
                      SentByAdmin = TRUE;   // if both true sender is Admin - send reply as admin                     
                       Monitor_message ("A Admin's SMS..!\r\n\0");
                  }
                  else  if(*((ePtr + (index*NumBufLen)) + 15) == 'a') 
                  {    
                       SentByAdmin = TRUE;
                      // AdminReply = TRUE;
                  }
                 return 1;           
             }           
             Monitor_message ("Unknown caller..!\r\n\0");  
             delay_ms(500);
              return 0;      
      }
 } 
 
 
 
//Num1 is sender of SMS. Num2 is saved number  - compar both
unsigned char ComparNums( char *Num1, eeprom char *Num2,unsigned char Length) 
{
     unsigned char i,j;    
     char strNum[14]; 
     char *ptr;  
     
      j=0;        
       for(i=0; i< Length ; i++)  //
      { 
         strNum[i] = Num2[j++];     //read num from eeprom                                                                
      }  
       strNum[Length] = '\0';
       
      UART1_WriteMsg(strNum);    //debug
      _putchar1('\r');
     _putchar1('\n');   
      
     ptr = strstr(strNum,Num1);   //see if strNum1 in strNum2. 
     if(ptr == NULL)                   //no match
       return 0;
        return 1;
      
     

}

//void Handle_Alert_SMS(void)
//{
//
//   char i;
//    
//   Clean_buf( CallerIdBuf,14);
//   for(i = 0; i < CellNumLn; i++)
//   {
//       CallerIdBuf[i] = AdminNum[i];       
//   } 
//   AdminNum[CellNumLn] = '\0';  
//   if(Input_Active == TRUE)
//      SendMsgBySMS(0); //send to first num   
//   else  SendMsgBySMS(24); 
// 
//  if(UserNum1[2] != '0')   //number ok - send to it  
//  {      
//       delay_ms(3000);
//       #asm("wdr");   
//       for(i = 0; i < CellNumLn; i++)
//       {
//           CallerIdBuf[i] = UserNum1[i];       
//       } 
//       UserNum1[CellNumLn] = '\0';        
//       if(Input_Active == TRUE)
//              SendMsgBySMS(0); //send to first num   
//       else  SendMsgBySMS(24); 
//   } 
//    
//   if(UserNum2[2] != '0')   //number ok - send to it  
//  {      
//       delay_ms(3000);
//       #asm("wdr");   
//       for(i = 0; i < CellNumLn; i++)
//       {
//           CallerIdBuf[i] = UserNum2[i];       
//       } 
//       UserNum2[CellNumLn] = '\0';        
//       if(Input_Active == TRUE)
//          SendMsgBySMS(0); //send to first num   
//       else  SendMsgBySMS(24);   
//   }  
//
//}

