/*
 * ui.c
 *
 *  Created on: Jan 6, 2013
 *      Author: boaz
 */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "define.h"
#include "uart.h"
//#include "reg.h"
//#include "param.h"
//#include "mytype.h"
#include "rtc.h"
#include "ui.h"

#define TMP_SENSOR 0
#define PH_SENSOR 1
#define EC_SENSOR 2
#define LEVEL_SENSOR 3


int ui_main_menu(int);
int ui_show_current_settings(int);
int ui_unit_configuration(int);
int ui_input_sensor_config(int);
int ui_sensor_type_config(int ui_select);
void sensor_type_config(uint16_t type);
int ui_pump_config(int ui_select);
int ui_pump_manual_operation(int ui_select);
int ui_pump_state_config(int ui_select);
//void analog_threshold_config(void);
extern uint16_t UARTGetBin(void);
extern void putchar0(char c);
extern unsigned int GetStatusReg(unsigned int mask);

void print_logo(void);
void print_monitor_mode_message(void);
void show_temp_limit_highTH(void);
void show_ph_limit_lowTH(void);
void show_ph_limit_highTH(void);
void show_ph_emergency_lowTH(void);
void show_ph_emergency_highTH(void);
void show_conductivity_limit_highTH(void);
void show_conductivity_emergency_highTH(void);
void show_sampling_frequancy(void);

void set_temp_limit_highTH(void);
void set_ph_limit_lowTH(void);
void set_ph_limit_highTH(void);
void set_ph_emergency_lowTH(void);
void set_ph_emergency_highTH(void);
void set_conductivity_limit_highTH(void);
void set_conductivity_emergency_highTH(void);
void set_sampling_frequancy(void);



//UI menu options
#define MAIN_MENU                   0x00
//#define FIRST_RUN_CONFIGURATION     0x01   // ???
#define SHOW_CURRENT_SETTINGS       0x01
#define UNIT_CONFIGURATION          0x02
//#define TIME_DATE_CONFIG            0x03   // ???
#define INPUT_SENSOR_CONFIG         0x03
#define SENSOR_TYPE_CONFIG          0x04
#define PUMP_CONFIG                 0x05
#define PUMP_MANUAL_OPERATION       0x06
#define PUMP_STATE_CONFIG           0x07

#define ESC 0x1b 

flash char sTemp[] = "Temperature ";
flash char sPH[] = "PH ";
flash char sConductivity[] = "Conductivity ";
flash char sWL[] = "Water-level ";
flash char sLimit[] = "limit ";
flash char sEmergency[] = "emergency "; 
flash char sHighTH[] = "high-threshold";
flash char sLowTH[] = "low-threshold";
flash char* units[] = {" (celsius): ", ": ", " (uS): ", " (cm): ", " (fahrenheit): ", " (m): " };

extern eeprom int MIN_LIMIT[MAX_SEN_NUM];
extern eeprom int MAX_LIMIT[MAX_SEN_NUM];
extern eeprom int PUMP_MIN_LIMIT[MAX_SEN_NUM];
extern eeprom int PUMP_MAX_LIMIT[MAX_SEN_NUM];
extern eeprom char cpue2_interval_1;



typedef int (*ui_menu)(int);

const ui_menu ui_vec[] = {
	ui_main_menu,			   		// MAIN_MENU                   0x00
	ui_show_current_settings,  		// SHOW_CURRENT_SETTINGS       0x01
	ui_unit_configuration,     		// UNIT_CONFIGURATION          0x02
	ui_input_sensor_config,    		// INPUT_SENSOR_CONFIG         0x03
	ui_sensor_type_config,          // SENSOR_TYPE_CONFIG          0x04
    ui_pump_config,                 // PUMP_CONFIG                 0x05 
    ui_pump_manual_operation,       // PUMP_MANUAL_OPERATION       0x06 
    ui_pump_state_config,           // PUMP_STATE_CONFIG           0x07    
};

int ui_select = MAIN_MENU;

void ui_main_loop(void){
     WDT_off();     
     print_logo(); 
     print_monitor_mode_message();
    
//	if(GetStatusReg(UNCONFIG_UNIT))
//		ui_select = FIRST_RUN_CONFIGURATION;
//	else
//		TxMsg("\r\nLASU menu, please choose from the options below:\r\n\0");
        
	while(TRUE){
		ui_select = ui_vec[ui_select](ui_select);
	}
}

int ui_main_menu(int ui_select) {

	char input; 
        
    TxMsg("\x1b[31;4m\0"); // underline red
	TxMsg("\r\nMain menu:\r\n\0");
	TxMsg("\x1b[30;24m\0"); // cancel underline red	
	TxMsg("1. Show current settings and status\r\n\0");
	TxMsg("2. Setup and configuration\r\n\0");
	TxMsg("3. Pump manual operation\r\n\0");

	input = getchar();
    
	switch(input)
	{        
		case '1':
			ui_select = SHOW_CURRENT_SETTINGS;
		break;

		case '2':
			ui_select = UNIT_CONFIGURATION;
		break;

		case '3':
			ui_select = PUMP_MANUAL_OPERATION;
		break;   
        
       TxByte(input);  //debug  
    
	}
    TxMsg("\x1b[2J\0");
    return ui_select;
}

//int ui_first_run_configuration(int ui_select) {
//	TxMsg("\nWelcome to LASU first run configuration\r\n\0");
//	TxMsg("Please follow the menu below:\r\n\0");
//    
//    FirstRunInit();
//
//	SetStatusReg(UNCONFIG_UNIT, 0);
//
//	ui_select = UNIT_CONFIGURATION;
//	return ui_select;
//}

int ui_sensor_type_config(int ui_select) {
    
    return 0;
}


int ui_pump_config(int ui_select) {
    
    TxMsg("Pump configuration...\r\n\0"); 
    delay_ms(2000);
    return MAIN_MENU;
}

int ui_pump_manual_operation(int ui_select) {
    
    char c;
    int activated_time;
    TxMsg("\x1b[31;4m\0"); // underline red
	TxMsg("\r\nPump manual operation\r\n\0");
	TxMsg("\x1b[30;24m\0"); // cancel underline red    	    
    
    TxMsg("\r\nHit Esc for back to Main Menu or any other key for Pump operation...\r\n\0");
	c = getchar();

	if(c != ESC){
        activated_time = 45; //(int)PUMP_ACTIVE_DURATION;
      //  TxMsg("Activated duration (sec):\0"); 
        
         TxMsg("Pump activation must be re written\0");
      //  PrintNum((long)activated_time);        
        TxMsg("Pump is activated...\r\n\0");
        //ActivePump(PUMP_ACTIVE_DURATION);
      //  ActivePump(activated_time);
        //return PUMP_MANUAL_OPERATION;
        return MAIN_MENU;	    
    }
	else{        
	    TxMsg("Pump activation was cancelled!\r\n\0");
        return MAIN_MENU;
    }
}

int ui_pump_state_config(int ui_select) {

    TxMsg("Pump state configuration...\r\n\0");
    delay_ms(2000);
    return MAIN_MENU;        
}

int ui_show_current_settings(int ui_select) {
       
	TxMsg("\x1b[34;1m\r\0");
    TxMsg("\x1b[4m\0"); // underline
	TxMsg("current settings:\r\n\0"); 
	TxMsg("\x1b[34;24m\0"); // cancel underline blue
    TxMsg("\x1b[22m\0");
    RTCgetTime();
    RTCgetDate();
    //temperature
    show_temp_limit_highTH();
    //PH
    show_ph_limit_lowTH();
    show_ph_limit_highTH();
    show_ph_emergency_lowTH();
    show_ph_emergency_highTH();
    //Conductivity
    show_conductivity_limit_highTH();
    show_conductivity_emergency_highTH();
    show_sampling_frequancy();
    
    return MAIN_MENU;
}


int ui_unit_configuration(int ui_select) {
    
	char input; 
        
    TxMsg("\x1b[31;4m\0"); // underline red
	TxMsg("\r\nUnit configuration:\r\n\0");
	TxMsg("\x1b[30;24m\0"); // cancel underline red	
	TxMsg("1. Set Temperature limit high-threshold\r\n\0");
	TxMsg("2. Set PH limit low-threshold\r\n\0");
	TxMsg("3. Set PH limit high-threshol\r\n\0");
    TxMsg("4. Set PH emergency low-threshol\r\n\0");
    TxMsg("5. Set PH emergency high-threshol\r\n\0");
	TxMsg("6. Set Conductivity limit high-threshol\r\n\0");
    TxMsg("7. Set Conductivity emergency high-threshol\r\n\0"); 
    TxMsg("8. Set sampling frequancy\r\n\0");   

	input = getchar();
    
	switch(input)
	{        
		case '1':
			set_temp_limit_highTH();
		break;

		case '2':
			set_ph_limit_lowTH();
		break;

		case '3':
			set_ph_limit_highTH();
		break;
        
		case '4':
			set_ph_emergency_lowTH();
		break;
        
		case '5':
			set_ph_emergency_highTH();
		break;
        
		case '6':
			set_conductivity_limit_highTH();
		break;
        
		case '7':
			set_conductivity_emergency_highTH();
		break;
        
		case '8':
			set_sampling_frequancy();
		break;        
        
        case ESC:
            ui_select = MAIN_MENU;
        break;                                                   
        
       TxByte(input);  //debug  
    
	}
    //TxMsg("\x1b[2J\0");
    return ui_select;
}

int ui_input_sensor_config(int ui_select) {
    
    TxMsg("Input sensor configuration...\r\n\0");
    delay_ms(2000);
    return MAIN_MENU;
}


void show_temp_limit_highTH(void){
    int tVal;
    TxMsg(sTemp );
    TxMsg(sLimit);
    TxMsg(sHighTH);
    TxMsg(units[TMP_SENSOR]);

    tVal = MAX_LIMIT[TMP_SENSOR];     
    PrintNum((long) tVal/10);   //show temp value
}

void show_ph_limit_lowTH(void){
    int tVal;
    TxMsg(sPH );
    TxMsg(sLimit);
    TxMsg(sLowTH);
    TxMsg(units[PH_SENSOR]); 
    tVal = MIN_LIMIT[PH_SENSOR]; 
    PrintNum((long) PHcalc(tVal));
}

void show_ph_limit_highTH(void){
    int tVal;
    TxMsg(sPH );
    TxMsg(sLimit);
    TxMsg(sHighTH);
    TxMsg(units[PH_SENSOR]);
    tVal = MAX_LIMIT[PH_SENSOR]; 
    PrintNum((long) PHcalc(tVal));
}

void show_ph_emergency_lowTH(void){
    int tVal;
    TxMsg(sPH );
    TxMsg(sEmergency);
    TxMsg(sLowTH);
    TxMsg(units[PH_SENSOR]);
    tVal = PUMP_MIN_LIMIT[PH_SENSOR]; 
    PrintNum((long) PHcalc(tVal));
}

void show_ph_emergency_highTH(void){
    int tVal;
    TxMsg(sPH );
    TxMsg(sEmergency);
    TxMsg(sHighTH);
    TxMsg(units[PH_SENSOR]);
    tVal = PUMP_MAX_LIMIT[PH_SENSOR]; 
    PrintNum((long) PHcalc(tVal));
}

void show_conductivity_limit_highTH(void){
    int tVal;
    TxMsg(sConductivity);
    TxMsg(sLimit);
    TxMsg(sHighTH);
    TxMsg(units[EC_SENSOR]);
    tVal = MAX_LIMIT[EC_SENSOR]; 
    PrintNum((long) ECcalc(tVal));
}

void show_conductivity_emergency_highTH(void){
    int tVal;
    TxMsg(sConductivity);
    TxMsg(sEmergency);
    TxMsg(sHighTH);
    TxMsg(units[EC_SENSOR]);
    tVal = PUMP_MAX_LIMIT[EC_SENSOR]; 
    PrintNum((long) ECcalc(tVal));
}

void show_sampling_frequancy(void){
    int tVal;
    
    TxMsg("Sampling frequancy (min): \0");
    tVal = cpue2_interval_1;     
    PrintNum((long)cpue2_interval_1*5);   //show temp value
}


void set_temp_limit_highTH(void){
    int tVal;
    char c;
    TxMsg("\x1b[2J\0");  // clear screen
    TxMsg("\x1b[34m\0"); // set color blue
    show_temp_limit_highTH();
    TxMsg("\x1b[30m\0");
    TxMsg("\r\nPlease enter a new value:");
    tVal = UART_GetNum();
    TxMsg("\r\nHit Esc to cancell or any other key to continue...\r\n\0");
	c = getchar();

	if(c != ESC){
        MAX_LIMIT[TMP_SENSOR] = (tVal*10);
	    TxMsg("New value is set\r\n\0");
    }
	else        
	    TxMsg("Set new value was cancelled!\r\n\0"); 
    delay_ms(500);
}

void set_ph_limit_lowTH(void){
    int tVal;
    char c;
    TxMsg("\x1b[2J\0");  // clear screen
    TxMsg("\x1b[34m\0"); // set color blue
    show_ph_limit_lowTH();
    TxMsg("\x1b[30m\0");
    TxMsg("\r\nPlease enter a new value:");
    tVal = UART_GetNum();
    TxMsg("\r\nHit Esc to cancell or any other key to continue...\r\n\0");
	c = getchar();

	if(c != ESC){
        MIN_LIMIT[PH_SENSOR] = PH_mV_calc(tVal);
	    TxMsg("New value is set\r\n\0");
    }
	else        
	    TxMsg("Set new value was cancelled!\r\n\0"); 
    delay_ms(500);
}

void set_ph_limit_highTH(void){
    int tVal;
    char c;
    TxMsg("\x1b[2J\0");  // clear screen
    TxMsg("\x1b[34m\0"); // set color blue
    show_ph_limit_highTH();
    TxMsg("\x1b[30m\0");
    TxMsg("\r\nPlease enter a new value:");
    tVal = UART_GetNum();
    TxMsg("\r\nHit Esc to cancell or any other key to continue...\r\n\0");
	c = getchar();

	if(c != ESC){
        MAX_LIMIT[PH_SENSOR] = PH_mV_calc(tVal);
	    TxMsg("New value is set\r\n\0");
    }
	else        
	    TxMsg("Set new value was cancelled!\r\n\0"); 
    delay_ms(500);
}

void set_ph_emergency_lowTH(void){
    int tVal;
    char c;
    TxMsg("\x1b[2J\0");  // clear screen
    TxMsg("\x1b[34m\0"); // set color blue
    show_ph_emergency_lowTH();
    TxMsg("\x1b[30m\0");
    TxMsg("\r\nPlease enter a new value:");
    tVal = UART_GetNum();
    TxMsg("\r\nHit Esc to cancell or any other key to continue...\r\n\0");
	c = getchar();

	if(c != ESC){
        PUMP_MIN_LIMIT[PH_SENSOR] = PH_mV_calc(tVal);
	    TxMsg("New value is set\r\n\0");
    }
	else        
	    TxMsg("Set new value was cancelled!\r\n\0"); 
    delay_ms(500);
}

void set_ph_emergency_highTH(void){
    int tVal;
    char c;
    TxMsg("\x1b[2J\0");  // clear screen
    TxMsg("\x1b[34m\0"); // set color blue
    show_ph_emergency_highTH();
    TxMsg("\x1b[30m\0");
    TxMsg("\r\nPlease enter a new value:");
    tVal = UART_GetNum();
    TxMsg("\r\nHit Esc to cancell or any other key to continue...\r\n\0");
	c = getchar();

	if(c != ESC){
        PUMP_MAX_LIMIT[PH_SENSOR] = PH_mV_calc(tVal);
	    TxMsg("New value is set\r\n\0");
    }
	else        
	    TxMsg("Set new value was cancelled!\r\n\0"); 
    delay_ms(500);
}

void set_conductivity_limit_highTH(void){
    int tVal;
    char c;
    TxMsg("\x1b[2J\0");  // clear screen
    TxMsg("\x1b[34m\0"); // set color blue
    show_conductivity_limit_highTH();
    TxMsg("\x1b[30m\0");
    TxMsg("\r\nPlease enter a new value:");
    tVal = UART_GetNum();
    TxMsg("\r\nHit Esc to cancell or any other key to continue...\r\n\0");
	c = getchar();

	if(c != ESC){
        MAX_LIMIT[EC_SENSOR] = EC_mV_calc(tVal);
	    TxMsg("New value is set\r\n\0");
    }
	else        
	    TxMsg("Set new value was cancelled!\r\n\0"); 
    delay_ms(500);
}

void set_conductivity_emergency_highTH(void){
    int tVal;
    char c;
    TxMsg("\x1b[2J\0");  // clear screen
    TxMsg("\x1b[34m\0"); // set color blue
    show_conductivity_emergency_highTH();
    TxMsg("\x1b[30m\0");
    TxMsg("\r\nPlease enter a new value:");
    tVal = UART_GetNum();
    TxMsg("\r\nHit Esc to cancell or any other key to continue...\r\n\0");
	c = getchar();

	if(c != ESC){
        PUMP_MAX_LIMIT[EC_SENSOR] = EC_mV_calc(tVal);
	    TxMsg("New value is set\r\n\0");
    }
	else        
	    TxMsg("Set new value was cancelled!\r\n\0"); 
    delay_ms(500);
}


void set_sampling_frequancy(void){
    int tVal;
    char c;
    TxMsg("\x1b[2J\0");  // clear screen
    TxMsg("\x1b[34m\0"); // set color blue
    show_sampling_frequancy();
    TxMsg("\x1b[30m\0");
    TxMsg("\r\nPlease enter a new value (in 5 minuts resolution):");
    tVal = UART_GetNum();
    TxMsg("\r\nHit Esc to cancell or any other key to continue...\r\n\0");
	c = getchar();

	if(c != ESC){
        cpue2_interval_1 = (tVal)/5;
	    TxMsg("New value is set\r\n\0");
    }
	else        
	    TxMsg("Set new value was cancelled!\r\n\0"); 
    delay_ms(500);
}    

//input: PH value
//return mV 
//mV = 1600/14 * value +400
int PH_mV_calc(int value)
{
    int mVdata;
    
    mVdata = (value * 114) + 400;
   return mVdata; 

}

//input: mV for certain PH value
//return PH val 
//(mV- 400) * 14 / 1600
int PHcalc(int value)
{
    int mVdata;
    
    mVdata = (value -400) * 14.3;
   return mVdata / 1600; 

}

//input: mV for certain EC value
//return EC val 
//(mV- 400) * 14 / 1600
int ECcalc(int value)
{
    int mVdata;
    int tmp; 
    
    tmp = value;
    if (tmp < 400)
    tmp = 400;   
    mVdata = (tmp -400) * 62.5;
   return  mVdata ; 

}

//input: EC value
//return mV 
//mV = 1600/100000 * value +400
int EC_mV_calc(int value)
{
    int mVdata, tVal;
    
    tVal = (value * 16);  
    mVdata  = tVal/1000;
   return mVdata + 400; 

}
 unsigned int STR2BIN(unsigned char *str)
 {
  
  unsigned int BinTmp;
 
      BinTmp = (unsigned int)(str[4]-0x30); 
      BinTmp += (unsigned int)(str[3]-0x30)*10; 
      BinTmp += (unsigned int)(str[2]-0x30)*100;
      BinTmp += (unsigned int)(str[1]-0x30)*1000; 
      BinTmp += (unsigned int)(str[0]-0x30)*10000; 
      
      return BinTmp;
  } 

/*
int ui_show_current_settings(int ui_select) {

	int input;

	TxMsg("\x1b[34;1m\r\0");
    TxMsg("\x1b[4m\0"); // underline
	TxMsg("current settings:\r\n\0"); 
	TxMsg("\x1b[34;24m\0"); // cancel underline blue
    TxMsg("\x1b[22m\0"); 
    RTCgetTime();
	RTCgetDate(); 
    TxMsg("\r\n\0");   
	
	input = GetStatusReg(INPUT_SENS_TYPE);

	switch(input)
	{
		case SINGLE_RELAY_INPUT:
			TxMsg("Unit sensor type: single dry contact input.\r\n\0");
		break;

		case DUAL_RELAY_INPUT:
			TxMsg("Unit sensor type: dual dry contact inputs.\r\n\0");
		break;

		case LASU_POWERED_4_20:
			TxMsg("Unit sensor type: 4-20 mA, powered by LASU-controller.\r\n\0");
		break;

		case EXT_POWERED_4_20:
			TxMsg("Unit sensor type: 4-20 mA, external powered.\r\n\0");
		break;
        
        default:
            TxMsg("Unit sensor was not configured!!!\r\n\0");
            sprintf(Str, "input = 0x%x \r\n\0", input );  //debug
            UART_WriteMsg(Str);
        break;
	}
    
    if(GetStatusReg(TIME_FRAME_EN))
		TxMsg("Time-frame is enabled.\r\n\0");
	else
		TxMsg("Time-frame is disabled.\r\n\0");
	if(GetStatusReg(TIME_DRIVEN_TRIG_EN))
		TxMsg("Time-driven trigger is enabled.\r\n\0");
	else
		TxMsg("Time-driven trigger is disabled.\r\n\0"); 

//    TxMsg("ShowBatLevel[2]\r\n\0");
    ShowBatLevel();
 
    
     if(ValveIsON == FALSE )
    {
        TxMsg("Valve Is Closed...\r\n\0"); 
    
    } 
    else TxMsg("Valve Is Open...\r\n\0"); 
    
    
	TxMsg("\x1b[30m\r\n\0");
	return MAIN_MENU;
}

int ui_unit_configuration(int ui_select) {

	char input;

	TxMsg("\x1b[31;4m\0"); // underline red
	TxMsg("Setup and configuration menu:\r\n\0");
	TxMsg("\x1b[30;24m\0"); // cancel underline red
	TxMsg("1. Time and date settings.\r\n\0");
	TxMsg("2. Operation mode settings.\r\n\0");
	TxMsg("3. Input sensor type settings.\r\n\0");
	TxMsg("4. Back to main menu.\r\n\0");

	input = getchar();

	switch(input)
	{
		case '1':
			ui_select = TIME_DATE_CONFIG;
            TxMsg("\x1b[2J\0");
		break;

		case '2':
			ui_select = OPERATION_MODE_SETTINGS;
            TxMsg("\x1b[2J\0");
		break;

		case '3':
			ui_select = INPUT_SENSOR_CONFIG;
            TxMsg("\x1b[2J\0");
		break;

		case '4':
        case ESC:
			ui_select = MAIN_MENU;
            TxMsg("\x1b[2J\0");
		break;
	}
    return ui_select;
}

int ui_valve_manual_operation(int ui_select) {
   
        char c; 
          
        TxMsg("Valve Manuale Activation\r\n\0");
                                             
    while(1)
    {       
    
     TxMsg("\x1b[2J\0");
    TxMsg("\r\n"); 
    TxMsg("\x1b[31;4m\0"); // underline red
     
      if(ValveIsON == FALSE )
    {    
       
        TxMsg("Valve Is Closed...\r\n\0"); 
    
    } 
    else TxMsg("Valve Is Open...\r\n\0"); 
    
        TxMsg("\x1b[30;24m\0"); // cancel underline red 
        TxMsg("\r\n");
        TxMsg("1. Open Valve.\r\n\0");
        TxMsg("2. Close Valve.\r\n\0");  
        TxMsg("3. Back To Auto Mode.\r\n\0"); 
        TxMsg("4. Back\r\n\0");       
         TxMsg("\r\n");
                                            
        while((c = UART_Getc()) == 0);            
        switch(c)
        {
            case '1':  
                      SetValveON(); 
                                                               
                      break; 
            case '2':  
                      SetValveOFF(); 
                                                                     
                      break;  
                      
            case '3': 
                      TxMsg("In Auto Mode...\r\n\0");                                                  
                      break;  
                                             
            case '4':
            case ESC:
		        	ui_select = MAIN_MENU;
                    return MAIN_MENU;
	            	break;                    
                      
        } 
       
     }             
	return MAIN_MENU;
}

//new
int ui_input_sensor_config(int ui_select) {

	char input;

    TxMsg("\x1b[31;4m\0"); // underline red
	TxMsg("Input sensor type configuration menu:\r\n\0");
    TxMsg("\x1b[30;24m\0"); // cancel underline red	
	TxMsg("1. Single (changed) dry contact (attached to input #1).\r\n\0");
	TxMsg("2. Dual dry contacts (attached to input #1,3).\r\n\0");
	TxMsg("3. Analog 4-20mA.\r\n\0");
	TxMsg("4. Back to Setup and configuration menu.\r\n\0");
	TxMsg("5. Back to main menu.\r\n\0");


	input = getchar();

	switch(input)
	{
		case '1':
            TxMsg("\x1b[2J\0");
            TxMsg("\x1b[34m\0");
			sensor_type_config(SINGLE_RELAY_INPUT);
            TxMsg("\x1b[30m\0");
		break;

		case '2':
            TxMsg("\x1b[2J\0");
            TxMsg("\x1b[34m\0");
	        sensor_type_config(DUAL_RELAY_INPUT);
	        TxMsg("\x1b[30m\0");			
		break;

		case '3':
            TxMsg("\x1b[2J\0");
            delay_ms(5);        
			ui_select = ANALOG_SENSOR_CONFIG;            
		break;

		case '4':
        case ESC:
			ui_select = UNIT_CONFIGURATION;
            TxMsg("\x1b[2J\0");
		break;

		case '5':
			ui_select = MAIN_MENU;
            TxMsg("\x1b[2J\0");
		break;

	}
    return ui_select;
}

//new
void sensor_type_config(uint16_t type){

//	TxMsg("3. Analog 4-20mA.\r\n\0");

	switch(type)
	{
		case SINGLE_RELAY_INPUT:
			SetStatusReg(INPUT_SENS_TYPE, SINGLE_RELAY_INPUT);
            #asm("cli")
            eCtrlReg = StatusReg;
            #asm("sei")
			TxMsg("\r\nSingle dry contact input was set successfully!.\r\n\0");

		break;

		case DUAL_RELAY_INPUT:
			SetStatusReg(INPUT_SENS_TYPE, DUAL_RELAY_INPUT);
            #asm("cli")
            eCtrlReg = StatusReg;
            #asm("sei")            
			TxMsg("\r\nDual dry contact input was set successfully!.\r\n\0");

		break;

		case LASU_POWERED_4_20:
			SetStatusReg(INPUT_SENS_TYPE, LASU_POWERED_4_20);
            #asm("cli")
            eCtrlReg = StatusReg;
            #asm("sei")            
			TxMsg("\r\nLASU powered 4-20mA input was set successfully!.\r\n\0");

		break;

		case EXT_POWERED_4_20:
			SetStatusReg(INPUT_SENS_TYPE, EXT_POWERED_4_20);
            #asm("cli")
            eCtrlReg = StatusReg;
            #asm("sei")            
			TxMsg("\r\nExternal powered 4-20mA input was set successfully!.\r\n\0");

		break;
	}
}


int ui_analog_sensor_config(int ui_select) {

	char input;

//    TxMsg("\x1b[31;4m\0"); // underline red
    TxMsg("\x1b[31m\0");
    TxMsg("\x1b[4m\0");
	TxMsg("Analog sensor configuration menu:\r\n\0");
	TxMsg("\x1b[24m\0");
    TxMsg("\x1b[30m\0");
//	TxMsg("\x1b[30;24m\0"); // cancel underline red                	
	TxMsg("1. Power source select.\r\n\0");
	TxMsg("2. Threshold configuration.\r\n\0");
	TxMsg("3. Back to input sensor type menu.\r\n\0");
	TxMsg("4. Back to main menu.\r\n\0");

	input = getchar();

	switch(input)
	{
		case '1':
            TxMsg("\x1b[2J\0");
//            TxMsg("\x1b[31;4m\0"); // underline red
//	        TxMsg("Power source select menu:\r\n\0");
//	        TxMsg("\x1b[30;24m\0"); // cancel underline red             
			analog_power_source_select_menu();            
		break;

		case '2':
            TxMsg("\x1b[2J\0");
			analog_threshold_config();            
		break;

		case '3':
        case ESC:
			ui_select = INPUT_SENSOR_CONFIG;
            TxMsg("\x1b[2J\0");
		break;

		case '4':
			ui_select = MAIN_MENU;
            TxMsg("\x1b[2J\0");
		break;
	}

	return ui_select;
}

int ui_time_date_config(int ui_select) {
	char input;
	TxMsg("\x1b[2J\0");
	TxMsg("\x1b[31;4m\0"); // underline red
	TxMsg("System's time and date:\r\n\0");
	TxMsg("\x1b[34;24m\0"); // cancel underline red

	RTCgetTime();
	RTCgetDate();
	TxMsg("\n\x1b[30m\0");

	TxMsg("1. Set Time.\r\n\0");
	TxMsg("2. Set Date.\r\n\0");
	TxMsg("3. Back to setup and configuration menu.\r\n\0");
	TxMsg("4. Back to main menu.\r\n\0");

	input = getchar();

	switch(input)
	{
		case '1':
			ui_select = TIME_DATE_CONFIG;
			RTCSetTime();
			//RTCgetTime();
		break;

		case '2':
			ui_select = TIME_DATE_CONFIG;
			RTCSetDate();
			//RTCgetDate();
		break;

		case '3':
        case ESC:
			ui_select = UNIT_CONFIGURATION;
            TxMsg("\x1b[2J\0");
		break;

		case '4':
			ui_select = MAIN_MENU;
            TxMsg("\x1b[2J\0");
		break;

	}
    return ui_select;
};

int ui_opertion_mode_settings(int ui_select) {

	char input;

	TxMsg("\x1b[34;1m\r\0");
    TxMsg("\x1b[4m\0"); // underline
	TxMsg("Operation mode status:\r\n\0");
	TxMsg("\x1b[34;24m\0"); // cancel underline blue
    TxMsg("\x1b[22m\0");
	
	if(GetStatusReg(TIME_FRAME_EN))
		TxMsg("Time-frame is enabled.\r\n\0");
	else
		TxMsg("Time-frame is disabled.\r\n\0");
	if(GetStatusReg(TIME_DRIVEN_TRIG_EN))
		TxMsg("Time-driven trigger is enabled.\r\n\0");
	else
		TxMsg("Time-driven trigger is disabled.\r\n\0");
    
    TxMsg("\x1b[31;4m\0"); // underline red
	TxMsg("\nOperation mode settings menu:\r\n\0");
    TxMsg("\x1b[30;24m\0"); // cancel underline red

	TxMsg("1. Time-frame configuration.\r\n\0");
	TxMsg("2. Time-driven trigger configuration.\r\n\0");
	TxMsg("3. Back to setup and configuration menu.\r\n\0");
	TxMsg("4. Back to main menu.\r\n\0");

	input = getchar();

	switch(input)
	{
		case '1':
			ui_select = TIMEFRAME_SETTINGS;
            TxMsg("\x1b[2J\0");            
		break;

		case '2':
			ui_select = TIMEDRIVEN_TRIG_SETTINGS;
            TxMsg("\x1b[2J\0");            
		break;

		case '3':
        case ESC:
			ui_select = UNIT_CONFIGURATION;
            TxMsg("\x1b[2J\0");
		break;

		case '4':
			ui_select = MAIN_MENU;
            TxMsg("\x1b[2J\0");
		break;

	}
    return ui_select;
};



void analog_power_source_select_menu(void){

	char input;

    TxMsg("\x1b[31;4m\0"); // underline red
	TxMsg("Analog power source select menu:\r\n\0");
	TxMsg("\x1b[30;24m\0"); // cancel underline red	   
	TxMsg("1. Analog (4-20mA) external-powered sensor.\r\n\0");
	TxMsg("2. Analog (4-20mA) sensor - powered by LASU unit.\r\n\0");
	TxMsg("3. Back to analog sensor configuration menu.\r\n\0");
	TxMsg("4. Back to main menu.\r\n\0");

	input = getchar();

	switch(input)
	{
		case '1':
			sensor_type_config(EXT_POWERED_4_20);
		break;

		case '2':
			sensor_type_config(LASU_POWERED_4_20);
		break;

		case '3':
        case ESC:
			ui_select = UNIT_CONFIGURATION;
            TxMsg("\x1b[2J\0");
		break;

		case '4':
			ui_select = MAIN_MENU;
            TxMsg("\x1b[2J\0");
		break;

	}
}


void analog_threshold_config(void){
	
    
    char  c;      
    unsigned int tmp; 
    char Str[40];    
       
          
     while(1)
    {
        ShowAnalogSettings();            
        TxMsg("\r\n");
        TxMsg("\x1b[31;4m\0"); // underline red
	    TxMsg("Analog input threshold configuration\r\n\0");
	    TxMsg("\x1b[30;24m\0"); // cancel underline red
        TxMsg("Please set Params in order 1..5\r\n\0"); 
        TxMsg("1. Set Min. sensor reading (units for 4mA).\r\n\0"); 
        TxMsg("2. Set Max. sensor reading (units for 20mA). \r\n\0"); 
        TxMsg("3. Set Low Threshold-value.\r\n\0");      
        TxMsg("4. Set High Threshold-value.\r\n\0");   
        TxMsg("5. Set Sensor Reading Interval. (Minutes)\r\n\0");  
        TxMsg("6. Back to Analog sensor configuration menu..\r\n\0"); 
        TxMsg("\r\n");  
        while((c = UART_Getc()) == 0); 
            switch(c)
            {   
                case '1':  
                    TxMsg("Set Min. sensor reading (units for 4mA):\r\n\0"); 
                    tmp = UART_GetNum(); 
                    UART_WriteMsg(Str);
                    if(MaxTankLevel){
                        if(MaxTankLevel <= tmp){
                            TxMsg("\nSTOP: Min. value must be lower than Max. value..!\r\n\0");
                            delay_ms(4000);
                            break;
                        }                    
                    }  
                    MinTankLevel = tmp;    //load val at powerup
                    #asm("cli")
                    eMinTankLevel = tmp; 
                    #asm("sei")
                                
                    break;  
                                             
                case '2':  
                    TxMsg("Set Max. sensor reading (units for 20mA):\r\n\0"); 
                    tmp = UART_GetNum(); 
                    if(MinTankLevel >= tmp){                                 
                        TxMsg("\nSTOP: Max. value must be higher than Min. value..!\r\n\0");
                        delay_ms(4000);
                        break; 
                    }                     
                    UART_WriteMsg(Str);  
                    #asm("cli") 
                    MaxTankLevel = tmp;       //load val at powerup
                    eMaxTankLevel = tmp; 
                    #asm("sei")
                    break;
                                             
                case '3':  
//                    if(( MinTankLevel == 0xFFFF) || (MaxTankLevel == 0xFFFF)){//not set yet
                    if((MaxTankLevel == 0)){//not set yet                                  
                        TxMsg("Set Options 1 & 2 First..!\r\n\0");
                        delay_ms(4000); 
                        break;
                    } 
                    TxMsg("Set Low Threshold-value:\r\n\0"); 
                    tmp = UART_GetNum();                     
                    UART_WriteMsg(Str);
                    if(tmp < MinTankLevel){
                        TxMsg("\nSTOP: Low Threshold-value must be higher than Min. value..!\r\n\0");
                        delay_ms(4000);
                        break;                    
                    }
                    
                    if(tmp > MaxTankLevel){
                        TxMsg("\nSTOP: Low Threshold-value must be lower than Max. value..!\r\n\0");
                        delay_ms(4000);
                        break;                    
                    }
                    
                    if(HighTreshold){
                        if(tmp > HighTreshold){
                            TxMsg("\nSTOP: High Threshold-value must be higher than Low Threshold-value..!\r\n\0");
                            delay_ms(4000);
                            break;                        
                        }    
                    } 
                    LowTreshold = tmp;
                    #asm("cli")                  
                    eLowTeshold = tmp ; 
                    #asm("sei")
                    break; 
                                 
                case '4':                     
                    if(MaxTankLevel == 0){//not set yet                                  
                        TxMsg("Set Options 1 & 2 First..!\r\n\0");
                        delay_ms(4000); 
                        break;
                    }                                          
                    TxMsg("Set High Threshold-value:\r\n\0"); 
                    tmp = UART_GetNum();                      
                    UART_WriteMsg(Str);
                    
                    if(tmp < MinTankLevel){
                        TxMsg("\nSTOP: High Threshold-value must be higher than Min. value..!\r\n\0");
                        delay_ms(4000);
                        break;                    
                    }
                    
                    
                    if((tmp < LowTreshold)){                      
                        TxMsg("\nSTOP: High Threshold-value must be higher than Low Threshold-value..!\r\n\0");
                        delay_ms(4000);
                        break;                                                    
                    }
                    
                    if(tmp > MaxTankLevel){
                        TxMsg("\nSTOP: High Threshold-value must be lower than Max. value..!\r\n\0");
                        delay_ms(4000);
                        break;                    
                    }                                        
                      
                    HighTreshold = tmp; //(unsigned int)((4 + (16 * tmp/MaxTankLevel)) * 100); //treshold voltage 
                    #asm("cli")                   //100 ohm resistor
                    eHighTreshold = HighTreshold ; 
                    #asm("sei")
                    break;
                                 
                case '5':  
                    TxMsg("Set Sensor Reading Interval. (Minutets)\r\n\0"); 
                    TxMsg("Reading the sensor influences battery life!\r\n\0");
                    TxMsg("Recommended value is 10 minutes or above.\r\n\0");
                    tmp = UART_GetNum();                     
                    UART_WriteMsg(Str);    
                    ReadingInterval = tmp;        //to be used it RTC setting
                    #asm("cli")                   //100 ohm resistor
                    eReadingInterval = tmp ; 
                    #asm("sei")
                    break; 
                                 
                case '6':
                case ESC: 
                    TxMsg("\x1b[2J\0");
                    return;                                         
            }                                       
        
    }
 
 
 }                                  



int ui_timeframe_settings(int ui_select) {
	char input;

    TxMsg("\x1b[34m\r\0"); // blue    
    if(GetStatusReg(TIME_FRAME_EN))
		TxMsg("Time-frame is enabled.\r\n\n\0");
	else
		TxMsg("Time-frame is disabled.\r\n\n\0");    

    TxMsg("\x1b[31;4m\0"); // underline red
	TxMsg("Time-frame settings menu:\r\n\0");
	TxMsg("\x1b[30;24m\0"); // cancel underline red	 
    
    if(GetStatusReg(TIME_FRAME_EN))		
        TxMsg("1. Disable Time-frame mode.\r\n\0");
	else
        TxMsg("1. Enable Time-frame mode.\r\n\0");   
	TxMsg("2. Show/delete active Time-frame.\r\n\0");
	TxMsg("3. Set a new Time-frame.\r\n\0");
	TxMsg("4. Back to setup and configuration menu.\r\n\0");
	TxMsg("5. Back to main menu.\r\n\0");

	input = getchar();

	switch(input)
	{
		case '1':
        
        
            if(GetStatusReg(TIME_FRAME_EN)){		
                SetStatusReg(TIME_FRAME_EN,0);
                #asm("cli")
                eCtrlReg = StatusReg;
                #asm("sei")
                TxMsg("\x1b[2J\0");
//                TxMsg("\x1b[34m\r\0");
//                TxMsg("Time-frame mode is disbled...!\r\n\n\0");
//                TxMsg("\x1b[30m\r\0");                    
            }
	        else{
                SetStatusReg(TIME_FRAME_EN,TIME_FRAME_EN);
                #asm("cli")
                eCtrlReg = StatusReg;
                #asm("sei")
                TxMsg("\x1b[2J\0"); 
//                TxMsg("\x1b[34m\r\0");
//                TxMsg("Time-frame mode is enabled...!\r\n\n\0");
//                TxMsg("\x1b[30m\r\0");
            }
		break;                   
    
		case '2':
			ui_select = SHOW_DELETE_TIMEFRAME;
            TxMsg("\x1b[2J\0");
		break;

		case '3':
			set_new_TFwin();
			ui_select = TIMEFRAME_SETTINGS;
            //TxMsg("\x1b[2J\0");
		break;

		case '4':
        case ESC:
			ui_select = UNIT_CONFIGURATION;
            TxMsg("\x1b[2J\0");
		break;

		case '5':
			ui_select = MAIN_MENU; 
            TxMsg("\x1b[2J\0");
		break;

	}
	return ui_select;
}


int ui_show_delete_time_frame(int ui_select){
	char input;

    TxMsg("\x1b[31;4m\0"); // underline red
	TxMsg("Show/delete active Time-frame menu:\r\n\0");
	TxMsg("\x1b[30;24m\0"); // cancel underline red	
	TxMsg("1. Show active Time-frame.\r\n\0");
	TxMsg("2. Delete active Time-frame.\r\n\0");
	TxMsg("3. Back to Time-frame settings.\r\n\0");
	TxMsg("4. Back to main menu.\r\n\0");

	input = getchar();

	switch(input)
	{
		case '1':
            TxMsg("\x1b[2J\0");
			print_active_TFwin();
			//ui_select = TIMEFRAME_SETTINGS;
		break;

		case '2':
            TxMsg("\x1b[2J\0");
			delete_active_TFwin();
			//ui_select = TIMEFRAME_SETTINGS;            
		break;

		case '3':
        case ESC:
            TxMsg("\x1b[2J\0");
			ui_select = TIMEFRAME_SETTINGS;
		break;

		case '4':
			ui_select = MAIN_MENU;
            TxMsg("\x1b[2J\0");
		break;

	}
	return ui_select;
}


int ui_timedriven_trig_settings(int ui_select){

    char input;
    
    TxMsg("\x1b[34m\r\0");                                                 
    if(GetStatusReg(TIME_DRIVEN_TRIG_EN))
        TxMsg("Time-driven trigger is enabled.\r\n\n\0");
    else
        TxMsg("Time-driven trigger is disabled.\r\n\n\0");
        
//    TxMsg("Time-driven trigger is not supported for this unit!\r\n\n\0"); 
//    TxMsg("\x1b[30m\r\0"); 
    
////
    TxMsg("\x1b[31;4m\0"); // underline red
	TxMsg("Time-driven trigger settings menu:\r\n\0");
	TxMsg("\x1b[30;24m\0"); // cancel underline red	 
    
    if(GetStatusReg(TIME_DRIVEN_TRIG_EN))		
        TxMsg("1. Disable Time-driven trigger mode.\r\n\0");
	else
        TxMsg("1. Enable Time-driven trigger mode.\r\n\0");   
	TxMsg("2. Show/delete active Time-driven trigger.\r\n\0");
	TxMsg("3. Set a new Time-driven trigger.\r\n\0");
	TxMsg("4. Back to setup and configuration menu.\r\n\0");
	TxMsg("5. Back to main menu.\r\n\0");

	input = getchar();

	switch(input)
	{
		case '1':
        
        
            if(GetStatusReg(TIME_DRIVEN_TRIG_EN)){		
                SetStatusReg(TIME_DRIVEN_TRIG_EN,0);
                #asm("cli")
                eCtrlReg = StatusReg;
                #asm("sei")
                TxMsg("\x1b[2J\0");
//                TxMsg("\x1b[34m\r\0");
//                TxMsg("Time-driven trigger mode is disbled...!\r\n\n\0");
//                TxMsg("\x1b[30m\r\0");                    
            }
	        else{
                SetStatusReg(TIME_DRIVEN_TRIG_EN,TIME_DRIVEN_TRIG_EN);
                #asm("cli")
                eCtrlReg = StatusReg;
                #asm("sei")
                TxMsg("\x1b[2J\0"); 
//                TxMsg("\x1b[34m\r\0");
//                TxMsg("Time-driven trigger mode is enabled...!\r\n\n\0");
//                TxMsg("\x1b[30m\r\0");
            }
		break;                   
    
		case '2':
			ui_select = SHOW_DELETE_TIMEDRIVEN_TRIG;
            TxMsg("\x1b[2J\0");
		break;

		case '3':
			set_new_TDwin();
			ui_select = TIMEDRIVEN_TRIG_SETTINGS;
            //TxMsg("\x1b[2J\0");
		break;

		case '4':
        case ESC:
			ui_select = UNIT_CONFIGURATION;
            TxMsg("\x1b[2J\0");
		break;

		case '5':
			ui_select = MAIN_MENU; 
            TxMsg("\x1b[2J\0");
		break;

	}
	return ui_select;
}

int ui_show_delete_timedriven_trig(int ui_select){
	char input;

    TxMsg("\x1b[31;4m\0"); // underline red
	TxMsg("Show/delete active Time-driven trigger menu:\r\n\0");
	TxMsg("\x1b[30;24m\0"); // cancel underline red	
	TxMsg("1. Show active Time-driven trigger.\r\n\0");
	TxMsg("2. Delete active Time-driven trigger.\r\n\0");
	TxMsg("3. Back to Time-driven trigger configuration.\r\n\0");    
	TxMsg("4. Back to main menu.\r\n\0");

	input = getchar();

	switch(input)
	{
		case '1':
            TxMsg("\x1b[2J\0");
			print_active_TDwin();		
		break;

		case '2':
            TxMsg("\x1b[2J\0");
			delete_active_TDwin();			     
		break;

		case '3':
        case ESC:
            TxMsg("\x1b[2J\0");
			ui_select = TIMEDRIVEN_TRIG_SETTINGS;
		break;

		case '4':
			ui_select = MAIN_MENU;
            TxMsg("\x1b[2J\0");
		break;

	}
	return ui_select;
}


int set_new_TFwin(void){
	int i, found, error;
    uint8_t day_of_week; 

	//look for the first available window
	for(i=0, found=FALSE; i<WIN_NUM && !found;i++){
		if(winTF[i].enable == 0){
			found = TRUE;
			//sprintf(Str,"window #%d is available...\n", i);
            // UART_WriteMsg(Str); 
			break;
		}
	}
	if(i==WIN_NUM){
		sprintf(Str,"All %d available Time-frames are in used\n\r\0", WIN_NUM);
        UART_WriteMsg(Str); 
        TxMsg("Please delete a Time-frame before adding a new one\n\r\0"); 
                  
		error=TRUE;
		return error;
	}
	//set day/days of week that this window should be active
    
	if(set_window_dow(&day_of_week)){
		error=TRUE;
		return error;
	}
    winTF[i].dow = day_of_week;
    
	//set start time
	TxMsg("Please enter Time-frame's start time:\n\r\n\0");
	if(set_win_time(&(winTF[i].start_time_min))){
		//error - print + back to prev menu...
	}
	else {
		TxMsg("Please enter Time-frame's end time\n\r\n\0");
		if(set_win_time(&(winTF[i].end_time_min))){
			//error - print + back to prev menu...
		}
		else {
			if(winTF[i].start_time_min >= winTF[i].end_time_min){
				TxMsg("\nERROR: end time must be greater than start time!\r\n\0");
				sprintf(Str,"Time Frame #%02i was NOT set!!!:\n",i+1);
                UART_WriteMsg(Str); 
				return -1;
			}
			winTF[i].enable = TRUE;
			sprintf(Str,"Time Frame #%02d was set successfully\n",i+1); 
            UART_WriteMsg(Str); 
			print_TFwin_details(i);
		}
	}
	return 0;
}


int set_new_TDwin(void){
	int i, found, error;
    uint8_t day_of_week; 
    
	//look for the first available window
	for(i=0, found=FALSE; i<WIN_NUM && !found;i++){
		if(winTD[i].enable == 0){
			found = TRUE;
			//sprintf(Str,"window #%d is available...\n", i);
            // UART_WriteMsg(Str); 
			break;
		}
	}
	if(i==WIN_NUM){
		sprintf(Str,"All %d available Time-driven triggers are in use\n\r\0", WIN_NUM);
        UART_WriteMsg(Str); 
        TxMsg("Please delete an old Time-driven trigger before adding a new one\n\r\0"); 
                  
		error=TRUE;
		return error;
	}
	//set day/days of week that this window should be active
    
	if(set_window_dow(&day_of_week)){
		error=TRUE;
		return error;
	}
    winTD[i].dow = day_of_week;
    
	//set start time
	TxMsg("Please enter Time-driven trigger's start time:\n\r\n\0");
	if(set_win_time(&(winTD[i].start_time_min))){
		//error - print + back to prev menu...
	}
	else {
		TxMsg("Please enter Time-driven trigger's end time\n\r\n\0");
		if(set_win_time(&(winTD[i].end_time_min))){
			//error - print + back to prev menu...
		}
		else {
			if(winTD[i].start_time_min >= winTD[i].end_time_min){
				TxMsg("\nERROR: end time must be greater than start time!\r\n\0");
				sprintf(Str,"Time Frame #%02i was NOT set!!!:\n",i+1);
                 UART_WriteMsg(Str); 
				return -1;
			}
			winTD[i].enable = TRUE;
			sprintf(Str,"Time Frame #%02d was set successfully\n",i+1); 
            UART_WriteMsg(Str); 
			print_TDwin_details(i);
		}
	}
	return 0;
}




// function: set_win_time
// description: get a new window time from user (start or end time),
//              convert time to minutes and store it to the address passed by the calling func.

int set_win_time(eeprom uint16_t *wintime){

	uint16_t minutes, hours, error; 
    
	//*minutes = *hours = 0;
	error = GetTimeFromUser(&minutes, &hours, 0);
	if(error==FALSE)
		*wintime = 60*(hours)+(minutes);
	//sprintf(Str,"\nTime in min is %d\n"),*wintime);  
    // UART_WriteMsg(Str); 
	return error;
}


// set window's day of week - winTF[i].dow
int set_window_dow(uint8_t *day_of_week){
	#define LENGTH 30
	int fdow=0, i, j, error;
	char c, tmp[2], days[LENGTH];
    uint8_t dow;

	do{
		*day_of_week = i =0;
		error = TRUE;
		memset(&days[0], 0, sizeof(days)); //clear days
		TxMsg("\nPlease enter Time-frame's active days. (enter <h> for help)\r\n\0");
		while (( c = getchar()) != '\n' && c != '\r' && i < LENGTH){
			if((c == 'h') || (c =='H')){
				TxMsg("\nEnter active days for current Time-frame ,\r\n\0");
				TxMsg("Where Sunday is 1, Saturday is 7\r\n\0");
				TxMsg("Example:\r\n\0");
				TxMsg("For Sunday and Wednesday enter 14 (or 1,4 or 1 4)\r\n\0");
				TxMsg("For Monday-Friday enter 23456\r\n\0");
				TxMsg("\n\rPlease enter Time Frame's day/days of week (enter <h> for help)\r\n\0");
			}
			else if(c == '\b'){
				if(i>0){
					putchar0(c);
					putchar0(' ');
					putchar0(c);
					i--;
				}
			}
			else if((c >= '1')&&(c <='7') ) { // correct day
				putchar0(c);
				days[i++] = c;
			}
			else if((c == ',')||(c ==';')||(c ==' ')) {
				putchar0(c);
			}
			else if((c == ESC)) {
				error=TRUE;
				return error;
			}
			days[i] = tmp[1] = '\0';
		}
		if(c == '\n' || c == '\r'){
			for(j=0; j <= i && days[j]!='\0'&& i>0; j++){
					tmp[0] = days[j];
					*day_of_week |= (1<<(atoi(tmp)-1)); 
                    
					//sprintf(Str,"OUT:j=%d,i=%d,atoi(tmp)=%d,[0x%x]\r\n\0",j,i,atoi(tmp),*day_of_week);
                    //UART_WriteMsg(Str); //
				}
			}
			//sprintf(Str,"[0x%x]\r\n\0",*day_of_week); 
            //UART_WriteMsg(Str); 
            
            dow = *day_of_week;
			memset(&days[0], 0, sizeof(days)); //clear days
			dow_bin2s(days, dow);
            
			if(*day_of_week == FALSE){
				TxMsg("\r\nNo active day was set for this Time-frame!\r\n\0");
				TxMsg("\r\nHit Esc to leave 'days of week' settings and back to 'Time-frame settings menu'\r\n\0");
				TxMsg("Or hit any other key to select new setting.\r\n\0");
				error = TRUE;
			}
			else{ 
                TxMsg("\r\nTime-frames' active days: \0");
				sprintf(Str,"%s\n\r\0",days); 
                UART_WriteMsg(Str);                                  
                  
				TxMsg("Hit Esc to change active days setting  or any other key to continue\r\n\0");
				error=FALSE;
			}
			c = getchar();

			if(c == ESC)
				fdow = (*day_of_week==FALSE)?TRUE:FALSE;
			else{
				fdow = (*day_of_week==FALSE)?FALSE:TRUE;
			}
	}while(fdow == 0);

	return error;
}

// convert day of week bits to string of days according to bit mask (winTF[i].dow).
void dow_bin2s(char *days, uint8_t day_of_week){
	uint8_t i,j;

//         sprintf(Str,"dow_bin2s debug: day_of_week = 0x%x\n\r",day_of_week); 
//         UART_WriteMsg(Str);

	for(i=0,j=0;i<7;i++){

//        printf("~~~~~dow_bin2s debug~~~~~~: i=%d, j=%d, 1<<i=0x%x\n\r",i,j,1<<i);       
//        sprintf(Str,"dow_bin2s debug: i=%d, j=%d, 1<<i=0x%x\n\r",i,j,1<<i);
//        UART_WriteMsg(Str);
//        memset(&Str[0], 0, sizeof(Str)); //clear Str
        
		if(day_of_week & 1<<i){
        
//            printf("~~~~~dow_bin2s debug~~~~~~: i=%d, j=%d, 1<<i=0x%x\n\r",i,j,1<<i);
//            sprintf(Str,"~~~~~dow_bin2s debug~~~~~~: i=%d, j=%d, 1<<i=0x%x\n\r",i,j,1<<i);
//            UART_WriteMsg(Str);
                    
			if(j)
				strcat(days, ",");
                            			
            strcatf(days, dayname[i]);

//                sprintf(Str,"^dow_bin2s debug^ i=%d,j=%d, 1<<i=0x%x\n\r",i,j,1<<i);
//                 UART_WriteMsg(Str);
             
//            sprintf(Str,"days: %s\n\r",days);  //show how "days" built
            UART_WriteMsg(Str);
         
		    j++;           
        }     
	}
    TxMsg("\n\r\r\n\0");
}

void print_active_TFwin(void){
	uint8_t i, found;

	for(i=0, found = FALSE; i < WIN_NUM ;i++){
		if(winTF[i].enable == TRUE){
			print_TFwin_details(i);
			found = TRUE;
		}
	}
	if(found == FALSE){
        TxMsg("\x1b[34m\r\0");
		TxMsg("\rNo active Time-frame was set...!\r\n\n\0"); 
        TxMsg("\x1b[30m\r\0");
    }    
}

void print_active_TDwin(void){
	uint8_t i, found;

	for(i=0, found = FALSE; i < WIN_NUM ;i++){
		if(winTD[i].enable == TRUE){
			print_TDwin_details(i);
			found = TRUE;
		}
	}
	if(found == FALSE){
        TxMsg("\x1b[34m\r\0");
		TxMsg("\rNo active Time-driven trigger was set...!\r\n\n\0"); 
        TxMsg("\x1b[30m\r\0");
    }    
}


int delete_active_TFwin(void){

	uint8_t win_idx, del_flg, found;
	char input;

	for(win_idx=0, found = FALSE; win_idx<WIN_NUM ;win_idx++){
		if(winTF[win_idx].enable == TRUE){
			found = TRUE;
			break;
		}
	}
	if(found == FALSE){        
        TxMsg("\x1b[34m\r\0");
		TxMsg("\rThere is no active Time-frame to delete...\r\n\n\0");
        TxMsg("\x1b[30m\r\0");
		return TRUE;
	}

	do{
		del_flg=FALSE;
		TxMsg("\n\rPlease select a Time-frame index to delete: \r\n\0"); 
        
		input = getchar(); 
         
        putchar0(input);
        TxMsg("\r\n\0");         
        
		win_idx = atoi(&input); 
                        
		if((win_idx >= 1)&&(win_idx < WIN_NUM)){
			if(winTF[win_idx-1].enable == TRUE){    
            
              TxMsg("\n\rTime Frame will be deleted. Are you sure ? (Y/n)\r\n\0");  
                            
              sprintf(Str,"\n\rTime Frame #%02u will be deleted. Are you sure ? (Y/n)\n\r",win_idx);
		      UART_WriteMsg(Str);  
                 
				for(;;){
					input = getchar();
					if(input == 'Y'||input=='y'||input=='\n'||input=='\r'){
						del_flg=TRUE;
						break;
					}
					else if(input == 'N'||input=='n')
						break;
					else if(input == ESC)
						break;
					else
						TxMsg("Please enter Y/y to delete or N/n to choose another Time Frame:\n\r\n\0");
				}

			}
			else{
				sprintf(Str,"\n\rTime Frame #%02d is NOT active, please choose one of the following Time Frames:\n",win_idx);
                UART_WriteMsg(Str);
				print_active_TFwin();
			}

		}
		else{
			TxMsg("\n\rWrong Time Frame index was selected\r\n\0");
			sprintf(Str,"Time Frame index should be between 1-%d\n\r",WIN_NUM);
             UART_WriteMsg(Str);
			TxMsg("Hit Esc to go back to 'Show/delete active Time Frames menu'\r\n\0");
			TxMsg("Or hit any other key to continue deleting an active Time Frame.\r\n\0");

			input = getchar();

			if(input == ESC)
				return 1;
		}

	}while(del_flg==FALSE);

	winTF[win_idx-1].enable = FALSE;
	sprintf(Str,"\n\rTime Frame #%02d was deleted successfully!\n\r",win_idx); 
     UART_WriteMsg(Str);
	return 0;
}


int delete_active_TDwin(void){

	uint8_t win_idx, del_flg, found;
	char input;

	for(win_idx=0, found = FALSE; win_idx<WIN_NUM ;win_idx++){
		if(winTD[win_idx].enable == TRUE){
			found = TRUE;
			break;
		}
	}
	if(found == FALSE){        
        TxMsg("\x1b[34m\r\0");
		TxMsg("\rThere is no active Time-driven trigger to delete...\r\n\n\0");
        TxMsg("\x1b[30m\r\0");
		return TRUE;
	}

	do{
		del_flg=FALSE;
		TxMsg("\n\rPlease select a Time-driven trigger index to delete: \r\n\0"); 
        
		input = getchar(); 
         
        putchar0(input);
        TxMsg("\r\n\0");         
        
		win_idx = atoi(&input); 
                        
		if((win_idx >= 1)&&(win_idx < WIN_NUM)){
			if(winTD[win_idx-1].enable == TRUE){    
            
              TxMsg("\n\rTime-driven trigger will be deleted. Are you sure ? (Y/n)\r\n\0");  
                            
              sprintf(Str,"\n\rTime-driven trigger #%02u will be deleted. Are you sure ? (Y/n)\n\r",win_idx);
		      UART_WriteMsg(Str);  
                 
				for(;;){
					input = getchar();
					if(input == 'Y'||input=='y'||input=='\n'||input=='\r'){
						del_flg=TRUE;
						break;
					}
					else if(input == 'N'||input=='n')
						break;
					else if(input == ESC)
						break;
					else
						TxMsg("Please enter Y/y to delete or N/n to choose another Time-driven trigger:\n\r\n\0");
				}

			}
			else{
				sprintf(Str,"\n\rTime Frame #%02d is NOT active, please choose one of the following Time-driven trigger:\n",win_idx);
                UART_WriteMsg(Str);
				print_active_TFwin();
			}

		}
		else{
			TxMsg("\n\rWrong Time-driven trigger index was selected\r\n\0");
			sprintf(Str,"Time-driven trigger index should be between 1-%d\n\r",WIN_NUM);
             UART_WriteMsg(Str);
			TxMsg("Hit Esc to go back to 'Show/delete active Time-driven triggers menu'\r\n\0");
			TxMsg("Or hit any other key to continue deleting an active Time-driven trigger.\r\n\0");

			input = getchar();

			if(input == ESC)
				return 1;
		}

	}while(del_flg==FALSE);

	winTD[win_idx-1].enable = FALSE;
	sprintf(Str,"\n\rTime-driven trigger #%02d was deleted successfully!\n\r",win_idx); 
     UART_WriteMsg(Str);
	return 0;
}



void print_TFwin_details(uint8_t win_idx){

	char days[30];
	uint8_t hour, min, day_of_week; 
   
	sprintf(Str,"\r\nTime-frame #%02d:",win_idx+1); 
    UART_WriteMsg(Str);  
    
    	TxMsg("\r\n--------------\r\n\0");
	memset(&days[0], 0, sizeof(days));
    day_of_week = winTF[win_idx].dow;
	dow_bin2s(days, day_of_week);
	sprintf(Str,"Active days of week: %s\n",days); 
    UART_WriteMsg(Str);
	GetTimeFromMinutsTime(&(winTF[win_idx].start_time_min), &hour, &min);
	sprintf(Str,"\r\nTime-frame active period: %02d:%02d-",hour, min); 
    UART_WriteMsg(Str);
	GetTimeFromMinutsTime(&(winTF[win_idx].end_time_min), &hour, &min);
	sprintf(Str,"%02d:%02d\r\n",hour, min); 
    UART_WriteMsg(Str);
}


void print_TDwin_details(uint8_t win_idx){

	char days[30];
	uint8_t hour, min, day_of_week;

	sprintf(Str,"\r\nTime-driven trigger #%02d:",win_idx+1); 
    UART_WriteMsg(Str);
	TxMsg("\r\n-------------------\r\n\0");
	memset(&days[0], 0, sizeof(days));
    day_of_week = winTD[win_idx].dow;
	dow_bin2s(days, day_of_week);    
	//dow_bin2s(days, &(winTD[win_idx].dow));
	sprintf(Str,"Active days of week: %s\n",days); 
    UART_WriteMsg(Str);
	GetTimeFromMinutsTime(&(winTD[win_idx].start_time_min), &hour, &min);
	sprintf(Str,"\r\nTime-driven trigger active period: %02d:%02d-",hour, min); 
    UART_WriteMsg(Str);
	GetTimeFromMinutsTime(&(winTD[win_idx].end_time_min), &hour, &min);
	sprintf(Str,"%02d:%02d\r\n",hour, min); 
    UART_WriteMsg(Str);
}

uint8_t GetTimeFromUser(uint16_t *minutes, uint16_t *hours, uint8_t ampm_flg)
{
	#define TRY_NUM 3
	uint8_t error = TRUE, try = TRY_NUM;

	do{
	  TxMsg("Set hour(24hr): \0");
	  *hours = UARTGetBin();
	  if(*hours >= 0 && *hours < 24)
		  error = FALSE;
	  else{
		  sprintf(Str,"\n%d is a illigal value!\nHour value should be in range 0-24\n",*hours); 
           UART_WriteMsg(Str);
		  try--;
	  }
	}while(error&&try);

	if(try){ //hour is correct
		error = TRUE;
		try = TRY_NUM;
	}
	else{
		TxMsg("\nTime was NOT set!\r\n\0");
		return error;
	}


	while(error&&try){
		TxMsg("\r\nSet minutes: \0");
		*minutes = UARTGetBin();
		if(*minutes >= 0 && *minutes < 60)
		  error = FALSE;
		else{
		  TxMsg("\r\nWrong value ..!- Minutes should be in range 0-59\r\n\0");
		  try--;
		}
	};

	if(try==FALSE){
		TxMsg("\nTime was NOT set!\r\n\0");
		return error;
	}
	TxMsg("\n\r\n\0");

	return error;  
 }   
    
uint8_t CurrentTimeNOTWithinTFCheck(void){

	uint16_t min_time;
	uint8_t within_timeframe_err=TRUE;

	unsigned char dow, i=0; 
    
    if(GetStatusReg(TIME_FRAME_EN)){

        dow = rtc_read_masked_bcd(0x07, 0x07);  //DOW register address = 0x07 mask =0x07

        min_time = GetCurrentMinutsTime();

    //	printf_P(PSTR("\nCurrentTimeNOTWithinTFCheck\n"),i);

        for(i=0; i<WIN_NUM ;i++){
   
            if(winTF[i].enable == TRUE){
   
                print_TFwin_details(i);
                if(BIT_CHECK(winTF[i].dow, dow)){
    
                    if((min_time >= winTF[i].start_time_min)&&(min_time < winTF[i].end_time_min)){

                        sprintf(Str,"CTWTFC: [%d, %d, %d]\n\r",winTF[i].start_time_min, min_time, winTF[i].end_time_min); 
                        UART_WriteMsg(Str);
                        within_timeframe_err = FALSE;
                        break;
                    }
    				else{
    					if((min_time > winTF[i].end_time_min)){
                            sprintf(Str,"CTWWC: [%d, %d]+++[%d]\n\r",winTF[i].start_time_min, winTF[i].end_time_min, min_time); 
                            UART_WriteMsg(Str);
                        }
    					if((min_time < winTF[i].start_time_min)){
                            sprintf(Str,"CTWWC: [%d]---[%d, %d]\n\r",min_time, winTF[i].start_time_min, winTF[i].end_time_min); 
                            UART_WriteMsg(Str);
                       }     
    				}
                }
                else
                    TxMsg("\nCurrent day not within Time-frame...!\r\n\0");                    
            }
        }
    }

	return within_timeframe_err;
}


// finds end time of current active timeframe.
// (In case where few active timeframe overlapping, find the one that ends latest).
// returns error: TRUE if we're NOT within a timeframe now, otherwise returns FALSE.
uint8_t find_timeframe_end(alarm_t* alrm){

	uint16_t min_time, tf_endtime;
	uint8_t within_timeframe, error;

	unsigned char dow, i=0;

	within_timeframe = error= FALSE;  
    tf_endtime = 0; //prepare for midnight?

	dow = RTCGetDOW();

	min_time = GetCurrentMinutsTime();

	for( i = 0; i < WIN_NUM ;i++){

		if(winTF[i].enable == TRUE){

//			print_window_details(i);
			if(BIT_CHECK(winTF[i].dow, dow)){ //  
				if((min_time >= winTF[i].start_time_min)&&(min_time < winTF[i].end_time_min)){

					within_timeframe = TRUE;
					if(winTF[i].end_time_min > tf_endtime){
						tf_endtime = winTF[i].end_time_min;
					}
				}
//				else{
//					if((min_time > winTF[i].end_time_min))
//						printf_P(PSTR("FTFE: [%d, %d]+++[%d]\n"),winTF[i].start_time_min, winTF[i].end_time_min, min_time);
//					if((min_time < winTF[i].start_time_min))
//						printf_P(PSTR("FTFE: [%d]---[%d, %d]\n"),min_time,winTF[i].start_time_min, winTF[i].end_time_min);
//				}
			} 
            else   TxMsg("DEBUG: No TF today..! \r\n\0"); 
		}
        
	}

//	if(within_timeframe)
//    {
//		if(tf_endtime==1439){ // 23:59
//			tf_endtime = 0;
//			dow++;
//			if(dow == 7)
//				dow = 0;
//	} 
//    else     //
//    {
         if(tf_endtime == 0)   //must wake at midnight 
         {
                dow++;
			if(dow == 7)
				dow = 0;
         }
//    }
//		printf_P(PSTR("BBB:dow = %d\n"), dow);
		alrm->dow = dow;
//		printf_P(PSTR("AAA:alrm->dow = %d\n"), alrm->dow);
//		printf_P(PSTR("BBB:tf_endtime = %d\n"), tf_endtime);
		alrm->alrm_time_min = tf_endtime;
//		printf_P(PSTR("AAA:alrm->alrm_time_min = %d\n"), alrm->alrm_time_min);

	
//	else
//		error = TRUE;      ????????????????????????????????????

	return error;
}

uint8_t find_next_timeframe(alarm_t* alrm){

	uint16_t min_time, tf_starttime;
	uint8_t within_timeframe, error;

	unsigned char dow, i=0;

	tf_starttime=within_timeframe=error=FALSE;

	dow = RTCGetDOW();

	min_time = GetCurrentMinutsTime();

	for(i=0; i<WIN_NUM ;i++){
//		printf_P(PSTR("\nFNTF: i=%d\n"),i);
		if(winTF[i].enable == TRUE){
//			printf_P(PSTR("FNTF: winTF[%d].enable=TRUE, winTF[%d].dow = 0x%x\n"),i,i,winTF[i].dow);
//			print_window_details(i);
			if(BIT_CHECK(winTF[i].dow, dow)){
//				printf_P(PSTR("FNTF: winTF[%d].dow = 0x%x\n"),i, winTF[i].dow);
				if((min_time >= winTF[i].start_time_min)&&(winTF[i].end_time_min > min_time)){
//					printf_P(PSTR("FNTF: [%d, %d, %d]\n"),winTF[i].start_time_min, min_time, winTF[i].end_time_min);
					within_timeframe = TRUE;
					break;
				}
				else{     //not in TF
//					if((min_time > winTF[i].end_time_min))
//						printf_P(PSTR("FNTF: [%d, %d]+++[%d]\n"),winTF[i].start_time_min, winTF[i].end_time_min, min_time);
					if((min_time < winTF[i].start_time_min)){
						if(tf_starttime == 0)//first assighnment
							tf_starttime = winTF[i].start_time_min;
						    else if(tf_starttime > winTF[i].start_time_min)
								tf_starttime = winTF[i].start_time_min;    //new lower value
//						     printf_P(PSTR("FNTF: [%d]---[%d, %d]\n"),min_time,winTF[i].start_time_min, winTF[i].end_time_min);
					}
				}
			}
		}
	}
	if(within_timeframe)
		error = TRUE;
	else
	{
		if(tf_starttime==1439){ // 23:59
			tf_starttime=0;
			dow++;
			if(dow==7)
				dow=0;
		}
		alrm->dow = dow;
		alrm->alrm_time_min = tf_starttime;
	}
	return error;
}




// Just for testing...
void test_win_available(void){
	int i;
	for(i=0;i<8;i++){
		//winTF[i].enable = 1;
		sprintf(Str,"winTF[%d].enable = %d\n",i,winTF[i].enable);
         UART_WriteMsg(Str); 
	}
}
*/
void print_logo(void){
	TxMsg("\x1b[2J\r\n\0");
	TxMsg("\x1b[34;1m\r\n\0");
	//TxMsg("\x1b[34\r\n\0");
	TxMsg(" ___  ____        _       ____  _____  ______      ___   \r\n\0");
	TxMsg("|_  ||_  _|      / \\     |_   \\|_   _||_   _ `.  .'   `.  \r\n\0");
	TxMsg("  | |_/ /       / _ \\      |   \\ | |    | | `. \\/  .-.  \ \r\n\0");
	TxMsg("  |  __'.      / ___ \\     | |\\ \\| |    | |  | || |   | | \r\n\0");
	TxMsg(" _| |  \\ \\_  _/ /   \\ \\_  _| |_\\   |_  _| |_.' /\\  `-'  /\r\n\0");
	TxMsg("|____||____||____| |____||_____|\\____||______.'  `.___.'    v1.00\r\n\0");
//	TxMsg("\x1bc"\r\n\0");
	TxMsg("\x1b[22m\r\n\0");
}

void print_monitor_mode_message(void){

	TxMsg("\x1b[47m\0");
	TxMsg("\x1b[30m\0");
	TxMsg("******************* KANDO LOGGER monitor-mode ********************\r\n\0");
	TxMsg("**** \0");
	TxMsg("\x1b[5m\0");
	TxMsg("To exit monitor-mode, change position of switch on board\0");
	TxMsg("\x1b[25m\0");
	TxMsg(" ****\r\n\0"); 
	TxMsg("\x1b[30;47m\0");
}

 
