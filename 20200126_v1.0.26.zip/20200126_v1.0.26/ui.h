/*
 * ui.h
 *
 *  Created on: Jan 7, 2013
 *      Author: boaz
 */

#ifndef UI_H_
#define UI_H_
#include <stdint.h>

//void ui_main_loop(void);

#endif /* UI_H_ */
