/*
 * uart.h
 *
 *  Created on: Jan 1, 2013
 *      Author: boaz
 */

#ifndef UART_H_
#define UART_H_

#define F_CPU 3686400UL
#define BAUD 19200


#include <stdio.h>


char     UART_Getc(void);
//void    SendDebugMsg(flash char *InStr);

void    UART1_WriteMsg( char *InStr);
//unsigned int     UART_GetNum();
//void    TxByte(char data );
unsigned int UARTGetBin(void);
void putchar0(char c);
void putchar(char c);
char getchar(void);
char getchar1(void);
void BIN2STR(unsigned int BinData, char *str);
void ShowHexString(char *message, char Lengh);
 void PCmessage( char *message );
 

//  int SD12_Sensors_Read(char sens_add);

#endif /* UART_H_ */
