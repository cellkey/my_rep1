/*
 * twi.h
 *
 *  Created on: Feb 23, 2013
 *      Author: boaz
 */

#ifndef TWI_H_
#define TWI_H_
#include <stdint.h>
int twiReadExtMemN(char block,const unsigned int InternalAddr, char n, char *pdata);
int twiReadReg (const uint8_t addr, const uint8_t reg);
//int twiReadRegN (const uint8_t addr, const uint8_t reg, uint8_t n, void *pdata);
//int twiReadRegN(const uint8_t addr, const uint8_t reg, uint8_t n, uint8_t *pdata);
int twiWriteReg (const uint8_t addr, const uint8_t reg, const uint8_t data);
//int twiWriteRegN (const uint8_t addr, const uint8_t reg, uint8_t n, void *pdata);
int twiWriteRegN(const uint8_t addr, const uint8_t reg, uint8_t n, uint8_t *pdata);    
int twiWriteExtMemN(char block, unsigned int addr, unsigned char n, char *pdata);
//int twiWriteEEP(const char addr, char n, char *pdata);

void twiInit (void);

#endif /* TWI_H_ */
