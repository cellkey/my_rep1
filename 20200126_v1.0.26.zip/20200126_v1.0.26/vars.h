#ifndef VARS_H
#define VARS_H

//eeprom char eCombination = 0;




//char err_buf[ERR_BUF_SIZE];
int iLastMsr[MAX_SEN_NUM];
int iVoltage;
int heat_time = -1;
//int measure_time;
//int SensorResult;       //save the measuring result into variable
int_bytes union_b2i;
unsigned int now_in_minutes;     //time from day start in ninutes
//unsigned int pSens_Ctrl_Params;	//pointer to current sensor control parameters in ext_e2
//int AtoDSensResult;
//unsigned char adc_mux;
char e2_writeFlag;
BYTE rssi_val;
//unsigned char eepromReadBuf[16];	//buffer for eeprom read operation
char readClockBuf[7];	         //buffer for data reading from clock
BYTE modemCurTask;
BYTE modemCurSubTask;
//BYTE waitingTask;


BYTE mainTask;

BYTE dataSentOK;

BYTE toDoList;
BYTE NextByteIndex;
BYTE BytesToSend;
//BYTE modemAnswer;
//BYTE rx0_buff_len;
//unsigned char rx0_buff_len;
unsigned int rx0_buff_len;

char RxUart0Buf[MAX_RX_BUF_LEN];    //128
char ComBuf[MAX_TX_BUF_LEN]; // buffer for transmit (TX)

BYTE ModemResponse;
unsigned int timeCnt;
//BYTE lastByteIndex = 0;

unsigned int nMaxWaitingTime;
int TimeLeftForWaiting;
//unsigned int nextCompare;
bit overFlow = 0;
bit Message_Recieved;
bit Modem_Message_Recieved;
bit bExtReset;
bit bReset = 0;
bit bWaitForModemAnswer;
bit longAnswerExpected = 0;


#ifdef BlueToothOption
char bEndOfBTTask;
int nMaxWaitBtResponse = 0;
#endif BlueToothOption
bit bNeedToWait4Answer;
//bit bMoreDataToSend;         //sign if there is more data to send
BYTE bConnectOK;

//BYTE triggerCnt = 0;
//BYTE LedStatus[4];
//BYTE BlinkNum[4];
char cuurent_interval;  	//varible to hold the the current measuring interval
//unsigned char ICCID[MAX_ICCID_LEN];
//BYTE UpdatePrmArr[MAX_PRM_TASKS];

BYTE iFirstConnToday;
//unsigned char nUnreadBlocks;

//BYTE useExtInt1; //water meter interrupt
//BYTE bWatchDog;
//BYTE bQuickSleep;
BYTE nInt1Fired;

unsigned int wndSpdPulseCnt;
//unsigned int wtrPulseCnt;
unsigned int cpuWakeTimeCnt;
BYTE msrAlertFlag;
BYTE AlertStatus[MAX_SEN_NUM];





#endif VARS_H