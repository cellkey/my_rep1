#ifndef SMS_H
#define SMS_H

//-------scehdular op type-------
//#define RELAY_ON 0x00 
//#define RELAY_OFF 0x01  

#define REL1_ON 0x00    //jason key 1
#define REL1_OFF 0x01   //jason key 2
#define REL2_ON 0x02    //jason key 3
#define REL2_OFF 0x03   //jason key 4
#define SELF_CHECK 0x10  //jason key 5

#define RELAY1 0
#define RELAY2 1


typedef struct           //0200 address
 {        
          unsigned char op_type;         //relay1 on, off -relay2 on, off , self check+notif
          unsigned char allowed_weekday;  //bit for day -0x7F max  
          unsigned char day_start;     //1-31   
          unsigned char day_end; 
          unsigned char day_steps;
           unsigned char hour_start;    //0-23 
          unsigned char hour_end;
          unsigned char hour_steps;
          unsigned char min_start;     //0-59 
          unsigned char min_steps;                                            
  }
   Schedular_table;    //10 bytes
             
                
 typedef struct{             //01E0 address
        unsigned char relay_indx;     //relay index 
        unsigned char active_days;     //active days of weeks  
        unsigned char op_delay;       //delay duration
       
        unsigned int next_ON_time;     //time of starting minutes from midnight
        unsigned int next_OFF_time;     //time of ending process 
        unsigned int op_duration;    //current duaration  
        unsigned int last_op_time;    //last operation time redord - min from misnight
        unsigned char last_op_day;
        unsigned char last_op_dow;
    
}Relay_table;      //13 bytes

 typedef struct{   //0240 address
 
      char op_type;     
      unsigned int op_duration;
 } relay_emergency; 
 
  typedef struct{   //
 
      char year;
      char month;
      char day;
      char hour;
      char minute;
      char dow;     
    
 } clock_params; 
 
#endif SMS_H