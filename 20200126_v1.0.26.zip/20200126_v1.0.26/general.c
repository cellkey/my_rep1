////////////////start of General.c file//////////////
#include "define.h"
#include "rtc.h"
#include "uart.h"
#include "sms.h"

unsigned char  GetStatusReg(unsigned char mask);
void OpenRelay1 (void);
void OpenRelay2 (void);
void CloseRelay1 (void);
void CloseRelay2 (void);
void Wakeup_Status_Check(void);

extern void SendATCmd(flash unsigned char *bufToSend);
extern char RxUart0Buf[MAX_RX_BUF_LEN];
extern void SendATCmd(flash unsigned char *bufToSend);
extern unsigned char GetStatusReg(unsigned char mask);
extern void SetStatusReg(unsigned char mask, unsigned char val);
extern void rtc_get_date(unsigned char *day,unsigned char *month, unsigned char *year, unsigned char *weekday);
extern void rtc_get_time(unsigned char *hour,unsigned char *min, unsigned char *sec);
extern void twiInit (void);
extern  void ClearAF(void);
extern void OpenRelay2 (void);
extern void Sync_Led_Off(void);
extern void Modem_Sleep_EN(void);
extern char Modem_To_Sleep(void);
extern unsigned int SetRelayVars(char relay,char op);

extern flash unsigned char AT_CCLK[];
extern eeprom char cpue2_interval_1;
extern eeprom unsigned char eStartConnectionH;        //first connection hour
extern eeprom unsigned char eConnectionInDay;        //number on connectionsin a day
extern eeprom unsigned char eConnectIntervalH;        //intervalbetween connections (hours)
extern eeprom char unique_id[]; //sensors id
extern eeprom unsigned char NumSensors;
extern eeprom BYTE SensorType[];

extern eeprom char eTimeZone ;
extern eeprom char eFLAGS_STSTUS;
extern eeprom int MIN_LIMIT[MAX_SEN_NUM];
extern eeprom Schedular_table op_timing[6]; 
extern eeprom Relay_table Relay_vars[2];
extern eeprom relay_emergency Relay_Emerge[2];

char ErrorType = 0;;
//-----------------------------------------------------------------------------

extern int_bytes union_b2i;
extern char e2_writeFlag;
extern char readClockBuf[];	         //buffer for data reading from clock
extern char cuurent_interval;  	//varible to hold the the current measuring interval
extern char ComFailureCounter;
extern BYTE NextByteIndex;
extern BYTE mainTask;

extern BYTE toDoList;
extern BYTE bConnectOK;
extern BYTE modemCurTask;
extern BYTE dataSentOK;

extern BYTE BytesToSend;
//extern BYTE waitingTask;
extern BYTE iFirstConnToday;

extern BYTE nInt1Fired;


extern BYTE msrAlertFlag;
extern BYTE AlertStatus[MAX_SEN_NUM];
extern BYTE bPORT;
extern char ModemAgainCount;
extern char gHour;
extern char gMin;
extern char ComBuf[MAX_TX_BUF_LEN];
//extern unsigned int nextCompare;

extern int iVoltage;
extern int heat_time;
extern char TimeZone;
extern char ModemRepeatCount;
extern char WakeTest;
extern  char Timer0_Ticks;
extern char FlagsStatus;
extern unsigned int now_in_minutes;

//extern bit Modem_Message_Recieved;
extern bit bWaitForModemAnswer;
extern bit bExtReset;
//extern bit bNeedToWait4Answer;

extern bit bReset;
extern bit IsAlertNeeded;
extern bit IsAlertActivated;
extern bit PumpActivated;
extern bit ModemRepeatNeeded ;
extern bit ModemIsOn ;
extern bit RING_PULSE_ACTIVE;
extern bit DIGITAL_IN_ACTIVE;
extern  bit RelayEmergAct;
extern bit Modem_Message_Recieved;



  bit UnitWaked; 
  char gBUF[7];
long_bytes lb;


void SetTimer1_100ms(void)
{
        DISABLE_TIMER1();    //
     
        TCNT1H=0xFD;
        TCNT1L=0x1F;
     
        OCR1AH=0x00;
        OCR1AL=0x00;
   
        PRR_EN_TMR1();           // allow timer1 in PRR
        ENABLE_TIMER1();      //int every 100 mili ssec  
    
}

void  Init_Modem_Vars(void)
{
 //   SendDebugMsg("init modem vars..\r\n\0");  
    mainTask = TASK_MODEM;
    modemCurTask = TASK_NONE;      //modem to be activated
    Modem_Message_Recieved = FALSE;;
    bConnectOK = FALSE;
    dataSentOK = FALSE;   
//    nFailureCntr = 0; 
     SetTimer1_100ms();   //keep modem timing
     PRR_EN_UART0();           // allow uart0 in PRR
    ENABLE_UART0();  
 //   heat_time = 0; 
    Timer0_Ticks = 7;   // 7 x 35mS
    ENABLE_TIMER1();

}

void  Init_Modem_For_SMS(void)
{
   // SendDebugMsg("init modem SMS..\r\n\0");  
     mainTask = TASK_MODEM;
     modemCurTask = TASK_NONE;       //modem to be activated
 //    DTR_LOW;                //dtr low - modem alive
     SetTimer1_100ms();   //keep modem timing    
     ENABLE_TIMER1();
    PRR_EN_UART1();           // allow uart0 in PRR
    ENABLE_UART1();

}


 void Reset_Ext_WD(void)
 {
     PORTD.4 = 1;
     delay_ms(200);
     PORTD.4 = 0;
 }

void InitPeripherals()
{
  // Creystal -  7.372400 mhz    
  
   // USART0 initialization  fr modem
    // Communication Parameters: 8 Data, 1 Stop, No Parity
    // USART0 Receiver: On
    // USART0 Transmitter: On
    // USART0 Mode: Asynchronous
    // USART0 Baud Rate: 19200
    UCSR0A=(0<<RXC0) | (0<<TXC0) | (0<<UDRE0) | (0<<FE0) | (0<<DOR0) | (0<<UPE0) | (0<<U2X0) | (0<<MPCM0);
    DISABLE_UART0();
    UCSR0C=(0<<UMSEL01) | (0<<UMSEL00) | (0<<UPM01) | (0<<UPM00) | (0<<USBS0) | (1<<UCSZ01) | (1<<UCSZ00) | (0<<UCPOL0);
    UBRR0H=0x00;
   UBRR0L=0x17;   // modem Baud Rate: 19200  7.372400 mhz
   //  UBRR0L=0x0B;    //38400
  //  UBRR0L=0x03;   // modem Baud Rate: 115200 7.372400 mhz

    // USART1 initialization  fr BLE
    // Communication Parameters: 8 Data, 1 Stop, No Parity
    // USART1 Receiver: On
    // USART1 Transmitter: On
    // USART1 Mode: Asynchronous
    // USART1 Baud Rate: 115200
    UCSR1A=(0<<RXC1) | (0<<TXC1) | (0<<UDRE1) | (0<<FE1) | (0<<DOR1) | (0<<UPE1) | (0<<U2X1) | (0<<MPCM1);
    UCSR1B=(1<<RXCIE1) | (0<<TXCIE1) | (0<<UDRIE1) | (1<<RXEN1) | (1<<TXEN1) | (0<<UCSZ12) | (0<<RXB81) | (0<<TXB81);
    UCSR1C=(0<<UMSEL11) | (0<<UMSEL10) | (0<<UPM11) | (0<<UPM10) | (0<<USBS1) | (1<<UCSZ11) | (1<<UCSZ10) | (0<<UCPOL1);
    UBRR1H=0x00;
    UBRR1L=0x03;  //BLE baud 115200

     
 
// ADC initialization
// ADC Clock frequency: 28.800 kHz
// ADC Voltage Reference: 2.56V, cap. on AREF
// ADC Auto Trigger Source: Free Running
// Digital input buffers on ADC0: Off, ADC1: Off, ADC2: Off, ADC3: On
// ADC4: Off, ADC5: Off, ADC6: Off, ADC7: Off
DIDR0=(1<<ADC7D) | (1<<ADC6D) | (1<<ADC5D) | (1<<ADC4D) | (0<<ADC3D) | (1<<ADC2D) | (1<<ADC1D) | (1<<ADC0D);

ADCSRA=(0<<ADEN) | (0<<ADSC) | (0<<ADATE) | (0<<ADIF) | (0<<ADIE) | (1<<ADPS2) | (1<<ADPS1) | (1<<ADPS0);
ADCSRB=(0<<ADTS2) | (0<<ADTS1) | (0<<ADTS0);

    // SPI initialization
    // SPI disabled
    SPCR=(0<<SPIE) | (0<<SPE) | (0<<DORD) | (0<<MSTR) | (0<<CPOL) | (0<<CPHA) | (0<<SPR1) | (0<<SPR0);
     twiInit();

}

//SET PINS AFTER WAKEUP -CREACELL 2
void InitIOs(void)
{


    DDRA=0x00;    //octopus board
    PORTA=0x00;

    DDRB=0x0B;
    PORTB=0x08;   //dtr high

    DDRC=0xF1;
    PORTC=0x03;

    DDRD=0xCA;
    PORTD=0x00;

}

//void WakeUpProcedure(void)
//{
//  //  BYTE gPORT;
//  int Next_Wake_Min;
//  //   DDRC.7 = 1;
//
//    InitIOs();     //new 130715
//                  // allow uart1 in PRR
////     MUX_PIN_0(2);
////     MUX_PIN_0(3);
//
//     PRR = 0x00;           // allow TWI in PRR
//  
//     UnitWaked = TRUE;
//
//     delay_ms(50);
//     twiInit ();
//
//     ClearAF();         //reset rtc int flag
//     delay_ms(5);
//
// //   InitPeripherals();  
////    SetTimer1_100ms(); 
////    Timer0_Ticks = 4;       //4x70mS OVF int counter
//
//    if( WakeTest == 2)   //clock pulse
//    delay_ms(500); 
//    
//    SendDebugMsg("\r\nWakeup cause \0");
//    PrintNum(WakeTest); 
//  
//    
//     //reset it
//    DISABLE_UART0();
// 
// //   delay_ms(500);
//      rtc_get_timeAll (readClockBuf);     //new - Danny
//      RTCgetDate();                      //show for debug
//      ENABLE_UART0();
//                   
//	//set condition for rtc communication
//     SPCR=0x00; //reset spi control register
//    bWaitForModemAnswer = FALSE;   
//    Modem_Message_Recieved = FALSE;
//    bNeedToWait4Answer = TRUE; 
//     
// //------------wake - check why-----------------   
//     if(WakeTest == 2)     //wake from RTC count down int -arm unit when sleep
//     {   
////          FlagsStatus =  eFLAGS_STSTUS;
////         if( GetStatusReg(UNIT_ARM_PEND))   //delay period expired?
////         {                               
////              Arm_Pending = FALSE;         //                   
////              UNIT_IS_ARMED = TRUE;  
////              RTC_Setup();                //set for regular activity  
////              SetStatusReg(UNIT_ARM_PEND | UNIT_ARMED ,UNIT_ARMED);  NEW_BLE_UNIT
////              eFLAGS_STSTUS =  FlagsStatus;
////              mainTask = TASK_SLEEP;  
////              SendDebugMsg("Arm delay expiered..Armed..\r\n\0");
////              return; 
////         }
////         else  //clock int - periodic wake for self check
////         {
////            SendDebugMsg("Periodic wake for self check\r\n\0");
////         }  
//         
//           Wakeup_Status_Check();
//         
//           Next_Wake_Min = SetRelayVars(RELAY1,REL1_ON);  //0
//           Relay_vars[0].next_ON_time = Next_Wake_Min; 
//            
//           Next_Wake_Min = SetRelayVars(RELAY1,REL1_OFF);
//           Relay_vars[0].next_OFF_time = Next_Wake_Min; 
////            SendDebugMsg("Next_Wake_Min OFF= \0"); 
////            PrintNum((long)Next_Wake_Min);    
//     } 
//    else  if(WakeTest == 5) 
//    {    
//         WakeTest = 0;  
//         PrintNum((long)MIN_LIMIT[0]);
//         if(RING_PULSE_ACTIVE == TRUE)
//        {     
//             DISABLE_PA0_INT();
//             SendDebugMsg("Receiving SMS..\r\n\0");
//             delay_ms(100); 
//             Init_Modem_For_SMS();  //handle SMS message  
//         
//             return;
//        } 
//        else if(DIGITAL_IN_ACTIVE == TRUE)   //sensor coused int
//        {      
//               delay_ms(1000);     //filter
//            
//               if(PINA.0 == 0)
//               {        
//                   SendDebugMsg("Sensor Activated ..\r\n\0"); 
//                   FlagsStatus =  eFLAGS_STSTUS; 
//                   if(Relay_Emerge[RELAY1].op_type == REL1_ON)  //check emergancy relays activations
//                   {      
//                          
//                           CloseRelay1();          //relay on
//                           SetStatusReg(RELAY1_ON , RELAY1_ON);                          
//                           Relay_vars[RELAY1].next_OFF_time = now_in_minutes + Relay_Emerge[RELAY1].op_duration;
//                           SendDebugMsg("Relay1 ON, \0"); //debbug 
//                   } 
//                   else
//                   {
//                           OpenRelay1();       //realy off???
//                           SetStatusReg(RELAY1_ON , 0); 
//                           
//                           if(Relay_Emerge[RELAY1].op_duration > 0)                            
//                           Relay_vars[RELAY1].next_ON_time = now_in_minutes + Relay_vars[RELAY1].op_duration; 
//                           SendDebugMsg("Relay1 OFF, \0"); //debbug
//                   }  
//                   
//                    if(Relay_Emerge[RELAY2].op_type == REL2_ON)
//                   {
//                           OpenRelay2(); 
//                           SetStatusReg(RELAY2_ON , RELAY2_ON);
//                            Relay_vars[RELAY2].next_OFF_time = now_in_minutes +Relay_Emerge[RELAY2].op_duration; 
//                           SendDebugMsg("Relay2 ON, \0"); //debbug 
//                   } 
//                   else
//                   {
//                           OpenRelay2(); 
//                           SetStatusReg(RELAY2_ON , 0); 
//                           if(Relay_Emerge[RELAY2].op_duration > 0) 
//                           Relay_vars[RELAY2].next_ON_time = now_in_minutes + Relay_vars[RELAY2].op_duration;
//                           SendDebugMsg ("Relay2 OFF, \0"); //debbug  
//                   } 
//                    SendDebugMsg (" due to sensor atctivation..\r\n\0"); //debbug   
//                    eFLAGS_STSTUS =  FlagsStatus;
//                    Relay_vars[RELAY1].op_duration = Relay_Emerge[RELAY1].op_duration; 
//                    Relay_vars[RELAY2].op_duration = Relay_Emerge[RELAY2].op_duration;
//                    RelayEmergAct = TRUE;    //situation flag 
//                    delay_ms(100);
//                    Init_Modem_For_SMS();  
//                                 
//                    return; 
//               }                               
//        } 
//            
//    }
//    eFLAGS_STSTUS = FlagsStatus ; 
//   mainTask = TASK_SLEEP;    //test HW
//     WakeTest = 0; 
//    if (mainTask != TASK_SLEEP)
//    {
//        #pragma optsize-
//        #asm("wdr")
//        WATCHDOG_ENABLE_STEP1();
//        WATCHDOG_ENABLE_STEP2();
//        #ifdef _OPTIMIZE_SIZE_
//        #pragma optsize+
//        #endif
//    }
//
//}
//


void PwrDwn(void)
{
   
//    EIFR=0x04;
//    EIMSK=0x04;

    PRR = 0x7F;
    SMCR |= 4;
    SMCR |= 1;  
    
//    ENABLE_PA2_INT();  //RING signal wakeup
//    ENABLE_PA0_INT();  //diigtal input wakeup

    #asm("sei"); 
    #asm
    sleep
    #endasm
    #asm ("nop\nop"); 		//wakeup from sleep mode

}

void PowerDownSleep( void )
{
 //   char t;   
    
    bExtReset = FALSE;     
    SendDebugMsg("\r\nGo2Sleep\r\n\0");
   
 //  if(MODEM_IS_ON)
   {     
       //  SendDebugMsg("Modem to sleep..\r\n\0");  
     
         Sync_Led_Off();      //modem status led       
         
//       t = (PINA );  //check modem status - must CTS high  
//       if(t & 0x02 )
//        SendDebugMsg("Modem Sleep..\r\n\0"); 
//        else   SendDebugMsg("CTS low..\r\n\0"); 
   } 
   
     Modem_Sleep_EN();  //CFUN=5
     Modem_To_Sleep(); 
     
     ModemIsOn = FALSE ;  
    Reset_Ext_WD();       //reset the ext WD chip
  
     
    DDRA=0x00;
    PORTA=0x00;

  DDRB=0x08;
    PORTB=0x08;

    DDRC=0x00;
    PORTC=0x00;
    
    DDRD=0xFA;
    PORTD=0x40; //dtr high- modem pwr dwn 
     LED1_OFF;   
     
       #asm("cli");
    DISABLE_TIMER0();
    DISABLE_TIMER1(); 
    DISABLE_TIMER2();
  //  DISABLE_UART1(); 
  
  
 //   DISABLE_PA2_INT() 
   PCICR=(0<<PCIE3) | (0<<PCIE2) | (0<<PCIE1) | (1<<PCIE0);
   PCIFR=(0<<PCIF3) | (0<<PCIF2) | (0<<PCIF1) | (1<<PCIF0);
  ENABLE_PA2_INT();  //RING signal wakeup ------------- 
; 
    
//     if(UNIT_IS_ARMED)    //enable sensor input if armed     
//     ENABLE_PA0_INT();  //diigtal input wakeup
                  
     EIFR |= (1<<INTF2) ;
     ENABLE_CLOCK_INT(); // enable external interrupt2 //Danny
    
   //   PRR_SHUTOFF();
      UnitWaked = FALSE;  
      ModemIsOn = FALSE ;         
      LED1_OFF;   
      #asm("sei"); 
//       _putchar1('&'); 
       
       WDT_off(); 
       delay_ms(10); 

       PwrDwn();


}








//the function recieve pointer to buf
//buf[0]=hi_byte, buf[1]=lo_byte
//the function return int (address) combined from 2 bytes
int bytes2int(char* buf)
{
	//set 2 bytes into union
	union_b2i.bval[0] = buf[0];
	union_b2i.bval[1] = buf[1];

	return union_b2i.ival;
}

//the function recieve int (address) and pointer to buf
//the function set into buf[0] the hi_address_byte
//and into buf[1] the lo_address_byte
void int2bytes(int int_pointer, char* buf)
{
	union_b2i.ival = int_pointer;
	//set 2 bytes into buf
	buf[0] = union_b2i.bval[0];
	buf[1] = union_b2i.bval[1];
}

// #monitor
//the function recieve pointer to buf
//buf[0]=hi_byte, buf[1]=lo_byte
//the function return int (address) combined from 2 bytes
long Bytes2Long(char* buf)
{
	//set 4 bytes into union
	lb.bVal[0] = buf[0];
	lb.bVal[1] = buf[1];
	lb.bVal[2] = buf[2];
	lb.bVal[3] = buf[3];

	return lb.lVal;
}

//the function recieve int (address) and pointer to buf
//the function set into buf[0] the hi_address_byte
//and into buf[1] the lo_address_byte
void Long2Bytes(long l, char* buf)
{
	lb.lVal = l;
	//set 2 bytes into buf
	buf[0] = lb.bVal[0];
	buf[1] = lb.bVal[1];
	buf[2] = lb.bVal[2];
	buf[3] = lb.bVal[3];
}

//copy from cpu e2 into buf
void cpu_e2_to_MemCopy( BYTE* to, char eeprom* from, BYTE length)
{
	BYTE i;
	for(i = 0; i < length; i++)
		to[i] = from[i];
}

//copy from ram buf into cpu e2
void MemCopy_to_cpu_e2( char eeprom* to, BYTE* from, BYTE length)
{

	BYTE i;
	for(i = 0; i < length; i++)
		to[i] = from[i];
}


void MemCopy( BYTE* to, BYTE* from, BYTE length)
{
	BYTE i;
	for(i = 0; i < length; i++)
		to[i] = from[i];
}


//copy from cpu flash into buf
void cpu_flash_to_MemCopy( BYTE* to, char flash* from, BYTE length)
{
	BYTE i;
	for(i = 0; i < length; i++)
		to[i] = from[i];
}

//copy flash buf to buffer. return num of  copy bytes
BYTE CopyFlashToBuf( BYTE* to, char flash* from)
{
    BYTE index = 0;
    while (from[index] != '@')
    {
        to[index] = from[index];                      //"425#"
        index++;
    }
    return index;
}

//checksum with parameter
// 0 = check_sum ^
// 1 = check_sum +
BYTE CheckSum( BYTE *buff, BYTE length, BYTE param )
{
        BYTE check_sum;

        check_sum = 0;
        while (length--)
        {
                //filter the "246 (F6)" for gprs modem ??
                if(param)
                {
                    check_sum += *buff++;
                }

                else
        	        check_sum ^= *buff++;
        }
        return (check_sum);
}


//the function will set address into 'pSens_Ctrl_Params' and 'pSens_cpu_e2'
// (int global variables define in data manager module)
//void SetCotrolParamAddress()
//{
//    //pSens_Ctrl_Params = sens1_control_param;
//    // POINT TO 16 BYTES BEFORE END OF DATA BLOCK
//    pSens_Ctrl_Params = (unsigned int) (SENSOR_MEMORY_START + (unsigned int)((objToMsr + 1) * SENSOR_MEMORY_SIZE) - SENSOR_CNTRL_PRM_SIZE);
//}

void InitProgram(void)
{
 //   unsigned char  data_not_valid = 0;
    // Crystal Oscillator division factor: 1

    #pragma optsize-
    CLKPR=(1<<CLKPCE);
    CLKPR=(0<<CLKPCE) | (0<<CLKPS3) | (0<<CLKPS2) | (0<<CLKPS1) | (0<<CLKPS0);
    #ifdef _OPTIMIZE_SIZE_
    #pragma optsize+
    #endif

    

    DDRA=0x00;    //octopus board
    PORTA=0x00;

  DDRB=0x0C;
    PORTB=0x08;

    DDRC=0xF1;
    PORTC=0x03;

    DDRD=0xCA;
    PORTD=0x00;
 
    
// Timer/Counter 0 initialization
// Clock source: System Clock
// Clock value: 7.200 kHz
// Mode: Normal top=0xFF
// OC0A output: Disconnected
// OC0B output: Disconnected
// Timer Period: 10 ms
TCCR0A=(0<<COM0A1) | (0<<COM0A0) | (0<<COM0B1) | (0<<COM0B0) | (0<<WGM01) | (0<<WGM00);
TCCR0B=(0<<WGM02) | (1<<CS02) | (0<<CS01) | (1<<CS00);
TCNT0=0xB8;    //Timer Period: 10 ms
OCR0A=0x00;
OCR0B=0x00;



// Timer/Counter 1 initialization
// Clock source: System Clock
// Clock value: 7.200 kHz
// Mode: Normal top=0xFFFF
// OC1A output: Disconnected
// OC1B output: Disconnected
// Noise Canceler: Off
// Input Capture on Falling Edge
// Timer Period: 0.10236 s
// Timer1 Overflow Interrupt: On
// Input Capture Interrupt: Off
// Compare A Match Interrupt: Off
// Compare B Match Interrupt: Off
 DISABLE_TIMER1();
TCCR1A=(0<<COM1A1) | (0<<COM1A0) | (0<<COM1B1) | (0<<COM1B0) | (0<<WGM11) | (0<<WGM10);
//TCCR1B=(0<<ICNC1) | (0<<ICES1) | (0<<WGM13) | (0<<WGM12) | (1<<CS12) | (0<<CS11) | (1<<CS10);
TCNT1H=0xFD;
TCNT1L=0x1F;
ICR1H=0x00;
ICR1L=0x00;
OCR1AH=0x00;
OCR1AL=0x00;
OCR1BH=0x00;
OCR1BL=0x00;





// Timer/Counter 2 initialization
// Clock source: System Clock
// Clock value: 7.200 kHz
// Mode: Normal top=0xFF
// OC2A output: Disconnected
// OC2B output: Disconnected
// Timer Period: 35.556 ms
ASSR=(0<<EXCLK) | (0<<AS2);
TCCR2A=(0<<COM2A1) | (0<<COM2A0) | (0<<COM2B1) | (0<<COM2B0) | (0<<WGM21) | (0<<WGM20);
//TCCR2B=(0<<WGM22) | (1<<CS22) | (1<<CS21) | (1<<CS20);
DISABLE_TIMER2();   //timer off
TCNT2=0x00;
OCR2A=0x00;
OCR2B=0x00;


    // Timer/Counter 0 Interrupt(s) initialization
    TIMSK0=(0<<OCIE0B) | (0<<OCIE0A) | (1<<TOIE0);

   // Timer/Counter 1 Interrupt(s) initialization
    TIMSK1=(0<<ICIE1) | (0<<OCIE1B) | (0<<OCIE1A) | (1<<TOIE1); //over flow int 

    // Timer/Counter 2 Interrupt(s) initialization
    TIMSK2=(0<<OCIE2B) | (0<<OCIE2A) | (1<<TOIE2);
   
// External Interrupt(s) initialization
// INT0: Off
// INT1: Off
// INT2: On       //clock int
// INT2 Mode: Falling Edge
// Interrupt on any change on pins PCINT0-7: On
// Interrupt on any change on pins PCINT8-15: Off
// Interrupt on any change on pins PCINT16-23: On
// Interrupt on any change on pins PCINT24-31: Off
EICRA=(1<<ISC21) | (0<<ISC20) | (0<<ISC11) | (0<<ISC10) | (0<<ISC01) | (0<<ISC00);
EIMSK=(1<<INT2) | (0<<INT1) | (0<<INT0);
EIFR=(1<<INTF2) | (0<<INTF1) | (0<<INTF0);
//PCMSK0=(1<<PCINT7) | (0<<PCINT6) | (0<<PCINT5) | (0<<PCINT4) | (0<<PCINT3) | (1<<PCINT2) | (0<<PCINT1) | (1<<PCINT0);
PCMSK0=(0<<PCINT7) | (0<<PCINT6) | (0<<PCINT5) | (0<<PCINT4) | (0<<PCINT3) | (1<<PCINT2) | (0<<PCINT1) | (0<<PCINT0);  //enable pa.2
PCMSK2=(0<<PCINT23) | (0<<PCINT22) | (0<<PCINT21) | (0<<PCINT20) | (0<<PCINT19) | (0<<PCINT18) | (0<<PCINT17) | (0<<PCINT16);
PCICR=(0<<PCIE3) | (1<<PCIE2) | (0<<PCIE1) | (1<<PCIE0);
PCIFR=(0<<PCIF3) | (1<<PCIF2) | (0<<PCIF1) | (1<<PCIF0);

ENABLE_PC2_INT();

  InitPeripherals();


    // Analog Comparator initialization
    // Analog Comparator: Off
    ACSR=(1<<ACD) | (0<<ACBG) | (0<<ACO) | (0<<ACI) | (0<<ACIE) | (0<<ACIC) | (0<<ACIS1) | (0<<ACIS0);
    ADCSRB=(0<<ACME);
    DIDR1=0x00;

    // Watchdog Timer initialization
    // Watchdog Timer Prescaler: OSC/1024k
    // Watchdog Timer interrupt: On
    MCUSR |= (1<<WDRF);
#pragma optsize-
    #asm("wdr")
    WATCHDOG_ENABLE_STEP1();
    WATCHDOG_ENABLE_STEP2();
#ifdef _OPTIMIZE_SIZE_
#pragma optsize+
#endif

    msrAlertFlag = 0;

 #asm("sei");
 
}

char SyncTiming(int e2_interval_val)
{
    char res = FALSE;
    //if it is 24:00
    if((readClockBuf[4] == 0)&&(readClockBuf[5] == 0))
        return TRUE;

    switch(e2_interval_val)
    {
         //if it is 5 minutes interval:
          case (5):
            if(readClockBuf[5]%5 == 0)
                res = 1;
            break;
        //if it is 10 minutes interval:
        case (10):
            if(readClockBuf[5]%10 == 0)
                res = 1;
            break;
        //if it is 20 minutes interval:
        case (20):
            if(readClockBuf[5]%20 == 0)
                res = 1;
            break;
        //if it is 30 minutes interval:
        case (30):
            if(readClockBuf[5]%30 == 0)
                res = 1;
            break;
        //if it is round hour and 60 minutes interval:
        case (60):
            if(readClockBuf[5] == 0)
                res = 1;
            break;
        //if it is 120 minutes interval:
        case (120):
            if(readClockBuf[5] == 0)
            {
                if(readClockBuf[4] % 2 == 0)
                    res = 1;
            }
            break;
        //if it is 240 minutes interval:
        case (240):
            if(readClockBuf[5] == 0)
            {
                if(readClockBuf[4] % 4 == 0)
                    res = 1;
            }
            break;
    }

    //if it is not a measuring time
    return res;
}
/*
//check_measuring_interval_time
BYTE IsTimeToMeasure(void)
{
	int e2_interval; //, round_minute;

//     SendDebugMsg("\r\nIsTimeToMeasure...\r\n\0 ");
    // if there are no defined sensors yet - do not measure
    if (NumSensors == 0)
    {
             return FALSE;
    }


	//read the rtc
    e2_writeFlag = 0;   //enable reading the rtc
	//delay_ms(10);       //let stabilate the cpu oscilator


//-->	GetRealTime();

    
	//check for mesuring timing:
    e2_interval = ((int)cpue2_interval_1 * INTERVAL_PARAM);

   

    //if minute is not "0" or minute modulo by "10" is not "0": disable measuring cycle
     if (readClockBuf[5] != 0)
      if ((readClockBuf[5] % MEASURE_INTERVAL) != 0)      //demo- measure every
      {
         bTimeToMeasure = FALSE;		//reset the msr flag
      }
 
    return bTimeToMeasure;
}

 */
///////////   -ORIGINAL, KEEP

//check_measuring_interval_time
//BYTE IsTimeToMeasure(void)
//{
//	int e2_interval; //, round_minute;
//    // if there are no defined sensors yet - do not measure
//    if (NumSensors == 0)
//        return FALSE;
//
//	//read the rtc
//    e2_writeFlag = 0;   //enable reading the rtc
//	delay_ms(10);       //let stabilate the cpu oscilator
//
//    rtc_get_timeAll (readClockBuf);     //new - Danny
////-->	GetRealTime();
//
//      bTimeToMeasure = FALSE;
//
//	//sens1_interval++;
//    e2_interval = ((int)cpue2_interval_1 * INTERVAL_PARAM);
//    // if u-normal value was found - measure every 10 minutes
//    if (msrAlertFlag > 0)
//        e2_interval = 10;
//
//	//check for mesuring timing:
//    if(SyncTiming(e2_interval) == 1)
//        bTimeToMeasure = TRUE;
//
//    //if minute is not "0" or minute modulo by "10" is not "0": disable measuring cycle
//    if (readClockBuf[5] != 0)
//        if (readClockBuf[5] % 10 != 0)
//            bTimeToMeasure = FALSE;		//reset the msr flag
//    //reset water pulse counter at midnight
//    if ((readClockBuf[4] == 0) && (readClockBuf[5] == 0))  //midnight
//        wtrPulseCnt = 0;
//
//    return bTimeToMeasure;
//}

BYTE IsTimeToConnectGPRS()
{
    BYTE i, t, nextConH, CyclesAday;
    iFirstConnToday = FALSE;

//   //===============================
  // return TRUE;      //call server every measurement
//   //=======================
     #ifdef DebugMode
     if( IsAlertNeeded == TRUE)
     SendDebugMsg("IsAlertNeeded = TRUE..\r\n\0 ");   //Danny for debug
     else SendDebugMsg("IsAlertNeeded = FALSE..\r\n\0 ");   //Danny for debug
       if( IsAlertActivated == FALSE)
     SendDebugMsg("IsAlertActivated = FALSE..\r\n\0 ");   //Danny for debug
     else SendDebugMsg("IsAlertActivated = TRUE..\r\n\0 ");   //Danny for debug
//       if( ComDelayNeeded == FALSE)
//     SendDebugMsg("Com Delay Needed = FALSE..\r\n\0 ");   //Danny for debug
//     else SendDebugMsg("Com Delay Needed = TRUE..\r\n\0 ");   //Danny for debug
     if(PumpActivated == TRUE)
     SendDebugMsg("Bottle is full..\r\n\0 ");
     else  SendDebugMsg("Bottle is empty..\r\n\0 ");
     #endif DebugMode

  //    rtc_get_timeAll (readClockBuf);       //needed? clock is in buf already
//       SendDebugMsg("\r\nHour nowt = ");
//       PrintNum(readClockBuf[4]);


  
 

//check if COMM now
    CyclesAday = eConnectionInDay ;
    //calculate the next hour for wakeup:
    for (i = 0; i < CyclesAday; i++)
    {
        //nextH = (int)startH + ((int)CycleInterval * i);
        t = i * eConnectIntervalH;
        nextConH = eStartConnectionH + t;
        if(nextConH  >= 24 )
        nextConH -= 24;

         if (readClockBuf[4] == nextConH)     //Curent HOUR value and after first measure of that hour
        {
               if (i == 0)//  if its first connection for today
                iFirstConnToday = TRUE;     //not used by Creacell
                if (readClockBuf[5] < 3 ) //== (CONNECTING_MINUTE ))  //max 3 minute offset from the hour
                {
                  //  toDoList = DO_DATA;
                    ComFailureCounter = 0;
                    SendDebugMsg("\r\n** Scheduled Server Communication **\r\n\0 ");
                    ModemAgainCount = 0;
                    ModemRepeatCount = 0;
                    //  PrintNum(readClockBuf[4]);
                      return TRUE;
                }
         }

                 
     }

    return FALSE;
}



//convert int less than 1000000 to string and send string to uart1
void PrintNum(long val)
{
    char s[6];
    BYTE i = 0;
    long tVAL;


    tVAL = val;
    if (tVAL < 0)
    {
         _putchar1('-');
        tVAL *= -1;
    }

    do
    {
        s[i++] = (char)(tVAL % 10);
        tVAL = tVAL / 10;
    }
    while (tVAL > 0);
    for (; i > 0; i--)
    _putchar1(s[i-1] + 48);
     _putchar1('\n');
     _putchar1('\r');
}

void PrintNum2(unsigned long val)
{
    char s[12];
    BYTE i = 0;
    unsigned long tVAL;

    tVAL = val;

    do
    {
        s[i++] = (char)(tVAL % 10);
        tVAL = tVAL / 10;
    }
    while (tVAL > 0);
    for (; i > 0; i--)
    _putchar1(s[i-1] + 48);
//     _putchar1('\n');
//     _putchar1('\r');
}

 void Num2String_Modem(long val)
{
    char buf[6];
    BYTE i,k = 0;
    long tVAL;

    tVAL = val;
     do
    {
        buf[i++] = (char)(tVAL % 10) + 0x30;
        tVAL = tVAL / 10;
    }
    while (tVAL > 0);

    for (k = 0; i > 0; k++, i--)
     gBUF[k] = buf[i-1] ;

     gBUF[k++] = (0x0D);
     gBUF[k] = (0x0A);
   //  gBUF[k] = '\0' ;
}

void SendDebugMsg(flash  char *bufToSend)
{
    BYTE i;

    i = 0;

    //copy flash string to buff
    while (bufToSend[i] != '\0')
    {
         ComBuf[i] = bufToSend[i];
         // _putchar1(ComBuf[i]);
         i++;
    }
    BytesToSend = i ;

    //transmitt to local modem port
    TransmitBuf(1);

}


void WDT_off(void)
{
    //__disable_interrupt();
	#asm ("wdr"); 		//reset the watchdog
    /* Clear WDRF in MCUSR */
    MCUSR &= ~(1<<WDRF);
    /* Write logical one to WDCE and WDE */
    /* Keep old prescaler setting to prevent unintentional time-out */
    WDTCSR |= (1<<WDCE) | (1<<WDE);
    /* Turn off WDT */
    WDTCSR = 0x00;
    //__enable_interrupt();
}


//read clk to UART_RxBuf



//extern unsigned char GetStatusReg(unsigned char mask);
//extern void SetStatusReg(unsigned char mask, unsigned char val);


unsigned char  GetStatusReg(unsigned char mask)
{
	return (FlagsStatus & mask);
}

void SetStatusReg(unsigned char mask, unsigned char val)
{
	FlagsStatus &= ((~mask) | val);
	FlagsStatus |= (mask & val);
}


void CloseRelay2 (void)
{
   
       PORTC.5 = 0;      
       PORTC.4 = 1;
       delay_ms(250);
       PORTC.4 = 0; 

}

void OpenRelay2 (void)
{
         PORTC.4 = 0;                 
         PORTC.5 = 1;     //
          delay_ms(500);
       //  PORTC.5 = 0;
}

void CloseRelay1 (void)
{      
     
        DDRC.7 = 1;
        delay_ms(10);
        PORTC.7 = 1;     //
        delay_ms(150);
        PORTC.7 = 0;
}
//adapted to Eazygate
void OpenRelay1 (void)
{
      
      delay_ms(100);
      DDRC.6 = 1;       //output
      PORTC.6 = 1;
       delay_ms(150);
      PORTC.6 = 0;  

}


//adapted to new IOEXP 17/03/15
//activation of switch of battery voltage measurement
void BatLevel_ON(void)
{

   BAT_SW_PIN_OUT() ;//   
   BAT_LEVEL_SW_ON() ;//
 //  PORTC.2=1;
     delay_ms(30);
}

//adapted to new IOEXP 17/03/15
void BatLevel_OFF(void)
{       
    BAT_LEVEL_SW_OFF();
}



//  struct   op_timing[6]               //0x0200 address
//          unsigned char op_type;         //relay1 on, off -relay2 on, off , self check+notif
//          unsigned char min_start;     //0-59 
//          unsigned char min_steps; 
//          unsigned char hour_start;    //0-23 
//          unsigned char hour_end;
//          unsigned char hour_steps;
//          unsigned char day_start;     //1-31 
//          unsigned char day_end;
//          unsigned char day_steps;             
//          unsigned char allowed_weekday;  //bit for day -0x7F max 

//  struct   Relay_vars[2]               //01E0 ddress
//         unsigned char relay_indx;     //relay index 
//        unsigned char active_days;     //active days of weeks  
//        unsigned char op_delay;       //delay duration
//       
//        unsigned int next_ON_time;     //time of starting minutes from midnight
//        unsigned int next_OFF_time;     //time of ending process 
//        unsigned int op_duration;    //current duaration  
//        unsigned int last_op_time;    //last operation time redord - min from misnight
//        unsigned char last_op_day;
//        unsigned char last_op_dow;   
     
unsigned int SetRelayVars(char relay,char op)
{
     char indx; 
     unsigned int  NextOpTotalMin, next_minute;
     unsigned char hour, min,  sec; 
     unsigned char day, month, year,  weekday;
     char day_start, day_end, day_steps, hour_start, hour_end, hour_steps, min_start, min_steps;  
     char next_hour, tmp; 
     char str1[80];
     bit weekday_allowed = FALSE; 
     bit today_allowed = FALSE; 
     bit Skip_day = TRUE; 
    #define HOURS_IN_DAY 23   
    #define MIN_IN_HOUR 59   
    


     SendDebugMsg("Set relays op time..\r\n\r\n\0");  
     
//   op_timing[op].day_start = 1;
//   op_timing[op].day_end = 31; 
//   op_timing[op].day_steps = 1;  
//   op_timing[op].hour_start = 6;
//   op_timing[op].hour_end = 18;
//    op_timing[op].hour_steps = 1;
//    op_timing[op].min_start = 0;
//    op_timing[op].min_steps = 10;

  
//read eerom struct   
     day_start  = op_timing[op].day_start;
     day_end    = op_timing[op].day_end; 
     day_steps  = op_timing[op].day_steps;  
     hour_start = op_timing[op].hour_start;
     hour_end   = op_timing[op].hour_end;
     hour_steps = op_timing[op].hour_steps;
     min_start  = op_timing[op].min_start;
     min_steps  = op_timing[op].min_steps; 
     

//     day_start  = 1;
//     day_end    = 30; 
//     day_steps  = 1;
//     hour_start = 8;
//     hour_end   = 18;
//     hour_steps = 1;
//      min_start  = 5;
//       min_steps  = 30;   
//     op_timing[op].allowed_weekday = 0xFF;   
     
     
                  
     NextOpTotalMin = 0; 
     Skip_day = TRUE;
     rtc_get_time(&hour,&min,&sec);
     rtc_get_date(&day,&month,&year,&weekday);
     now_in_minutes = (int)hour*60 + min;   
      
      sprintf(str1, "Now: %02d:%02d, %02d/%02d day: %02d\r\n\0",hour,min,day,month,weekday+1);  //debug
      UART1_WriteMsg(str1);  
        sprintf(str1, "now_in_minutes = %d\r\n\r\n\0",now_in_minutes);  //debug
      UART1_WriteMsg(str1); 
    
      sprintf(str1, "day start: %d- day_end: %d- day_steps: %d\r\n\0", day_start,day_end,day_steps);  //debug
      UART1_WriteMsg(str1);
      sprintf(str1, "hour start: %d- hour_end: %d- hour_steps: %d\r\n\0", hour_start,hour_end,hour_steps);  //debug
      UART1_WriteMsg(str1); 
      
      sprintf(str1, "min start: %d- min_steps: %d\r\n\0", min_start,min_steps);  //debug
      UART1_WriteMsg(str1);        
         
    
   
      if(op_timing[op].allowed_weekday & (1 << weekday))  //today ok
      {
          weekday_allowed = TRUE;         
      };
//      Relay_vars[relay].active_days = op_timing[op].allowed_weekday;   //allowed day of week   
      
     if( weekday_allowed)
     {    
         SendDebugMsg("weekday_allowed = TRUE..\r\n\0");
         if((day >= day_start) && (day <= day_end) )   //if day in days range
         {
             for(indx = day_start; indx <= day_end ; indx += day_steps)  //look for next day available
             {
                 if(indx == day)  //today allowed 
                 {   
                     today_allowed = TRUE;  
                      SendDebugMsg("today_allowed = TRUE..\r\n\0");
                     break;                  
                 }               
             }
                   
              if(today_allowed == TRUE)
              {  
                  if(( hour  >= hour_start) && (hour  <= hour_end))   //still in hours range
                  { 
                      indx = 0;
                      while(((hour_start + (indx * hour_steps)) < hour) && ((indx * hour_steps) <= HOURS_IN_DAY)) //look for first allowed hour today
                      indx++;
                      
                      if((indx * hour_steps) <= HOURS_IN_DAY)  //hour available
                      {
                        
                         next_hour = hour_start + (indx * hour_steps);                //set new op time  
                         if(next_hour == hour)    //check if if still op in that hour
                         {   
                             SendDebugMsg("op at current hour..\r\n\0"); 
                             
                             tmp =  (MIN_IN_HOUR - min_start) /min_steps;                           
                             if(min >= (min_start + min_steps *tmp))  //no more op in that our 
                             {    
                                  next_hour += hour_steps; 
                               //   NextOpTotalMin += ((int)next_hour *60 - now_in_minutes + min_start); 
                                   NextOpTotalMin += ((int)next_hour *60 + min_start);
                                  
                                   SendDebugMsg("min steps expired\r\n\0");                                                                 
                             } 
                             else  //stiil op in the hour
                             {     
                                  indx = 0;
                                  while((min_start + (indx * min_steps)) <= min && ((indx * min_steps) <= MIN_IN_HOUR)) //look for first allowed min in the hour
                                  indx++;                                     
                                                               
                                  if((indx * min_steps) <= MIN_IN_HOUR)
                                 {
                                      next_minute = min_start + ((int)indx * min_steps); 
                                   //   NextOpTotalMin += ((int)next_hour *60 - now_in_minutes + next_minute); 
                                      NextOpTotalMin += ((int)next_hour *60 + next_minute);                                                                                                                  
                                      SendDebugMsg("pos3\r\n\0");                              
                                 }  
                                   
                             }
                         } 
                         else
                         {
                                   SendDebugMsg("op in next hour\r\n\0");  
                               //   NextOpTotalMin += ((int)next_hour *60 - now_in_minutes + min_start);
                                    NextOpTotalMin += ((int)next_hour *60 + min_start);          
                         }
                               
//                        sprintf(str1, "Next op in %d min.\r\n\0",NextOpTotalMin);  //debug
//                        UART1_WriteMsg(str1); 
                          if(op == REL1_ON)
                             sprintf(str1, "Next R1 ON at %02u:%02u\r\n\0",NextOpTotalMin/60,(NextOpTotalMin)%60);  //debug 
                          else if (op == REL1_OFF)
                             sprintf(str1, "Next R1 OFF at %02u:%02u\r\n\0",NextOpTotalMin/60,(NextOpTotalMin)%60);  //debug 
                          UART1_WriteMsg(str1); 
                          Skip_day = FALSE;                                                                            
                      } 
                      else
                      {
                           SendDebugMsg("next hour calc failure..\r\n\0");
                      }
                 
                 } 
                 else   //
                 {      
                       if( hour < hour_start) //need to wait for start_hour
                       {
                         //  NextOpTotalMin += (((int)hour_start *60 + min_start) - now_in_minutes);    //minutes to the op hour   
                          NextOpTotalMin += (((int)hour_start *60 + min_start));    //minutes to the op hour 
                           sprintf(str1, "Wait for hour_start - Next op in %d min.\r\n\0",NextOpTotalMin-now_in_minutes);  //debug
                           UART1_WriteMsg(str1);  
                            Skip_day = FALSE; 
                       } 
                                          
                 }                        
              }
              else SendDebugMsg("today_allowed = FALSE..\r\n\0");
        } 
        else  SendDebugMsg("day range problem..\r\n\0");
     }
     else 
     {
          sprintf(str1, "Week day failure..\r\n\0");  //debug
          UART1_WriteMsg(str1); 
     }
         
     if(Skip_day == TRUE) 
     {   
         NextOpTotalMin = 1440;
         sprintf(str1, "Next op not today..\r\n\0");  //debug
         UART1_WriteMsg(str1); 
     } 
     
     return  NextOpTotalMin;

}

////check wake status and handle it
  void Wakeup_Status_Check(void)
  {
       
        char  tmp, DOW;
        unsigned int stat;
  //      unsigned int SensorData;
     
        unsigned char today, tomonth, toyear;
        
        char str1[60];
        bit relay1_day_ok = 0;
        bit relay2_day_ok = 0;
        bit relay1_expected_ON;
        bit relay2_expected_ON;
          
         SendDebugMsg("\r\nWakeup - Check unit status...\r\n\0");


         relay1_day_ok = FALSE;
         relay2_day_ok = FALSE; 
         
        FlagsStatus =  eFLAGS_STSTUS;
        rtc_get_date( &today, &tomonth, &toyear, &DOW); //get date to be logged
        now_in_minutes = GetCurrentMinutsTime(); //load current minutes value for later compares

         tmp = (1 << DOW);         //set bit of day
       
         stat = Relay_vars[RELAY1].active_days; // get active  days from str1uct var
         if(tmp & stat)               //current day ok
         relay1_day_ok = TRUE;        //today is ok to pump    
         
         stat = Relay_vars[RELAY2].active_days; // get active  days from str1uct var
         if(tmp & stat)             //current day ok
         relay2_day_ok = TRUE;      //today is ok to pump      

      //------------------ relay 1 handling ---------------------------------

         stat = GetStatusReg(RELAY1_ON);  //relay 1 on? if yes, need close?
        if(stat)   //relay 1 is on - check if off time
        {
            if(now_in_minutes >= Relay_vars[RELAY1].next_OFF_time)  //
            {
               
                 OpenRelay1();          //relay off   
                 RelayEmergAct = FALSE;    
                 SetStatusReg(RELAY1_ON , 0);      
                 //TO DO: SET NEW OFF TIME
                 SendDebugMsg("Relay 1 ON to OFF.\r\n\0");
              
            }
            else
            {
                 sprintf(str1, "relay 1 is ON: will be OFF in %d Min.\r\n\0", Relay_vars[RELAY1].next_OFF_time - now_in_minutes);  //debug
                 UART1_WriteMsg(str1);
            }
        }
          
         //relay is off. need to be open?
        else  if(relay1_day_ok == TRUE)  //current day ok
        {
              
              if(now_in_minutes >= Relay_vars[RELAY1].next_ON_time) //time to ON valve 1?
              {
                  relay1_expected_ON = TRUE; 
                  //TO DO: SET NEW ON TIME
              }                                                                      
              else
              {
                      sprintf(str1, "Relay 1 is OFF: Expected ON at %02d:%02d. \r\n\0", Relay_vars[RELAY1].next_ON_time / 60, Relay_vars[RELAY1].next_ON_time % 60);
                      UART1_WriteMsg(str1);
              }
    
         }
        else   PCmessage("Relay 1: NOT allowed today .!\r\n\0");  
        
 //--------------------------------HANDLE RELAY 2---------------------------------------------------------  
 
 //-------------------------------------------------------------------------------------------------     
        if( relay1_expected_ON == TRUE)
        {
                OpenRelay1();
                relay1_expected_ON = FALSE;                 
                SetStatusReg(RELAY1_ON , RELAY1_ON);               
                
                Relay_vars[RELAY1].last_op_time = now_in_minutes;
                Relay_vars[RELAY1].last_op_day = today;                  //record day in eeprom
                Relay_vars[RELAY1].last_op_dow = DOW;             //record dow in eeprom
                                     
                sprintf(str1, "Relay 1 to ON- will be OFF in %d Min. \r\n\0",Relay_vars[0].next_OFF_time - now_in_minutes);  //debug
                UART1_WriteMsg(str1);  
        }  
        eFLAGS_STSTUS = FlagsStatus ;
 }


//
//eeprom unsigned int epLog_Read @0x120;
//eeprom unsigned int epLog_Read = 0x00;
//
//eeprom unsigned int epLog_Write @0x122;
//eeprom unsigned int epLog_Write = 0x00;
//
//unsigned int pLog_Read;                //pointer to read location in the circular buffer
//unsigned int pLog_Write;              //pointer to write location

// void WriteErrorLog(char errorType)
// {
//     char i;
//     char buf[6];
//
//      rtc_get_timeAll (readClockBuf);
//      pLog_Write = epLog_Write;        //write offset in log section
//
//      buf[0] = readClockBuf[1];     //month
//      buf[1] = readClockBuf[2];     //daqy
//      buf[2] = readClockBuf[4];     //hour
//      buf[3] = readClockBuf[5];     //min
//      buf[4] =  errorType;
//      buf[5] = '#';
//
//      for(i = 0 ; i< eLog_Msg_Len ; i++)
//      {
//         eLogSection[pLog_Write++] = buf[i];    //write to eeprom error log
//      }
//      if(pLog_Write >=  eLog_End)
//      pLog_Write =  0;
//      epLog_Write = pLog_Write;
//       SendDebugMsg("\r\nError Log updated...\r\n\0");
//
// }






////////////////end of general.c////////////////