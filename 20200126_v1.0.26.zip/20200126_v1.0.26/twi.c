/***************************************************************************
 Two Wire Interface driver January, 2012
 (c) 2012 Eric Williams

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
****************************************************************************/

//#include <avr/io.h>
//#include <avr/pgmspace.h>
#include <string.h>
#include <stdint.h>
#include "twi.h"
#include "define.h"
#include "sfr_defs.h"
#include "uart.h"

//#include "util.h"

#define W 0
#define R 1

/* TWI status codes */
#define SR_START        0x08    /* START condition has been transmitted */
#define SR_RSTART       0x10    /* Repeated START has been transmitted */
#define SR_SLA_WA       0x18    /* SLA+W has been transmitted, ACK received */
#define SR_SLA_W        0x20    /* SLA+W has been transmitted, no ACK */
#define SR_DTA_A        0x28    /* Data byte has been transmitted, ACK received */
#define SR_DTA          0x30    /* Data byte has been transmitted, no ACK */
#define SR_BUS          0x38    /* Arbitration lost */
#define SR_SLA_RA       0x40    /* SLA+R has been transmitted, ACK received */
#define SR_SLA_R        0x48    /* SLA+R has been transmitted, no ACK */
#define SR_DTR_A        0x50    /* Data byte received, ACK returned */
#define SR_DTR          0x58    /* Data byte received, no ACK */

extern void SetAlarmTiming(unsigned int NewVal);

extern char cuurent_interval;
bit TWIerrON = FALSE;

/*
** Wait for TWI hardware to finish
*/

#define twiWait() {loop_until_bit_is_set (TWCR, TWINT);}

/*
** Generate error message that shows expected and received status
*/
//char twi_fmt[] PROGMEM = "twi %02x:%02x\r\n\0";
//char twi_fmt[] = "twi %02x:%02x\r\n\0";

void twiError (uint8_t expected, char received)
{
   static char TWIflag = 0;

    expected = 0;
    received= 0;

    if( received == -1)
    {
           SendDebugMsg("Handle TWI Error..\r\n\0");
         TWIflag = 1;
         TWIerrON = TRUE;

   
          delay_ms(10);
    }
    else   if( received == 0)
    {
        TWIerrON = FALSE;
    }
    else   SendDebugMsg("TWI Error\r\n\0");

//#if DEBUG
//        char d[12];
//
//        sprintf_P (d, twi_fmt, expected, received);
//        uart_puts (d);
//#endif
}

/*
** Issue a START condition on the TWI bus
*/
static uint8_t twiStart (void)
{
        uint8_t stat;

        TWCR = _BV(TWINT) | _BV(TWEN) | _BV(TWSTA);
        twiWait();
        stat = TWSR & 0xf8;
        if ((stat == SR_START) || (stat == SR_RSTART))
                return 0;
        twiError (SR_START, stat);
        return 1;
}

/*
** Issue STOP condition on TWI bus
*/
static inline void twiStop (void)
{
        TWCR = _BV(TWINT) | _BV(TWEN) | _BV(TWSTO);
}

/*
** Write one byte of data
*/
static inline void twiWrite(const uint8_t data)
// void twiWrite(const uint8_t data)
{
        TWDR = data;
        #asm("cli")
        TWCR = _BV(TWINT) | _BV(TWEN);
      //  twiWait();
         while (!(TWCR & (1<<TWINT)));
         #asm("sei")
}

/*
** Read one byte of data
*/
static inline void twiRead(void)
{
        TWCR = _BV(TWINT) | _BV(TWEN) | _BV(TWEA);
        twiWait();
}

/*
** Read one byte without ACK
*/
static inline void twiReadNack(void)
{
        TWCR = _BV(TWINT) | _BV(TWEN);
        twiWait();
}

/*
** Write <data> into register <reg> of device at address <addr>
*/
int twiWriteReg(const uint8_t addr, const uint8_t reg, const uint8_t data)
{

   char flag = 0;
   // #asm("cli")
  // SendDebugMsg("twiWriteReg()..!\r\n\0");
    do{
        flag++;
        if (twiStart() == 0) {
                twiWrite((addr & 0xfe) | W);
                if (TWSR != SR_SLA_WA)
                {

                        twiError(SR_SLA_WA, -1);

                }
                else {
                        twiWrite(reg);
                        if (TWSR != SR_DTA_A)
                                twiError(SR_DTA_A, TWSR);
                        else {
                                twiWrite(data);
                                if (TWSR != SR_DTA_A)
                                        twiError(SR_DTA_A, TWSR);
                                else {
                                        twiStop();
                                      #asm("sei")
                                       if(TWIerrON == TRUE)
                                       {
                                            TWIerrON = FALSE;
                                            twiError(0, 0);
                                            #asm("jmp 0x0000")   //start program
                                       }
                                        return 1;
                                }
                        }
                }

       }
     }while(flag < 2);



         #asm("sei")
        TWCR = 0;               /* Disable TWI */
        return -1;
} 
char twiReadEEP1Byte(char block,  unsigned int InternalAddr )
{

    unsigned char EEPaddr = 0xA0;
    unsigned char   adressHigh, adressLow;

     if(block == 1)
      EEPaddr = (0xA2);   //    //upper section bit high check chip datasheet

     adressHigh = (unsigned char)((InternalAddr >> 8) & 0xFF);
     adressLow  = (unsigned char)(InternalAddr) ;


        if (twiStart() == 0)
        {
                twiWrite((EEPaddr & 0xfe) | W);   //A0
               // delay_us(10);
                if (TWSR != SR_SLA_WA)
                        twiError(SR_SLA_WA, 0x30);
                else
                {
                        twiWrite(adressHigh);      //high address
                       if (TWSR != SR_DTA_A)
                            twiError(SR_DTA_A, 0x31);
                       else
                       {
                            twiWrite(adressLow);   //low address  -wait for ack
                            if (TWSR != SR_DTA_A )
                            twiError(SR_DTA_A, 0x32);

                            else if (twiStart() == 0)    //new start bit
                            {
                                  twiWrite((EEPaddr & 0xfe) | R);    //read command
                                  if (TWSR != SR_SLA_RA)
                                  twiError(SR_SLA_RA, 0x33);
                                  else
                                  {
                                            twiReadNack();  /* Last byte */
                                            if (TWSR != SR_DTR)
                                            {
                                                    twiError(SR_DTR, 0x34);
                                                    TWCR = 0;               /* Disable TWI */
                                                    return 0;
                                            }


                                        twiStop();
                                        return TWDR;
                                  }
                            }
                       }

                }

        }

        TWCR = 0;               /* Disable TWI */
        return 0;
}

char ReadEEPCurrentAddress(char EEPaddr)
{

        if (twiStart() == 0)
        {
              twiWrite (EEPaddr | 1);    //read command
                if (TWSR != SR_SLA_RA)
                 twiError(SR_SLA_RA, 0x39);
              else
              {
                    twiReadNack();      //read one byte
                    if (TWSR != SR_DTR)
                    {
                            twiError(SR_DTR, 0x34);
                            twiStop();
                            TWCR = 0;               /* Disable TWI */
                            return 0;
                    }
                    twiStop();
                    return TWDR;
              }
        }
         return 0;
}

int twiWriteExtMemN(char block, unsigned int addr, unsigned char n, char *pdata)
{
       unsigned char AddH, AddL;
       char MemAddress = 0xA0;

      if(block == 1)
      MemAddress = 0xA2;    //upper section bit high  atmel chip

        AddH = (unsigned char)((addr >> 8) & 0xFF);     //address high
        AddL  = (unsigned char)(addr) ;

        if (twiStart() == 0) { 
              
                twiWrite((MemAddress) | W);
                if (TWSR != SR_SLA_WA)
                        twiError(SR_SLA_WA, 0x36);
                    
                else {
                        twiWrite(AddH);
                        if (TWSR != SR_DTA_A)
                               twiError(SR_DTA_A, 0x37);
                            
                        else {
                               twiWrite(AddL);
                               if (TWSR != SR_DTA_A)
                                twiError(SR_DTA_A, 0x38);
                              
                            else {
                                     #asm("cli")
                                    while (n > 0) {
                                       twiWrite(*(uint8_t *)pdata++);
                                     
                                            if (TWSR != SR_DTA_A) {
                                                    twiError(SR_DTA_A, 0x39);
                                                    TWCR = 0; 
                                                     #asm("sei")
                                                    return 0;
                                            }
                                            n--;
                                    }
                                    twiStop();
                                     #asm("sei")
                                    return 1;
                                 }
                      }
                }
        }
        TWCR = 0;     /* Disable TWI */
                  
        return 0;
}

/*
** Write N sequential bytes of data starting at register <reg>
*/
int twiWriteRegN(const uint8_t addr, const uint8_t reg, uint8_t n, uint8_t *pdata)
//int twiWriteRegN(const uint8_t addr, const uint8_t reg, uint8_t n, void *pdata)
{
        if (twiStart() == 0) {
                twiWrite((addr & 0xfe) | W);
                if (TWSR != SR_SLA_WA)
                        twiError(SR_SLA_WA, TWSR);
                else {
                        twiWrite(reg);
                        if (TWSR != SR_DTA_A)
                                twiError(SR_DTA_A, TWSR);
                        else {
                                while (n > 0) {
                                   twiWrite(*(uint8_t *)pdata++);

                                        if (TWSR != SR_DTA_A) {
                                                twiError(SR_DTA_A, TWSR);
                                                TWCR = 0;
                                                return -1;
                                        }
                                        n--;
                                }
                                twiStop();
                              //  return 0;
                                return 1;
                        }
                }
        }
        TWCR = 0;               /* Disable TWI */
        return -1;
}
//new for eeprom write. replace SendBuf() at eeprom.c
//*pdata include address of page
//int twiWriteEEP(const char addr, char n, char *pdata)
//
//{
//    //    #asm("cli")
//  
//   
//        if (twiStart() == 0)
//         {
//                twiWrite((addr & 0xfe) | W);
//                if (TWSR != SR_SLA_WA)
//                    twiError(SR_SLA_WA, 0);
//                else
//                {
//                        while (n > 0)
//                        {
//                           twiWrite(*(uint8_t *)pdata++);
//
//                               if (TWSR != SR_DTA_A)
//                               {
//                                        twiError(SR_DTA_A, TWSR);
//                                      //   #asm("sei")
//                                        TWCR = 0;
//                                        return -1;
//                                }
//                                n--;
//                          }
//                          twiStop();
//                        //   #asm("sei")
//                         
//                            return 1;
//                }
//            }
//    
//     
//        TWCR = 0;               /* Disable TWI */
//        return -1;
//}

/*
** Read register <reg> from device at address <addr>
*/
int twiReadReg(const uint8_t addr, const uint8_t reg)
 {
        uint8_t dr;
      char flag = 0;

   //   #asm("cli")
   do
   {
         flag++;
        if (twiStart() == 0) {
                twiWrite((addr & 0xfe) | W);
                if (TWSR != SR_SLA_WA)
                {
                        twiError(SR_SLA_WA, -1);

                }
                else {
                        twiWrite(reg);
                        if (TWSR != SR_DTA_A)
                                twiError(SR_DTA_A, TWSR);
                        else if (twiStart() == 0) {
                                twiWrite((addr & 0xfe) | R);
                                if (TWSR != SR_SLA_RA)
                                        twiError(SR_SLA_RA, TWSR);
                                else {
                                        twiReadNack();
                                        if (TWSR != SR_DTR)
                                                twiError(SR_DTR, TWSR);
                                        else {
                                                dr = TWDR;
                                                 #asm("sei")
                                                twiStop();
                                               if(TWIerrON == TRUE)
                                               {
                                                    TWIerrON = FALSE;
                                                    twiError(0, 0);
                                                    #asm("jmp 0x0000")   //start program
                                               }

                                                return (dr);
                                        }
                                }
                        }
                }

        }

   }while(flag < 2);

         #asm("sei")
        TWCR = 0;               /* Disable TWI */
        return -1;
 }
 //return read char

/*
** Read N sequential bytes of data starting at register <reg>
**
** Note pdata must point to a buffer of sufficient size.
*/
//int twiReadRegN(const uint8_t addr, const uint8_t reg, uint8_t n, uint8_t *pdata)
//{
//        if (twiStart() == 0) {
//                twiWrite((addr & 0xfe) | W);
//                if (TWSR != SR_SLA_WA)
//                        twiError(SR_SLA_WA, 0);
//                else {
//                        twiWrite(reg);
//                        if (TWSR != SR_DTA_A)
//                                twiError(SR_DTA_A, TWSR);
//                        else if (twiStart() == 0) {
//                                twiWrite((addr & 0xfe) | R);
//                                if (TWSR != SR_SLA_RA)
//                                        twiError(SR_SLA_RA, TWSR);
//                                else {
//                                        while (n > 0) {
//                                                if (n == 1) {
//                                                        twiReadNack();  /* Last byte */
//                                                        if (TWSR != SR_DTR) {
//                                                                twiError(SR_DTR, TWSR);
//                                                                TWCR = 0;               /* Disable TWI */
//                                                                return -1;
//                                                        }
//                                                } else {
//                                                        twiRead();
//                                                        if (TWSR != SR_DTR_A) {
//                                                                twiError(SR_DTR_A, TWSR);
//                                                                TWCR = 0;               /* Disable TWI */
//                                                                return -1;
//                                                        }
//                                                }
//                                             *(uint8_t *)pdata++ = TWDR;
//                                                n--;
//                                        }
//                                        twiStop();
//                                     //   return 0;
//                                        return 1;
//                                }
//                        }
//                }
//        }
//        TWCR = 0;               /* Disable TWI */
//        return -1;
//}
//read n chars from external eeprom

int twiReadExtMemN(char block,const unsigned int InternalAddr, char n, char *pdata)
{

    unsigned char EEPaddr = 0xA0;
    unsigned char   adressHigh, adressLow;  
        
    if(block == 1)
    EEPaddr = 0xA2;    //upper section bit high  atmel chip


    adressHigh = (unsigned char)((InternalAddr >> 8) & 0xFF);
    adressLow  = (unsigned char)(InternalAddr) ;

  //  delay_ms(50);
    
        if (twiStart() == 0)
        {      
                 twiWrite((EEPaddr & 0xfe) | W);   //A0

                if (TWSR != SR_SLA_WA)
                        twiError(SR_SLA_WA, 0);
                else
                {
                        twiWrite(adressHigh);      //high address
                       if (TWSR != SR_DTA_A)
                            twiError(SR_DTA_A, TWSR);
                       else
                       {
                            twiWrite(adressLow);   //low address  -wait for ack
                            if (TWSR != SR_DTA_A )
                            twiError(SR_DTA_A, TWSR);

                            else if (twiStart() == 0)    //new start bit
                            {
                                  twiWrite((EEPaddr & 0xfe) | R);    //read command
                                  if (TWSR != SR_SLA_RA)
                                  twiError(SR_SLA_RA, TWSR);
                             else
                                {
                                        while (n > 0)
                                        {    
                                             //   #asm("cli")
                                                if (n == 1)
                                                {
                                                        twiReadNack();  /* Last byte */
                                                        if (TWSR != SR_DTR)
                                                        {
                                                                #asm("sei")
                                                                twiError(SR_DTR, TWSR);
                                                                TWCR = 0;               /* Disable TWI */
                                                                return 0;
                                                        }
                                                }
                                                 else
                                                 {

                                                        twiRead();
                                                        if (TWSR != SR_DTR_A)
                                                        {
                                                                twiError(SR_DTR_A, TWSR);
                                                                 #asm("sei")
                                                                TWCR = 0;               /* Disable TWI */
                                                                return 0;
                                                        }
                                                 }
                                               *(uint8_t *)pdata++ = TWDR;
                                                n--;
                                        }

                                        twiStop();
                                        #asm("sei")
                                        return 1;
                                }
                            }
                     }    
               }
        }
      
        TWCR = 0;               /* Disable TWI */
        return 0;
}

//void twiInit (void)
//{
//        /* SCL freq = CPU clock/(16+2*TWBR*4^TWPS) */
//    // TWI initialization
//// Bit Rate: 20.035 kHz
//   TWBR=0x54;
//// Two Wire Bus Slave Address: 0x0
//// General Call Recognition: Off
//    TWAR=0x00;
//// Generate Acknowledge Pulse: Off
//// TWI Interrupt: Off
//    TWCR=0x04;
//    TWSR=0x00;
//}


//fropm test program
//void twiInit (void)
//{
//        /* SCL freq = CPU clock/(16+2*TWBR*4^TWPS) */
//      // TWI initialization
//// Bit Rate: 10.017 kHz
//TWBR=0xB0;
//// Two Wire Bus Slave Address: 0x0A
//// General Call Recognition: Off
//TWAR=0x14;
//// Generate Acknowledge Pulse: Off
//// TWI Interrupt: Off
//TWCR=0x04;
//TWSR=0x00;
//}

void twiInit (void)
{
        /* SCL freq = CPU clock/(16+2*TWBR*4^TWPS) */
      // TWI initialization
// Bit Rate: 10.017 kHz
TWBR=0x0A;
// Two Wire Bus Slave Address: 0x0A
// General Call Recognition: Off
TWAR=0x00;
// Generate Acknowledge Pulse: Off
// TWI Interrupt: Off
TWCR=0x44;   //04
//TWCR =0x00;
//TWSR=0x00;
}