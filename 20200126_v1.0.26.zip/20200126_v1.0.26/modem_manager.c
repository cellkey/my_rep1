#ifndef MODEM_MANAGER_C
#define MODEM_MANAGER_C
#include <string.h>
#include "define.h"
#include "uart.h"
#include <mem.h>
#include "rtc.h"
//#include "vars.h"


#define SUB_TASK_MODEM_SEND_GET 100


char Pharse_Server_Response(char *str, unsigned int index);

extern void SendPostLength(int len);
extern void SetTimer1_100ms(void);
 
extern void CloseRelay2 (void);
extern void OpenRelay2 (void);
extern void CloseRelay1 (void);
extern void OpenRelay1 (void);
extern unsigned char ChkNodemRespons(char flash *str1,char flash *str2, unsigned char timeout);
extern  char SendSMS2Server(void);

//char Pharse_params_struct(char *str, unsigned int index);
char CheckMessage(char source);
char RTC_Update_by_Server( char *str, int ptr);
void ModemForgetOldCop(void);
void SendStartDial();
void SendSModemString( char *bufToSend, BYTE bufLen);

//char Pharse_SDIparams_struct(char *str, char index);
unsigned char ICCID[] = "********************";
char COPS_value[15];

char cEndMark = '\0';
char ComFailureCounter = 0;

char ModemAgainCount;
int pStr2Bin (char *str, char p);
int ServerResponseTimeOut;   //count down when get connected with server

bit  ServerComOn;
bit ConnectedToServer = FALSE;
bit Found200 ;
bit ClockUpdated = FALSE;
bit ModemRepeatNeeded = FALSE;         //for new trial of communication
bit ModemIsOn = FALSE;
bit ModemAgain = FALSE;
bit MODEM_GOT_IP = FALSE;
extern bit ListUpdateNeeded ;
bit  ModemAlive = FALSE;
bit Open_Session_On = FALSE;


BYTE nMaxFailuresNum;
//BYTE prmUpdtIndex;

BYTE failCnt;
BYTE initCnt;
BYTE bPostAnswered;
//BYTE bMakeReset;
BYTE bUseRoaming;
BYTE nFailureCntr;
char Timer0_Ticks;
char ModemRepeatCount ;
char TimeZone;


//extern flash unsigned char RomVersion[2];
extern bit Modem_Message_Recieved;
extern bit bExtReset;
extern bit bWaitForModemAnswer;
extern bit bNeedToWait4Answer;
extern bit PumpActivated;
extern bit IsAlertNeeded;
extern bit IsAlertActivated;
extern bit longAnswerExpected;
extern bit overFlow;
extern bit RING_PULSE_ACTIVE;
extern bit DIGITAL_IN_ACTIVE;
extern bit SearchServerDataBase;
extern bit SearchDial;
extern bit KeepAliveMsgNeeded;
extern bit ReDialNeeded;
extern bit  ATO_needed;
extern bit ServerSMSneeded ;


extern BYTE modemCurTask;
extern BYTE modemCurSubTask;
//extern BYTE waitingTask;
extern BYTE dataSentOK;
extern BYTE toDoList;
extern BYTE BytesToSend;
extern BYTE ModemResponse;
extern BYTE msrAlertFlag;
extern BYTE AlertStatus[MAX_SEN_NUM];
extern unsigned int timeCnt;
extern bit bReset;
extern int TimeLeftForWaiting;
extern unsigned int rx0_buff_len;
extern BYTE rssi_val;
extern BYTE bConnectOK;
extern char e2_writeFlag;
extern char readClockBuf[];	         //buffer for data reading from clock

//extern char clockBuf[7]; 		 //buffer for all clock operation need
extern char ComBuf[MAX_TX_BUF_LEN];
extern char RxUart0Buf[MAX_RX_BUF_LEN];
extern char CallerIdBuf[];
extern char RingCounter;
extern unsigned int Keep_Alive_timer;

extern char ErrorType;
extern char AT_D1[];     //dtr hangup call
extern char ATO[];
extern char UNIT_NAME[11];


//extern int DataAtAlertStatus;

extern unsigned int timeCnt;
//extern unsigned int nextCompare;
extern unsigned int nMaxWaitingTime;
extern int iVoltage;
extern int heat_time;

extern int iLastMsr[MAX_SEN_NUM];
extern  char Timer0_Ticks;
extern char gBUF[];
extern BYTE iFirstConnToday;
extern char ActiveRelay;
extern char Relay_period;
//extern unsigned char nUnreadBlocks;


extern char FlagsStatus;

//extern unsigned char GetStatusReg(unsigned char mask);
extern void SetStatusReg(unsigned char mask, unsigned char val);
extern void UART0_WriteMsg( char *InStr);
extern char ReadReceivedSMS(void);
extern  void SendMsgBySMS(unsigned char code);
extern  void DelSMS(void);
extern unsigned int RxUpdateFile(void);
extern  char CheckSMSMsg(char source) ;

extern flash unsigned char fw_version[];
extern eeprom char unique_id[]; //sensors id
extern eeprom unsigned char eStartConnectionH;        //first connection hour
extern eeprom unsigned char eConnectionInDay;        //number on connectionsin a day
extern eeprom unsigned char eConnectIntervalH;        //intervalbetween connections (hours)
//extern eeprom char eGMT;        //GMT offset param
extern eeprom char cpue2_interval_1;
extern eeprom int MIN_LIMIT[MAX_SEN_NUM];
extern eeprom  char eUnit_Name[17];

#pragma keep+
eeprom BYTE SensorType[MAX_SEN_NUM ] @0x00;
eeprom BYTE SensorType[MAX_SEN_NUM ]= {0, 0, 0, 0, 0, 0, 0, 0};

eeprom char eUnit_Type @0x08;
eeprom char eUnit_Type = 1;    //default value - regular unit 

eeprom unsigned int elogger_id @0x09; //
eeprom unsigned int elogger_id = 1 ;

eeprom unsigned char NumSensors @0x0B;
eeprom unsigned char NumSensors = 0;     

eeprom unsigned int BatLevelTrshold @0x0D;     //to be checked by CPU
eeprom unsigned int BatLevelTrshold = 3400;     

eeprom signed char ADCMux[MAX_SEN_NUM ] @0x10;
eeprom signed char ADCMux[MAX_SEN_NUM ] = { -1, -1, -1, -1, -1, -1, -1, -1};

eeprom char unique_id[ MAX_SEN_NUM ] @0x20 ;
eeprom char unique_id[ MAX_SEN_NUM ] = {1,2,3,4, 5,6,7,8}; //sensors id

eeprom char cpue2_interval_1 @0x28;
eeprom char cpue2_interval_1 = 1;
eeprom unsigned char eStartConnectionH  @0x29;
eeprom unsigned char eConnectionInDay   @0x2A;
eeprom unsigned char eConnectIntervalH  @0x2B;
eeprom unsigned char eStartConnectionH = 6;        //first connection hour
eeprom unsigned char eConnectionInDay  = 3;        //number on connectionsin a day
eeprom unsigned char eConnectIntervalH = 8;        //intervalbetween connections (hours)

eeprom  char ePORTval1[4]   @0x2C;
eeprom  char ePORTval1[4]    = {'0','0','8','0'};

eeprom  char eIPorURLval1[32] @0x30;
eeprom char eIPorURLval1[32] = {'g','a','t','e','s','.','c','r','e','a','-','c','e','l','l','.','c','o','m','#','0','0','0','0','0','0','0','0','0','0','0','0'}; //32 byte

eeprom  char eAPN[32]  @0x50;
eeprom  char eAPN[32]         = {'i','n','t','e','r','n','e','t','#','0','0','0','0','0','0','0','0','0','0',\
                                        '0','0','0','0','0','0','0','0','0','0','0','0'};     //"internetm2m.air.com#000000000000";                                          
eeprom int MIN_LIMIT[MAX_SEN_NUM] @0x70;
eeprom int MIN_LIMIT[MAX_SEN_NUM] = {MIN_INT, MIN_INT, MIN_INT, MIN_INT, MIN_INT, MIN_INT, MIN_INT, MIN_INT};

eeprom int MAX_LIMIT[MAX_SEN_NUM] @0x80;
eeprom int MAX_LIMIT[MAX_SEN_NUM] = {MAX_INT, MAX_INT,MAX_INT,MAX_INT, MAX_INT, MAX_INT, MAX_INT, MAX_INT};            

eeprom  unsigned char eReserved[16]  @0x90;     //260117 for special EC treshold vlaue for PH pump activation limit
eeprom  unsigned char eReserved[16];                                        
                                                    
eeprom  unsigned char Option_1[16]    @0xA0;
eeprom  unsigned char Option_1[16]     = {'#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#'};   //,'0','0','0','0',\ 

eeprom  char Option_2[32]    @0xB0;
eeprom char Option_2[32]      = {'#','p','t','i','o','n','_','2','#','0','0','0','0','0','0','0','0','0','0',
                                         '0','0','0','0','0','0','0','0','0','0','0','0','0'}; //32 bytes   

eeprom  char eCreacellPassWord[6]  @0xD0;
eeprom  char eCreacellPassWord[6]  = {'1','2','3','4','5','6'};               //6 bytes user PW for SMS 
                                        
eeprom char  eICCID[5]  @0xD6 ;
eeprom char  eICCID[5]= {'0','0','0','0','0'} ;

eeprom char eFLAGS_STSTUS @0xDB;
eeprom char eFLAGS_STSTUS =  0;

eeprom char eTimeZone  @0x0DC;
eeprom char eTimeZone = 12;   //Summer
eeprom unsigned int eCurrentYear @0xDD;
eeprom unsigned int eCurrentYear = 2019;

eeprom unsigned int eCurrentDayOfWeek;
eeprom unsigned int eCurrentDayOfWeek = 0;


eeprom char eUsersNumArray[160]  @0xE0;
eeprom char eUsersNumArray[160] =    { '0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0',//,
                                      '0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0',
                                      '0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0',
                                      '0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0',
                                      '0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0',
                                      '0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0',
                                      '0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0',
                                      '0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0',
                                      '0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0',
                                      '0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0'};
                                             

//eeprom  char AdminNum[16] @0xE0;
//eeprom char AdminNum[16] = {'0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0'};
//eeprom  char UserNum1[16] @0xF0;
//eeprom  char UserNum1[16] = {'0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0'};
//eeprom  char UserNum2[16] @0x0100;
//eeprom  char UserNum2[16] = {'0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0'};
//eeprom  char UserNum3[16] @0x0110;
//eeprom  char UserNum3[16] = {'0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0'};
//eeprom  char UserNum4[16] @0x0120;
//eeprom char UserNum4[16] = {'0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0'};
//eeprom  char UserNum5[16] @0x0130;
//eeprom  char UserNum5[16] = {'0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0'};
//eeprom  char UserNum6[16] @0x0140;
//eeprom  char UserNum6[16] = {'0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0'};
//eeprom  char UserNum7[16] @0x0150;
//eeprom  char UserNum7[16] = {'0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0'};
//eeprom  char UserNum8[16] @0x0160;
//eeprom  char UserNum8[16] = {'0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0'};
//eeprom  char UserNum9[16] @0x0170;
//eeprom  char UserNum9[16] = {'0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0'};



 #pragma keep-                                        



//https://kando-staging.herokuapp.com:443/autosamplings/device_broadcast

//flash char END_MARK = '\n';
flash  unsigned char  AT_IsModemOK[] = "AT\r\n\0";             //5 bytes
flash  unsigned char  AT_IsModemReg[] = "AT+CREG?\r\n\0";     //10 bytes
 flash  unsigned char AT_IsModemRegGPRS[] = "AT+CGREG?\r\n\0";
flash  unsigned char  AT_COPS_AUTO[] = "AT+COPS=0\r\n\0";      //11 bytes
//flash  char  AT_COPS_MAN[] = "AT+COPS=4,2,@";       //12 bytes. must have # at the end

flash  unsigned char  AT_COPS_ASK[] = "AT+COPS?\r\n\0";
//flash unsigned char  AT_CELL_MONITOR[] = "AT#MONI\r\n\0";
flash unsigned char  AT_CSQ[] = "AT+CSQ\r\n\0";               //8 bytes
flash unsigned char AT_CCLK[] = "AT+CCLK?\r\n\0";
flash unsigned char AT_CRSM[]= "AT+CRSM=214,28542,0,4,3,\"FFFFFF\"\r\n\0";   //reset sim card memory
 //flash unsigned char  DE_ACTIVATE_ATCH[] =  "AT+CGATT=0\r\n\0";

//battery voltage check
//flash unsigned char  AT_GPIO_ON[] =  "AT#GPIO=3,1,1\r\n\0 ";   // Switch ADC ON
//flash unsigned char  AT_ADC[] =      "AT#ADC=1,2\r\n\0 ";      // Value milivolt [Vm]  => Voltage input to sensor = Vm*4.7
//flash unsigned char  AT_GPIO_OFF[] = "AT#GPIO=3,0,1\r\n\0 ";   // Switch ADC OFF
//flash unsigned char AT_CRSM[] = "AT+CRSM=176,12258,0,0,10\r\n\0";
//flash unsigned char AT_CTZU[] = "AT+CTZU=1\r\n\0";
//flash unsigned char AT_NITZ[] = "AT#NITZ=1\r\n\0";

//GPRS connecting commands:
//flash unsigned char READ_PDP_CNTXT[] = "AT+CGDCONT?\r\0\n";                         //13

#ifdef SIM800
 
    flash unsigned char AT_E0[] = "ATE0;&W\r\n\0"; 
   flash unsigned char DEF_QULT_MIN_PROF[] = "AT+CIICR\r\n\0";                     //24
    flash unsigned char ACTIVATE_CNTXT[] = "AT+CIFSR\r\n\0";    //get IP
    flash char AT_TCP_OPN[] = "AT+CIPSTART=\"TCP\",@";
    flash unsigned char MODEM_SHDN[] = "AT+CIPSHUT\r\n\0";
    flash unsigned char AT_TCP_CLS[] = "AT+CIPCLOSE=1\r\n\0";  //sim800
    flash unsigned char AT_CIPMODE[] = "AT+CIPMODE=1\r\n\0";
    flash unsigned char AT_CCID[] = "AT+CCID\r\n\0";
    flash  char DEF_PDP_CNTXT[] = "AT+CSTT=@";    //39
    flash unsigned char GPRS_ATTACH[] = "AT+CGATT=1\r\n\0";  
    flash unsigned char CIICR[] = "AT+CIICR\r\n\0";
    flash unsigned char MODEM_SHUTOFF[] = "AT+CPOWD=0\r\n\0";                   
#else //Telit


 
//   flash unsigned char GPRS_ATTACH[] = "AT+CGATT=1\r\n\0";

 //  flash  char DEF_PDP_CNTXT[] = "AT+CGDCONT=1,\"IP\",@";    //39
//   flash unsigned char DEF_QULT_MIN_PROF[] = "AT+CGQMIN=1,0,0,0,0,0\r\n\0";                     //24
//   flash unsigned char DEF_QULT_REQ_PROF[] = "AT+CGQREQ=1,0,0,0,0,0\r\n\0";                     //24
//   flash unsigned char DEF_SCKT_CNFG[] = "AT#SCFG=1,1,500,30,150,4\r\n\0"; 
                //24
 //  flash unsigned char ACTIVATE_CNTXT[] = "AT#SGACT=1,1\r\n\0";
//   flash  char  AT_IsIPactive[] = "AT#SGACT?\r\n\0";
//   flash unsigned char DE_ACTIVATE_CNTXT[] = "AT#SGACT=1,0\r\n\0";                             //14
//   flash char AT_TCP_OPN[] = "AT#SD=1,0,@";           //"AT#SD=1,0,1020,\"phytech1.dyndns.org\"\r\n\0 ";   //40
//   flash unsigned char AT_TCP_CLS[] = "AT#SH=1\r\n\0";  //telit                             //9
//   flash unsigned char MODEM_SHDN[] = "AT#SHDN\r\n\0";
//   flash unsigned char MODEM_SYSHALT[] = "AT#SYSHALT\r\n\0";
//   flash unsigned char AT_CCID[] = "AT#CCID\r\n\0";  
 
 
#endif

//flash unsigned char AT_POST_TITLE_ALERT[] = "POST /m2m/update/sensorAlert HTTP/1.1\r\n\0";  //                 api/file/sensorparams

#ifdef KANDO_SERVER
//====================================== kando =====================================
flash unsigned char AT_POST_ALERT[] = "POST /autosamplings/device_notification?unit_id=\0";
//flash unsigned char AT_POST_ALERT_API[] = "POST /api/autosamplings/device_notification?unit_id=\0";
flash unsigned char AT_POST_TITLE_DATA_LOGGER1[] = "POST /autosamplings/device_broadcast?unit_id=\0";   //kando
//flash unsigned char AT_POST_TITLE_DATA_LOGGER1_API[] = "POST /api/autosamplings/device_broadcast?unit_id=\0";   //kando
flash unsigned char  POST_UPDATE_FIRMWARE[] = "POST /autosamplings/flash?unit_id=\0";     //update file
//flash unsigned char  POST_UPDATE_FIRMWARE_API[] = "POST /api/autosamplings/flash?unit_id=\0";     //update file
//flash unsigned char  POST_AUTH_SSL[] = "POST /oauth/token?grant_type=client_credentials&unit_id=\0";   //ssl code
flash char HTTP1[] =" HTTP/1.1\r\n\0";
//===================================================================================
#else //creacell
flash unsigned char AT_POST_TITLE_DATA_LOGGER1[] = "POST /m2m/update/sensordata HTTP/1.1\r\n\0"; // 38 //add data string and / HTTP/1.1\r\n\0
flash unsigned char AT_POST_ALERT[] = "POST /m2m/update/general HTTP/1.1\r\n\0";
flash unsigned char AT_POST_LIST_UPDATE[] = "POST /m2m/list_update/general HTTP/1.1\r\n\0";   //EazyGate list update rquest
flash unsigned char AT_POST_LIST_SEARCH[] = "POST /api/device/check_user HTTP/1.1\r\n\0"; 
flash unsigned char AT_POST_GET[] = "GET /api/test-keepalive HTTP/1.1\r\n\0";    //tst new connction 
flash unsigned char AT_POST_GET_1[] = "GET /api/device/";
flash unsigned char AT_POST_GET_2[] = "/listen HTTP/1.1\r\n\0";
flash unsigned char AT_POST_GET_MANUAL[] = "GET /api/test-keepalive-manual HTTP/1.1\r\n\0";    //tst new connction 
flash unsigned char AT_POST_CHUNKED[] = "Transfer-Encoding: chunked\r\n\0";
flash unsigned char KEEP_ALIVE[] = "1\r\nA\r\n\0"; 
flash char FW_VER[] = "FW_VERSION: \0";
flash char COPS_ID[] = "COPS_ID: \0";
flash char UNIT_TYPE_[] = "UNIT_TYPE: \0";
#endif                              
//=========================================================================================

flash unsigned char AT_POST_CONN[] = "Connection: keep-alive\r\n\0";       //24
flash unsigned char AT_POST_TYPE[] = "Content-Type: application/octet-stream\r\n\0";   //40
flash  char AT_POST_HOST[] = "Host: @#";        

//flash unsigned char AT_POST_LENGTH1[] = "Content-Length: 226\r\n\0\r\n\0";                     //23
flash  char AT_POST_LENGTH4[] = "Content-Length: @#";                     //23
flash  unsigned char AT_POST_LENGTH3[] = "Content-Length: 130\r\n\0\r\n\0";                     //23
flash unsigned char AT_POST_FILE_HDR1[] = "Content-Disposition: form-data; name=\"file\"; \0";             //45
//flash unsigned char AT_POST_FILE_HDR_PRM[] = "filename=\"PARAMS.txt\"\r\n\0#";    //23
//flash unsigned char AT_POST_FILE_HDR_DATA[] = "filename=\"DATA.txt\"\r\n\0#";    //21
flash unsigned char AT_POST_FILE_HDR_GETDATA[] = "filename=\"GETPARAMPOST.txt\"\r\n\0#";    //29
flash unsigned char AT_POST_FILE_HDR2[] = "Content-Type: text/plain\r\n\0\r\n\0";          //28
flash unsigned char AT_POST_ACCEPT[] = "Accept: */*\r\n\0"; //13
flash unsigned char AT_POST_USER_AGENT[] = "User-Agent: Creacell/1.0\r\n\0"; //28
//flash unsigned char AT_POST_USER_AGENT[] = "User-Agent: Creacell-Kando/1.0\r\n\0"; //28
flash unsigned char UNITID[] = "Unit: \0";
flash unsigned char TIME_ZONE[] = "TIME_ZONE: \0";
flash unsigned char SIM_ID[] = "SIM_ID: \0";

//send flash init string to modem
void SendATCmd(flash unsigned char *bufToSend)
{
    BYTE i;

    i = 0;
    //copy flash string to buff
    do
    {
         ComBuf[i] = bufToSend[i];
         i++;
    }
    while (bufToSend[i] != cEndMark);
    BytesToSend = i ;
    //transmitt to local modem port
    TransmitBuf(0);


}


// translate rssi val from string to single byte
char ConvertRssiVal(void)
{
        BYTE i, b = 0;

        rssi_val = 100;
        for( i = 0; i < rx0_buff_len - 4 ; i++)
        {
            //if return "+CSQ:"
            if((RxUart0Buf[i] == 0x2B) &&
               (RxUart0Buf[(int)i+1] == 0x43) &&
               (RxUart0Buf[(int)i+2] == 0x53) &&
               (RxUart0Buf[(int)i+3] == 0x51) &&
               (RxUart0Buf[(int)i+4] == 0x3A))
            {
                b = 1;
                //serch for ',':
                // if rssi val is only 1 digit - take it as is
                   if(RxUart0Buf[(int)i+7] == 0x2C)
                    //rssi val is 1 byte
                    rssi_val = RxUart0Buf[(int)i+6]-0x30;
                   // rssi_val = 0x30 + ComBuf[i+6];
                else
                    // if its 2 digits:
                     if(RxUart0Buf[(int)i+8] == 0x2C)
                    {
                        rssi_val = RxUart0Buf[(int)i+6]-0x30;
                        rssi_val *= 10;
                        rssi_val += RxUart0Buf[(int)i+7]-0x30;
                    }
                break;
            }
        }
        // no answer found (+CSQ:)
        if (b == 0)
            return FALSE; 

        return TRUE;
 
}



void ModemIgnit(void)
{
  
        PORTC.2 = 1;   //ignition pulse 
        delay_ms(3000); 
        #asm("wdr"); 
        delay_ms(3000); 
          #asm("wdr"); 
        PORTC.2 = 0;
    //    delay_ms(1000); 
         initCnt++;  
                  
}

char ModemInit(void)
{
       char CNMI[]="AT+CNMI=2,2,0,0,0\r\n\0";  
       char CMGF[]="AT+CMGF=1\r\n\0"; 
        char CLIP[]="AT+CLIP=1\r\n\0"; 
   //    char CMGD[]="AT+CMGD=1,4\r\n\0";   
       char FUNC1[] = "AT+CFUN=1\r\n\0";  
  //    char CIPTKA[] = "AT+CIPTKA=1,60,60,9\r\n\0";
      char ATD1[] = "AT&D1\r\n\0";   
    //   char CIPTKA[] = "AT+CIPTKA?\r\n\0";  
    
       UART0_WriteMsg(ATD1); 
      delay_ms(300);   
      UART0_WriteMsg(FUNC1); 
      delay_ms(300);  
      UART0_WriteMsg(CMGF); 
      delay_ms(300);  
      UART0_WriteMsg(CLIP); 
      delay_ms(300);
                  
      UART0_WriteMsg(CNMI); 
      delay_ms(300); 
      
//      UART0_WriteMsg(CIPTKA); 
//      delay_ms(300); 
      
//      UART0_WriteMsg(CMGD); 
//      delay_ms(300);   
     
   //     MODEM_GOT_IP = TRUE ;  //test it here
  return 1;    
       
}

void  Modem_Close_Connection(void)
{
        char plusplus[] = "+++"; 
        
      SendSModemString(plusplus, 3);
      delay_ms(1500);            //????
      SendATCmd(AT_TCP_CLS);
       
   //  SendATCmd(MODEM_SHUTOFF); 
      MODEM_GOT_IP = FALSE;
       

} 

char Modem_Server_Reconnect(void)
{

     char ok;  
     char ATO_[] = "ATO\r\n\0"; 
     
    //  SendDebugMsg("Re connect to server..\r\n\0"); 
               
       ENABLE_RX_INT_UART0();              
       UART0_WriteMsg (ATO_);                          
      ok =  ChkNodemRespons("CONN","-",20);
      if(ok)
      {               
              
             return 1;
           //  SendDebugMsg("to MODEM..\r\n\0"); 
      }
      else
      {      
             UART0_WriteMsg (ATO_); 
              ok =  ChkNodemRespons("CONN","-",20);
             if(ok)
             {                       
                  
                    return 1;
              } 
             else
             { 
                  SendDebugMsg("NOT re connected..\r\n\0");  
                  return 0;
                    
              }  
      }                               
     
}  


void SetModemPwrOn() //  addapted to octopus  -not needed
{

     delay_ms(200);  
     initCnt++;                //was marked!!. Danny removed mark 130515
     ModemResponse = TASK_COMPLETE;
//    bModemIsON = TRUE;

}


//  addapted to octopus  -not needed
//HE910 201216
void SetModemPwrOff()
{
 
    delay_ms(200);
    ModemResponse = TASK_COMPLETE;

}


//sync led on-blinking
void Sync_Led_On(void)
{
  char SLED4[] = "AT#SLED=4\r\n\0";    
  UART0_WriteMsg(SLED4);  
  delay_ms(500);
} 

void Sync_Led_Off(void)
{
  char SLED4[] = "AT#SLED=0\r\n\0";    
  UART0_WriteMsg(SLED4); 
  delay_ms(300); 
} 

void Modem_Text_Mode(void)
{
  char CMGF[] = "AT+CMGF=1\r\n\0";    
  UART0_WriteMsg(CMGF); 
  delay_ms(500); 
} 
void Modem_Host_CNMI(void)
{
  char CNMI[] = "AT+CNMI=3,1,2,0,0\r\n\0";    
  UART0_WriteMsg(CNMI); 
  delay_ms(500); 
} 
void Modem_Ring_Active(void)
{
  char RING_ON[] = "AT#E2SMSRI=500\r\n\0";  //500 mili Sec low  
  UART0_WriteMsg(RING_ON); 
  delay_ms(500); 
} 
void Modem_Sleep_EN(void)
{
  char  FUN5[] = "AT+CFUN=5\r\n\0";    
  UART0_WriteMsg(FUN5); 
  delay_ms(300); 
} 

void Get_Provider(char *str)
{
     char COPS[] = "AT+COPS?\r\n\0";   //+COPS: 0,0,"Partner",0
     char i,j, STR[15]; 
     
     i=j=0;  
     Modem_Message_Recieved = FALSE; 
     bWaitForModemAnswer = TRUE; 
     rx0_buff_len = 0; 
     
      UART0_WriteMsg(COPS);
      delay_ms(600); 
    
  if(Modem_Message_Recieved == TRUE)
  {  
         while(( RxUart0Buf[i] != '"') && (i < 16))
         i++;
         if(i < 16)
         {
             i++ ;
             while( RxUart0Buf[i] != '"') 
             str[j++] = RxUart0Buf[i++];   //get provider name   
              str[j] = '\0';
         } 
         sprintf(STR, "Provider: %s\r\n\0",str);  
         UART1_WriteMsg(STR); 
  } 
  else  SendDebugMsg("Get COPS failed.\r\n\0");         
}

void Get_CSQ(char *str)            //+CSQ: 28,0
{
      char CSQ[] = "AT+CSQ\r\n\0";     
     
       char STR[15]; 
       char k,j; 
              
       k=0; 
       j=0;
     Modem_Message_Recieved = FALSE; 
     bWaitForModemAnswer = TRUE; 
     rx0_buff_len = 0;
      UART0_WriteMsg(CSQ);
      delay_ms(600);  
      
   if(Modem_Message_Recieved == TRUE)
  {        
     while(( RxUart0Buf[k] != ' ') && (k < 8))
     k++;
     if(k < 8)
     {
         k++ ;
         while( RxUart0Buf[k] != ',') 
         str[j++] = RxUart0Buf[k++];   //get provider name   
         RxUart0Buf[k] = '\0';
     } 
     sprintf(STR, "CSQ: %s\r\n\0",str);  
     UART1_WriteMsg(STR); 
   } else   SendDebugMsg("Get CSQ failed.\r\n\0");    
                   
}


char Modem_To_Sleep(void)
{     
                                                            
//      DTR_HIGH;     //DTR high - modem goes to power saving mode -CTS goes high 
//      delay_ms(2000);         
//    if(PINA.1 == 1)  //cts high when in power save mode
//      return TRUE; 
       return FALSE;    
}  

void SendSModemString( char *bufToSend, BYTE bufLen)
{
    BYTE i;

    for (i = 0; i < bufLen; i++)
        ComBuf[i] = bufToSend[i];
        //transmitt to local modem port
    BytesToSend = bufLen;
     TransmitBuf(0);
  //  ShowHexString(ComBuf);     //Danny- send to monitor
}

void SendPostHost()
{
    BYTE i, n;
    //build the host address from url+port
    n = CopyFlashToBuf(ComBuf, AT_POST_HOST);
    i = 0;
    while (eIPorURLval1[i] != '#')
    {
        ComBuf[(int)i+n] = eIPorURLval1[i];
        i++;
    }

      n += i;
      ComBuf[n++] = ':';
    cpu_e2_to_MemCopy(&ComBuf[n], ePORTval1, 4);
    n += 4;

                //    n-=4;
                //    ComBuf[n++] = '0';
                //    ComBuf[n++] = '0';
                //    ComBuf[n++] = '8';
                //    ComBuf[n++] = '0';

    ComBuf[n++] = '\r';
    ComBuf[n++] = '\n';
    BytesToSend = n;
     TransmitBuf(0);
  //  ShowHexString(ComBuf);     //Danny- send to monitor
}

void PutString(unsigned char* dest, unsigned char* src, int len)
 {
    int i;
    for (i = 0; i <len; i++)
        dest[i] = src[i];
 }

// build the string of parameters to send to web service
void BuildParamsBuff()
{
    int index;
    BYTE cs, i,;
   char hBuf[2];

    index = 0;

//    cpu_e2_to_MemCopy( &ComBuf[index], &unique_id[0], 4);  //logger ID
//    index += 4;
//     // Version
//    cpu_flash_to_MemCopy(&ComBuf[index], RomVersion, 2);
//    index += 2;

//    // ID
//    cpu_e2_to_MemCopy( &ComBuf[index], &unique_id[0], 4);   //logger id
//    index += 4;
//    // URL
//    cpu_e2_to_MemCopy( &ComBuf[index], eIPorURLval1, 32);
//    index += 32;
//    // APN
//    cpu_e2_to_MemCopy( &ComBuf[index], eAPN, 32);
//    index += 32;
//    //Port
//    cpu_e2_to_MemCopy( &ComBuf[index], ePORTval1, 4);
//    index += 4;
//
//// ICCID num.
//    for (i = 0; i < MAX_ICCID_LEN; i++)
//        ComBuf[index++] = ICCID[i];

    //MemCopy(&GPRSBuf[index],ICCID, MAX_ICCID_LEN);
    //index += MAX_ICCID_LEN;

//    // Wakeup timing
//    ComBuf[index++] = eStartConnectionH;
//    ComBuf[index++] = eConnectionInDay;
//    ComBuf[index++] = eConnectIntervalH;
//    // RSSI
//    ComBuf[index++] = rssi_val;


    // Clock
    e2_writeFlag = 0; //enable reading the rtc
    rtc_get_timeAll (readClockBuf);     //new - Danny
    ComBuf[index++] = readClockBuf[0]; //year
    ComBuf[index++] = readClockBuf[1]; //month
    ComBuf[index++] = readClockBuf[2]; //day
    ComBuf[index++] = readClockBuf[4]; //hour
    ComBuf[index++] = readClockBuf[5]; //minute

     //Battery
    ComBuf[index++] = (unsigned char)((iVoltage >> 8) & 0xFF);     //address high
    ComBuf[index++] = (unsigned char)(iVoltage) ;                 //address low

       for (i = SENSOR1; i < NumSensors; i++)
    {
          if(AlertStatus[i] == TRHRESHOLD_CROSSED)
          {
               cpu_e2_to_MemCopy( &ComBuf[index], &unique_id[(int)i*4], 4);   //sensor id
                index += 4;
                ComBuf[index++] = SensorType[i];             // set  type
                ComBuf[index++] = 1;  //AlertType[i]        //code for alert
                int2bytes(iLastMsr[i], hBuf);               //convert int to 2 bytes (high, low)
                ComBuf[index++] = hBuf[0] ;                 //Data high
                ComBuf[index++] = hBuf[1] ;                 //Data low
                ComBuf[index++] = '-' ;                 //end of alert block for sensor


          }
    }

    //check sum
    cs = CheckSum(ComBuf, index, 1);
    ComBuf[index++] = cs;

    ComBuf[index++] = '\r';
    ComBuf[index++] = '\n';
    BytesToSend = index;
}



// build the string of data to send to web service
// for 1st service, func "sensordata": length was 63
// for extended service (Nir), func "loggersensordata": length was  58
// for service with limites: func "loggersensordatath": length is: 62

//
//void BuildDataStr()
//{
//    #define POST_DATA  0x00
// //    #define POST_SPECIAL  0x01
//    #define POST_ALERT 0x03        //bit 0 high for special post
//    #define POST_PUMP  0x05        //bit 0 high for special post
//    #define POST_BACK_NORMAL  0x09 //bit 0 high for special post
//
//    int index;
//    int post_type = POST_DATA;
//    BYTE cs;
//    char buf[2];
// //  char  CRLF[] = {'\n','\r','\0'};
//
////     #ifdef DebugMode
////    SendDebugMsg("\r\nBuildDataStr()\r\n\0 ");
////    #endif DebugMode
//
//    index = 0;
//    // ID
//    cpu_e2_to_MemCopy( &ComBuf[index], &unique_id[objToMsr * 4], 4);   //sensor ID - 2 words hex
//    index += 2;                                                       //Danny -now 2 bytes. 2 more for battery
//
//      //Battery
//     ComBuf[index++] = (unsigned char)(iVoltage) ;                 //list
//    ComBuf[index++] = (unsigned char)((iVoltage >> 8) & 0xFF);     //most
//
//
//    //Type
//    ComBuf[index++] = GetSensorType();     // set  type
//
//    // interval
//    //cpu_e2_to_MemCopy( &ComBuf[index++], &cpue2_interval_1, 1);
//    ComBuf[index++] = (char)DataBlock[1] * INTERVAL_PARAM; // interval of block  5 min change
//
//    // logger ID
//    cpu_e2_to_MemCopy( &ComBuf[index], &unique_id[0], 4);     // set logger ID
//    index += 2;
//     //RSSI
//     ComBuf[index] = (unsigned char)(rssi_val) ;
//     index++;
//     //Prog Version
//      cpu_flash_to_MemCopy(&ComBuf[index], RomVersion, 1);   //Danny - prog ver data
//      index++;
//
//    // min & max values
//    int2bytes(MIN_LIMIT[objToMsr], buf);
//    MemCopy( &ComBuf[index], buf, 2);
//    index += 2;
//
//    int2bytes(MAX_LIMIT[objToMsr], buf);
//    MemCopy( &ComBuf[index], buf, 2);
//    index += 2;
//
//
//    // Timestamp
//    PutString(&ComBuf[index],&DataBlock[3], 5);         //DataBlock[10] - used to be cos offset of 7 from unknown reasen
//    index += 5;
//
//      //add two bytes of code here
//    if(IsAlertNeeded)
//        post_type |= POST_ALERT;
//
//    if ( PumpActivated)  //Danny - send bit once until PumpActivated is reset
//        post_type |= POST_PUMP;
//
//    if(BackToNormalAlertNeeded == TRUE)
//    post_type = POST_BACK_NORMAL;           //notify sever by bit 3
//
//     int2bytes(post_type, buf);
//    MemCopy( &ComBuf[index], buf, 2);
//    index += 2;
//
//    // values:
//    PutString(&ComBuf[index],&DataBlock[8], 40);      //DataBlock[15] - KANAL
//    index += 40;
//
//
//    //check sum
//    cs = CheckSum(ComBuf, index, 1);
//    ComBuf[index++] = cs;
//    ComBuf[index++] = '\r';
//    ComBuf[index++] = '\n';
//
// //    ComBuf[index++] = '/';        //Hagai asked to concel it
//
//
//    BytesToSend = index;             //62 bytec
//
//}
/*
void BuildDataStr()
{
    #define POST_DATA  0x00
 //    #define POST_SPECIAL  0x01
    #define POST_ALERT 0x03        //bit 0 high for special post
    #define POST_PUMP  0x04        //bit 0 high for special post
    #define POST_BACK_NORMAL  0x09 //bit 0 high for special post
    #define WLV_OVF_STAT 0x10       //060916
    #define MAG_SW_ON  0x40
    #define DATA_LOST  0x80;

    int index;
    int post_type = POST_DATA;
    BYTE cs;
    unsigned int unit_id;
    char buf[2],i;



//     #ifdef DebugMode
//    SendDebugMsg("\r\nBuildDataStr()\r\n\0 ");
//    #endif DebugMode

    index = 0;
      // Logger ID + sensor ID
    unit_id = elogger_id;                 //read eeprom val
    int2bytes((unsigned int)unit_id , buf);        //make word shifted  as two bytes
    MemCopy( &ComBuf[index], buf, 2);                  //enter 2 bytes logger id
    index += 2;



    cpu_e2_to_MemCopy( &ComBuf[index], &unique_id[objToMsr], 1);   //sensor ID - 1 byte + empty byte
    index ++;

    //reserved byte
    ComBuf[index++] = 0;       //reserved byte

     //sensor type
     ComBuf[index++] = 0;//GetSensorIOType();     // set server type

    // interval
    //cpu_e2_to_MemCopy( &ComBuf[index++], &cpue2_interval_1, 1);
    ComBuf[index++] = (char)DataBlock[1] * INTERVAL_PARAM; // interval of this block  5 min change

     //Battery  voltage
     ComBuf[index++] = (unsigned char)(iVoltage) ;                 //list
    ComBuf[index++] = (unsigned char)((iVoltage >> 8) & 0xFF);     //most


     //RSSI
     ComBuf[index] = (unsigned char)(rssi_val) ;
     index++;

     //Prog Version
//      cpu_flash_to_MemCopy(&ComBuf[index], RomVersion, 1);   //Danny - prog ver data
      index++;

 
  
        // min & max values
        int2bytes(MIN_LIMIT[objToMsr], buf);
        MemCopy( &ComBuf[index], buf, 2);
        index += 2;

        int2bytes(MAX_LIMIT[objToMsr], buf);
        MemCopy( &ComBuf[index], buf, 2);
        index += 2;
   

    // Timestamp
    PutString(&ComBuf[index],&DataBlock[3], 5);         //DataBlock[10] - used to be cos offset of 7 from unknown reasen
    index += 5;

      // status code
    if(IsAlertNeeded)
        post_type |= POST_ALERT;

    if ( PumpActivated)  //Danny - send bit once until PumpActivated is reset
        post_type |= POST_PUMP;

  
    if(SavedDataLost == 1)
    {
       post_type |= DATA_LOST;          //if reset memory accured
       SavedDataLost = 0;
    }

    int2bytes(post_type, buf);
    MemCopy( &ComBuf[index], buf, 2);
    index += 2;
    
    
    #ifdef GEVIM_ALERT_UNIT
        ComBuf[index++] = 0xFA;   //real data
        ComBuf[index++] = 0x00;    //real data
        for (i = 0;i < 38;i+= 2)
        {
           ComBuf[index+i] = 0xFF; 
           index++;
           ComBuf[index] = 0x7F; 
           
        }
    
    #else
    // values:
       PutString(&ComBuf[index],&DataBlock[8], 40);      //DataBlock[15] - KANAL  
    
    #endif  
    index += 40;


    //check sum
    cs = CheckSum(ComBuf, index, 1);
    ComBuf[index++] = cs;
    ComBuf[index++] = '\r';
    ComBuf[index++] = '\n';

 //    ComBuf[index++] = '/';        //Hagai asked to concel it


    BytesToSend = index;             //62 bytec

}
*/

/*
void SendPostParam()
{
   //  char endFileStr[10];

     // sign that for all next transmits - no need to wait for ana answer from modem
     bNeedToWait4Answer = FALSE;
     bSendData = 1;

     // preare end file mark string
//     endFileStr[0] = '-';                //Danny- no need for creacell
//     endFileStr[1] = '-';
//     cpu_flash_to_MemCopy(&endFileStr[2], PHYTECH_FILE_END_MARK, 8);

     //--- send post header---
  //   SendATCmd(AT_POST_TITLE_PRM);
//     SendATCmd(AT_POST_TITLE_ALERT );      //Danny for creacell alert stat
//     SendATCmd(AT_POST_CONN);
//     SendATCmd(AT_POST_TYPE);
//  //   SendATCmd(PHYTECH_FILE_END_MARK);
//     //GPRS_send_init_flash_string(AT_POST_HOST);
//     SendPostHost();
//     SendATCmd(AT_POST_LENGTH1);
//
//     // send file header:
//     SendSModemString(endFileStr, 10);         //10
//     SendATCmd(AT_POST_FILE_HDR1);       //45
//     SendATCmd(AT_POST_FILE_HDR_PRM);    //23
//     SendATCmd(AT_POST_FILE_HDR2);       //28

 //-------------Danny- as in post data
     SendATCmd(AT_POST_TITLE_ALERT );           //Danny for creacell alert stat
      SendPostHost();
     //   SendATCmd(AT_POST_HOST);                //25      "Host: 5.29.245.191:8080\r\n\0"
        SendATCmd(AT_POST_TYPE);                //40      "Content-Type: application/octet-stream\r\n\0"
        SendATCmd(AT_POST_ACCEPT);              //13    
        SendATCmd(AT_POST_USER_AGENT);          //28      "User-Agent: Creacell/1.0\r\n\0"
        // build post body                                    //110
        BuildParamsBuff();
        SendPostLength(BytesToSend);                     //        12 bytes: ID-4, code-1, data-2, date/time-5, cs-1, CRLF-2

     // send post
         TransmitBuf(0);
    // ShowHexString(ComBuf);     //Danny- send to monitor

     bNeedToWait4Answer = TRUE;
//     SendSModemString(endFileStr, 10);            //10

//     lastByteIndex = 0;
     longAnswerExpected = 1;
     overFlow = 0;
}
*/
//#ifdef EXT_SERVICE
void SendPostLength(int len)
{
    BYTE i, n;
    char s[4];
    //build the host address from url+port
    n = CopyFlashToBuf(ComBuf, AT_POST_LENGTH4);
    i = 0;

    //make bin as ascii
    do
    {
        s[i++] = (char)(len % 10);
        len = len / 10;
    }
    while (len > 0);
    for (; i > 0; i--)
       ComBuf[n++] = s[i-1] + 48;


    ComBuf[n++] = '\r';
    ComBuf[n++] = '\n';
    ComBuf[n++] = '\r';
    ComBuf[n++] = '\n';
    BytesToSend = n;
     TransmitBuf(0);
   // ShowHexString(ComBuf);     //Danny- send to monitor
}


 //adjusted for creacell way
void SendPostData()
{
  //    char endFileStr[10], i;
  //    BYTE nBlocks;
        int i,num, tmpNblk;
   //     char tObj2Msr;
   //     char bytes2send;
   //     char Blocks[NumSensors];
         unsigned int unit_id;

         char Tzone;


         tmpNblk = 0;
   //      tObj2Msr = objToMsr;
      //   DataSent = FALSE;
         #ifdef NO_SERVER
         objToMsr = 0;      //debug-remov
         #endif

  //count blocks of data to send 
  
       NumSensors = 0;  ////////////////test
  
  #ifndef GEVIM_ALERT_UNIT 
     if( NumSensors > 0)  
  {
//      do
//      {
//                                //Dannyi
//             SendDebugMsg("\r\nSensor index:   ");
//             PrintNum((long)objToMsr+1);
//          
//
//          {
//              tmpNblk += nUnreadBlocks;             //
//              objToMsr++;                           //go to next sensor location in mem
//          }
//      }
//       while (objToMsr  < NumSensors);
  } 
     #endif
  //   pBread_saved = TRUE;
       Option_2[0] = 1;        //flag in eeprom


 //   objToMsr = tObj2Msr;                      //regain initial number
    unit_id = 0x1427;// elogger_id;


    Num2String_Modem((long)unit_id);      //fill gBUF with loggr id ascii number
       // sign that for all next transmits - no need to wait for an answer from modem
        bNeedToWait4Answer = FALSE;

        //calc the length  
        
         #ifdef GEVIM_ALERT_UNIT
            num = 64;             //one block
        #else    
           if( NumSensors > 0) 
               num =(int)  tmpNblk * 64; // 62;               //        Is it the right way????????????  
           else num = 0; 
         #endif   
      
       
        
        SendATCmd(AT_POST_TITLE_DATA_LOGGER1);  //38     "POST /m2m/update/sensordata HTTP/1.1\r\n\0"
        SendPostHost();
     //   SendATCmd(AT_POST_HOST);                //25      "Host: 5.29.245.191:8080\r\n\0"
        SendATCmd(AT_POST_TYPE);                //40      "Content-Type: application/octet-stream\r\n\0"
        SendATCmd(AT_POST_ACCEPT);              //13     
        SendATCmd(AT_POST_USER_AGENT);                 //28      "User-Agent: Creacell/1.0\r\n\0"


        Tzone = eTimeZone;

     //   SendATCmd(TIME_ZONE);
        if(Tzone > 0)
        {
           ComBuf[0] =  '+';
        }
        else
        {
            Tzone *= -1;
            ComBuf[0] =  '-';

        }
         ComBuf[1] =  (Tzone / 10) + 0x30;
         ComBuf[2] =  (Tzone % 10) + 0x30;

     //    ComBuf[3] =  '\r';
     //    ComBuf[4] =  '\n';
     //    BytesToSend = 5 ;
     //     TransmitBuf(0);


        SendATCmd(UNITID);        //send looger id to server
        for(i = 0; i < 5; i++)
        ComBuf[i] = gBUF[i];
        ComBuf[i] =  '\r';
        ComBuf[++i] =  '\n';
        BytesToSend = 7 ;
          TransmitBuf(0);

//        SendATCmd(SIM_ID);        //send looger id to server
//        for(i = 0; i < 5; i++)
//        ComBuf[i] = eICCID[i];
//        ComBuf[i] =  '\r';
//        ComBuf[++i] =  '\n';
//        BytesToSend = 7 ;
//          TransmitBuf(0);
       
       if( NumSensors== 0)
       {  
          num = 0;
          SendPostLength(num);   
       } 
                       //
   #ifdef GEVIM_ALERT_UNIT     //send one fake data block
                     BuildDataStr();  //make fake block                                    
                     bNeedToWait4Answer = TRUE;           //  Danny-prepare for answer check            
                     BytesToSend = 64 ;    //save   BytesToSend
                  
                     TransmitBuf(0);
                    // SendDebugMsg("-");  //no...
                    BytesToSend = bytes2send  ;   //restore
  #else 
     
     if( NumSensors > 0)     
   {
//          do{
//
//        //       if (GetMeasurments(1) == FALSE)        //set again  nUnreadBlocks
//        //       {
//        //             SendDebugMsg("Failed GetMeasurments(1)\r\n\0 ");
//        //             ModemResponse = TASK_FAILED;
//        //             return;
//        //       }
//                  #ifdef NO_SERVER
//                 objToMsr = 0;      //debug-remov
//                 #endif
////                  while((GetMeasurments(1) == FALSE) && (objToMsr < NumSensors))
////                  {
////                         objToMsr++;
////                  }
////                  if(objToMsr ==  NumSensors)
////                  {
////                          SendDebugMsg("Failed GetMeasurments(1)\r\n\0 ");
////                           ModemResponse = TASK_FAILED;
////                           return;
////                  }
//          //   do
//             {
//
//                  // build post body
//                  //   BuildDataStr();  //adding creacell part
//                    //send the post
//                     if((objToMsr +1 == NumSensors) && (nUnreadBlocks == 1))
//                     bNeedToWait4Answer = TRUE;           //  Danny-prepare for answer check
//
//                #ifdef NO_SERVER
//                   ShowHexString(ComBuf, BytesToSend );     //Danny- send to monitor
//
//                #else
//                    bytes2send = BytesToSend ;    //save   BytesToSend
//                  
//                    TransmitBuf(0);
//                    // SendDebugMsg("-");  //no...
//                    BytesToSend = bytes2send  ;   //restore
//            //---------------------debug only------------------------
//            //        #ifdef DebugMode
//           //           ShowHexString(ComBuf, BytesToSend );  //Danny- send to monitor
//            //        #endif DebugMode
//            //------------------------------------------------------------
//               //   TransmitBuf(0);
//                #endif
//                  //    nUnreadBlocks--;
////                      if(  nUnreadBlocks)
////                      GetMeasurments(2);                    //
//                   //   ServerResponseTimeOut = 70;
//            }
//           //  while (nUnreadBlocks);
//
//            // objToMsr++;
//              #asm ("wdr");
//           }
//        //   while (objToMsr  < NumSensors);
  } 
  
   #endif
  
   ServerResponseTimeOut = 70;          //shorter than WD
   TimeLeftForWaiting = 70;

    //  DataSent = TRUE;
      longAnswerExpected = TRUE;         //Danny - buffer is 255 bytes-no need
      bNeedToWait4Answer = TRUE;

      rx0_buff_len = 0;
      overFlow = 0;


}
//"GET /api/device/crxxxxxxxx/listen  HTTP/1.1\r\n\0
void SendPostGET(void)
{
       
        char mBuf[11],i,j;
        
       
         SendDebugMsg("Send Post GET..\r\n\0 "); 
    //       SendATCmd(AT_POST_GET);     //old post 
    //    SendATCmd(AT_POST_GET_MANUAL);     
      //------------------------------------------------------       
         SendATCmd(AT_POST_GET_1);      //"GET /api/device/"            
         for(i = 0; i < 10; i++)
         ComBuf[i] = UNIT_NAME[i];     //load name from eeprom
         BytesToSend = 10 ;
         TransmitBuf(0);             //send unit name as part of GET string
         SendATCmd(AT_POST_GET_2);     // /listen  HTTP/1.1\r\n\0
      //----------------------------------------------------------             
         SendATCmd(AT_POST_CHUNKED);

             
        //------------------Program Version---------------         
           for(i = 0; i< 6; i++)
           mBuf[i] = fw_version[i];
           mBuf[i] = '\0';
           sprintf(ComBuf,"FW_VERSION: %s\r\n",mBuf);
     
           BytesToSend = 20; //12 + i;
           TransmitBuf(0); 
        //=================COPS===========================                  
         i=0; 
         while(COPS_value[i] != '\0')
        {
             mBuf[i] =  COPS_value[i];
             i++;
        } 
         sprintf(ComBuf,"COPS_ID: %s\r\n",mBuf); //set string to be sent);  
         BytesToSend = 11 + i;
         TransmitBuf(0);  
        //------------------SIM ID---------------------------                 
        SendATCmd(SIM_ID);        //send looger id to server
        for(i = 0; i < 20; i++)
        ComBuf[i] = ICCID[i];
        ComBuf[i++] =  '\r';
        ComBuf[i++] =  '\n'; 
        ComBuf[i++] =  '\r';
        ComBuf[i++] =  '\n'; 
        BytesToSend = i ;
        TransmitBuf(0);
       //----------------------------------------------------  
        ServerResponseTimeOut = 50;          //shorter than WD
       TimeLeftForWaiting = 50;                     
       longAnswerExpected = TRUE;         //Danny - buffer is 255 bytes-no need
       bNeedToWait4Answer = TRUE;  
      
       KeepAliveMsgNeeded = FALSE;                                                                             
       Keep_Alive_timer = 50;//KeepAlivePeriod; 
       SearchServerDataBase = TRUE;
       ENABLE_TIMER1();
       
}

//adjusted for creacell way
void SendPostInfo(char index)
{

        unsigned int tmpInt;
        char buf[2],i,j;
       unsigned int unit_id ;  
       unsigned char CHECK_USER[] = "15\r\nCHECK_USER:\0";  //15h  
       char mBuf[11];


//         #ifdef DebugMode
          SendDebugMsg("Send Post info..\r\n\0 ");
//        #endif DebugMode

        delay_ms(500);  //debug 
    //    goto END;

        bNeedToWait4Answer = FALSE;
        unit_id = elogger_id;
        Num2String_Modem((long)unit_id);      //fill gBUF with loggr id ascii number  
        
         if((index == 3) || (index == 2))                  //ask list update
          SendATCmd(AT_POST_LIST_UPDATE);  //   POST /m2m/list_update/general HTTP/1.1\r\n\0"  
   //---------------------------------------------       
      
//        else 
//        {   
//            SendATCmd(AT_POST_ALERT);  //   POST /m2m/update/general HTTP/1.1\r\n\0"  
//            
//             SendPostHost();                         //gates.crea-cell.com:3000
//           SendATCmd(AT_POST_TYPE);                //40      "Content-Type: application/octet-stream\r\n\0" 
//        
//            SendATCmd(AT_POST_ACCEPT);              //13      "Accept: */*\r\n\0"
//            SendATCmd(AT_POST_USER_AGENT);          //28      "User-Agent: Creacell/1.0\r\n\0" 
//        }   
        
         if((index == 3) || (index == 2))                 //ask list update
           SendPostLength(12);     //   POST /m2m/list_update/general HTTP/1.1\r\n\0"
             
          else  if(index == 5) //search caller id in sever data base
          {     
               i = 0; 
               j = 0;
               while(CHECK_USER[i] != '\0') 
               {                       
                     ComBuf[i] = CHECK_USER[i];   //21\r\nCHECK_USER: 
                     i++;                         
               }
                                                                                                                                   
               do
               {                       
                     ComBuf[i++] = CallerIdBuf[j++];   //collect num digits to be sent to server                           
               }
               while(j < 10) ;  //10???
               
              ComBuf[i++] = '\r';    
              ComBuf[i++] = '\n';  
             //  SendPostLength(BytesToSend); //notify server body size  
             
//                for(i = 0; i< 10; i++)
//                mBuf[i] = CallerIdBuf[i];
//                mBuf[i] = '\0';
//                sprintf(ComBuf,"15\r\nCHECK_USER:%s\r\n",mBuf);
     
                BytesToSend = i; //12 + i;
               
                                                            
          }  
           
        else
           SendPostLength(6);  
                                    //
          // build post body
          if(index == 0)       //cover alert
          {
              ComBuf[2] = 0xF1;    //code F1, F2,F3..
          }

                     
           else if((index == 3) || (index == 2))    //ask for new users list
          {     
                i = 0;
               while(i < 10) 
               {
                     ComBuf[i] = eUnit_Name[i];   //read eeprom addres 0x01B0 
                     i++;   
               }  
                ComBuf[i++] = '_';
               if (index == 2)   //tell server to send file                  
                    ComBuf[i++] = 'S';                                       
               else
                ComBuf[i++] = '?';  //ask server if file ready
                   
                ComBuf[i++] = 0x00; 
                BytesToSend = i;
          }  
              
          else  if(index == 5) //search caller id in sever data base
          {
                  
                 BytesToSend = i;//do none - all set befor                                                      
          }
                             
          else
          {
              tmpInt = elogger_id;                 //read eeprom val
              int2bytes((unsigned int)tmpInt , buf);        //make word shifted  as two bytes
               MemCopy( &ComBuf[0], buf, 2);                  //enter 2 bytes logger id
              ComBuf[3] = 0;
              ComBuf[4] = 0;
              ComBuf[5] = 0;

              BytesToSend = 6 ;
          }
                             
          ServerResponseTimeOut = 50;          //shorter than WD
          TimeLeftForWaiting = 50;                     
          longAnswerExpected = TRUE;         //Danny - buffer is 255 bytes-no need
          bNeedToWait4Answer = TRUE;
          overFlow = 0;   
//         ShowHexString(ComBuf, BytesToSend );     //Danny- send to monitor

//          if(index == 5)
//         BytesToSend = i; 
         
         delay_ms(50);
          TransmitBuf(0);   //send the post body
//        #asm ("wdr");

}


BYTE GetBufferIndex(int i)
{
    BYTE b;

    if (i >= MAX_RX0_BUF_LEN)
        b = (BYTE)i - MAX_RX0_BUF_LEN;
    else
        b = i;
    return b;
}

BYTE IsOK()
{
  
      char *ptr;

   
        ptr = strstrf(RxUart0Buf, "OK"); 
        if(ptr != NULL)
        return TRUE;                    
        return FALSE;
}

BYTE IsConnect()
{
    
    char *ptr;
//  delay_ms(1000);
  if(rx0_buff_len > 5)   //msg long enough
  {     
  
        ptr = strstrf(RxUart0Buf, "CONN"); 
        if(ptr != NULL)
        {
                longAnswerExpected = TRUE;
                ServerComOn = TRUE;
                Timer0_Ticks = 7;
             //   MODEM_GOT_IP = TRUE ;   //flag shows IP exist
                return TRUE;
        }  
         SendDebugMsg("Wait for CONNECT..\r\n\0"); 
         rx0_buff_len = 0;
         ErrorType = 1;        
     //    MODEM_GOT_IP = FALSE;
         return FALSE;         
  }

    
}

 BYTE IsNO_CARRIER()
{
    char *ptr;
    
     ptr = strstrf(RxUart0Buf, "NO C"); 
     if(ptr != NULL)
     { 
          return TRUE;
     } 
      return FALSE;     
}

BYTE Is_IP_REC()
{
    BYTE index = 0;

     index = 0;

    while (index < rx0_buff_len-1)
    {    
        if ((RxUart0Buf[index] == '.') && ((RxUart0Buf[(int)index+1] >='0') || (RxUart0Buf[(int)index+1] <='9')))
        {
            return TRUE;
        }
        else
            index++;
    }
    return FALSE;
}

BYTE    IsRegistOK()
{
   // BYTE index = 0;  
    char *ptr = NULL;
  
      bUseRoaming = FALSE; 
      
    
    // SendDebugMsg("IsRegistOK().. \r\n\0 "); 
     
      ptr = strstrf( RxUart0Buf, "0,1"); 
     if(ptr == NULL)       
      ptr = strstrf( RxUart0Buf, "0,5"); 
     if(ptr == NULL)
     {    
             SendDebugMsg ("Not Registered..\r\n\0"); 
             return 0; 
     }   
     else
     {     
            SendDebugMsg ("Modem Registered..\r\n\0"); 
           return TRUE;
     }
      
    return FALSE;
}

BYTE Is_IP_OK()
{
    BYTE index = 0;

    //find the , (comma \ psik)
    while (index < rx0_buff_len)

    {
        if (RxUart0Buf[index++] == ',')
            break;
    }

    // if , was found - lookon the digitt after: and before
    if (index < rx0_buff_len)
        if ((RxUart0Buf[index] == '1') && (RxUart0Buf[index - 2] == '1'))
        {
            return TRUE;
        }

       return FALSE;
}


void GetICCID()
{
    int n, i = 0;
    if (!IsOK())
        return;
//   SendDebugMsg("ICCID valid..!\r\n\0");
    //find begining of SIM num
    while ((RxUart0Buf[i] < '0') || (RxUart0Buf[i] > '9'))
        i++;
     n = 0;
    do
    {
        ICCID[n++] = RxUart0Buf[i++];
    }
    while ((RxUart0Buf[i] >= '0') && (RxUart0Buf[i] <= '9') && (n < 20));

//    for (; n < 20; n++)
//        ICCID[n] = '*'; //fill buf until 20 chars


 //   SendDebugMsg("ICCID saved..!\r\n\0");
    for( i = 0; i < 5; i++)
    eICCID[i] = ICCID[n-5 + i];  //write to eeprom last 5 digits


}

//+COPS: 0,0,"Orange"
char Get_COPS()
{
    int n, i = 0;  
   
    while ((RxUart0Buf[i] != '"') && (i < (rx0_buff_len - 5)))   //look for first "
        i++; 
         
   if(i < (rx0_buff_len - 5))
   {     
        i++;      //point to string
        n = 0;
        while (RxUart0Buf[i] != '"') 
        {
            COPS_value[n++] = RxUart0Buf[i++];
        }         
        COPS_value[n] = '\0';  //termination char  
        return 1;
   }
   else 
   {
         for(i = 0; i< 8; i++)
         COPS_value[i] = 'x';  
         COPS_value[i] = '\0';
         SendDebugMsg("No COPS value found..\r\n\0"); 
   } 
   return 0;   
}
//check numbers in between dot are leagal, i.e. not large than 256
BYTE IsLegalNum(char* ip, BYTE indexFirst, BYTE indexLast)
{
    BYTE numDigits, index;
    int num, multy;

    numDigits = indexLast - indexFirst + 1;
    if (numDigits > 3)
        return FALSE;
    if (numDigits == 3)
    {
        multy = 1;
        num = 0;
        index = indexLast;
        while (numDigits > 0)
        {
            num += (ip[index--] - 0x30) * multy;
            multy *= 10;
            numDigits--;
        }
        if (num > 255)
            return FALSE;
    }
    return TRUE;
}

//get new ip and check if its leagal, i.e: 4 numbers from 0 to 255 seperate by '.' (dots).
BYTE IsLegalIP(char* ip)
{
    BYTE dotCntr = 0, n = 0, lastDotIndex = -1;
    while ((ip[n] != '#') && (n < 32))
    {
        if ((ip[n] < '0') || (ip[n] > '9'))
        {
            if (ip[n] != '.')  //if ip is not a number or dot
                return FALSE;
            else
            {
                dotCntr++;               // count dots
                if (n == 0)             // if first IP char is dot
                    return FALSE;
                if ((dotCntr > 1) && (lastDotIndex + 1 == n))  //if its not first dot and the last dot is one index before-meanning 2 dots in a row
                    return FALSE;
                if (!IsLegalNum(ip, lastDotIndex + 1, n - 1))   //check if number in between dots is leagal
                    return FALSE;
                lastDotIndex = n;
            }
        }
        n++;
    }
    if (lastDotIndex + 1 == n) //if last IP char is dot
        return FALSE;
    if (dotCntr != 3)       // ip address can contain exactly 3 dots
        return FALSE;
    if (!IsLegalNum(ip, lastDotIndex + 1, n - 1))     //check if last number is leagal
        return FALSE;
    return TRUE;
}




// is task send as bytes
int ParseSnsrMinMax(char* sID, BYTE lmt)
{
    int i = 0, j = 0;
    long l = 0, lID = 0;
    char s[4];
    int min,max;
    BYTE  nSenNum, res = 0;;

    nSenNum = sID[0];
    if (nSenNum > MAX_SEN_NUM)
        return -1;
    #ifdef DebugMode
    #ifndef MEGA324
    SendDebugMsg("\r\nNum sensor to set limits: ");
    #endif

    PrintNum(nSenNum);
    #endif DebugMode
    for (j = 0; j < nSenNum; j++)
    {
        lID = Bytes2Long(&sID[j*8 + 1]);

        #ifdef DebugMode
        #ifndef MEGA324
        SendDebugMsg("\r\nSensor to change limits: ");
        #endif

        PrintNum(lID);
        #endif DebugMode
        for (i = SENSOR1; i < NumSensors; i++)
        {
            cpu_e2_to_MemCopy(s, &unique_id[i*4], 4);
            l = Bytes2Long(s);
//            #ifdef DebugMode
//            SendDebugMsg("\r\nSensor  ");
//            PrintNum(l);
//            #endif DebugMode
            if (l == lID)
            {
                #ifdef DebugMode
                SendDebugMsg("\r\nfound sensor: ");
                PrintNum(i);
                #endif DebugMode
                min = bytes2int(&sID[j*8 + 5]);  //
                max = bytes2int(&sID[j*8 + 7]);
                #ifdef DebugMode
                SendDebugMsg("\r\nMin value: ");
                PrintNum(min);
                SendDebugMsg("\r\nMax value: ");
                PrintNum(max);
                #endif DebugMode
                // if function was called to update limits
                if (lmt == 0)
                {
                    if (min < max)
                    {
                        MIN_LIMIT[i] = min;
                        MAX_LIMIT[i] = max;
                        res++;
                    }
                }
                else  //if function was called to update back to routine
                {
                    MIN_LIMIT[i] = min;
                    MAX_LIMIT[i] = max;
                    res++;
                }
            }
        }
    }
    if (res != nSenNum)   // if num of sensor was defined is different from num of sensor was sent - something wrong
        return -1;
    return 1;
}


void ParseModemResponse()
{
    char i;

    switch (modemCurSubTask)
    {
       
        case SUB_TASK_INIT_MODEM_COPS:
        case SUB_TASK_INIT_MODEM_GET_COPS:
        case SUB_TASK_INIT_MODEM_PARAMS:
        case SUB_TASK_INIT_MODEM_RSSI:
        case SUB_TASK_MODEM_CONNECT_ATCH:
        case SUB_TASK_MODEM_CONNECT_SETUP1:
        case SUB_TASK_MODEM_CONNECT_SETUP2:
        case SUB_TASK_MODEM_CONNECT_SETUP3:
        case SUB_TASK_MODEM_CONNECT_PDP_DEF:

     
            if (IsOK() == TRUE)
            {    
                 //  SendDebugMsg("OK = TRUE..\r\n\0");
                ModemResponse = TASK_COMPLETE;

                if (modemCurSubTask == SUB_TASK_INIT_MODEM_RSSI)
                {
                      ConvertRssiVal();

                 #ifdef AGRICULTURE_TASK
                        if((rssi_val < 6) || (rssi_val >= 99))
                  #else
                        if((rssi_val < 8)|| (rssi_val >= 99))
                 #endif

                    {
                         ModemResponse = TASK_FAILED;
                      //   ModemRepeatNeeded = TRUE;         //for new trial of communication
                    }

                }
                else if (modemCurSubTask == SUB_TASK_INIT_MODEM_GET_COPS)
                {
                      i = Get_COPS(); 
                      if(i)
                      ModemResponse = TASK_COMPLETE;
                      else
                      ModemResponse = TASK_FAILED; 
                } 
            }
            else
            {
                ModemResponse = TASK_FAILED;
                ModemRepeatNeeded = TRUE;         //for new trial of communication

            }
        break; 
          
         case SUB_TASK_INIT_MODEM_OK:
                     if (IsOK() == FALSE)
                     {
                          ModemResponse = TASK_FAILED;
                     } 
                     else  ModemResponse = TASK_COMPLETE;  
         break;
        
          case SUB_TASK_INIT_MODEM_REG:  
           
          //  SendDebugMsg("check CREG response..\r\n\0 "); 
            if (IsRegistOK() == TRUE) 
            {
                  ModemResponse = TASK_COMPLETE;   
               //   SendDebugMsg("CREG OK -TASK_COMPLETE ..\r\n\0 ");
                  heat_time = 0;  
            }            
             else
            {   
                  SendDebugMsg("CREG response failed..\r\n\0 "); 
                  ModemResponse = TASK_FAILED;
                  ModemRepeatNeeded = TRUE;         //for new trial of communication
             //    ModemRepeatCount++;
            } 
               modemCurTask = TASK_MODEM_INIT; 
        break;

        case SUB_TASK_MODEM_CLOSE_PPP:

         //    if (IsOK() == TRUE)
                ModemResponse = TASK_COMPLETE;

        break;
        
        case SUB_TASK_MODEM_CLOSE_TCP:
        case SUB_TASK_MODEM_CLOSE_MDM:

            if (IsOK() == TRUE)
            {
                ModemResponse = TASK_COMPLETE;
            }
            else
                 ModemResponse = TASK_COMPLETE;     //test 9
             //   ModemResponse = TASK_FAILED;
        break;

      

         case SUB_TASK_INIT_MODEM_REG_GPRS:
            if (IsRegistOK() == TRUE)
                ModemResponse = TASK_COMPLETE;
             else
            {
                ModemResponse = TASK_FAILED;
                ModemRepeatNeeded = TRUE;         //for new trial of communication
             //    ModemRepeatCount++;
            }
        break;

        case SUB_TASK_MODEM_CHK_ICCID:
            GetICCID();
            //ConvertIccID();
            ModemResponse = TASK_COMPLETE;
        break;

        case SUB_TASK_MODEM_CONNECT_START_DIAL:

               i = 0;
               ConnectedToServer = FALSE;
               delay_ms(500);

               do{
                 // #asm("wdr")

                      i++;
                     if (IsConnect() == TRUE)
                     {
                          ModemResponse = TASK_COMPLETE;
                          ConnectedToServer = TRUE;
                        //  ServerResponseTimeOut = 200;
                     }
                      else
                      {
                            delay_ms(1000);   
                      }
                }
               while((ConnectedToServer == FALSE) && (i < 15));

                if(ConnectedToServer == FALSE)
                 {
                     ModemResponse = TASK_FAILED;
                     ModemRepeatNeeded = TRUE;         //for new trial of communication
                 //    ModemRepeatCount++;
                      Timer0_Ticks = 6;              //restore regular value
                       ServerResponseTimeOut = 70;
                 }
        break;

         case SUB_TASK_MODEM_POST_DATA:
         case SUB_TASK_MODEM_ASK_LIST_UPDATE: 
         case SUB_TASK_MODEM_WAIT_FOR_LIST: 
          case SUB_TASK_MODEM_SEND_GET: 

               i = CheckResult();   //check server response msg
              if (i == -2)   //server response is too short - SIM800? ignor it..
              {                
                   #asm("wdr")
                  delay_ms(2000);
                  i = CheckResult();
              }

               if ((i > -1) || (Found200 == TRUE))
              {
                     ModemResponse = TASK_COMPLETE;
              }
              else
              {
                   //   #asm("wdr")                  
                      ModemResponse = TASK_FAILED;                      
              }

        break; 
        
//         case SUB_TASK_MODEM_SEND_GET: 
//             //check how to end it  
//                ModemResponse = TASK_COMPLETE;
//         break;
     }
        
          
 }


int CheckResult()
{
 
    int index;  
    char *ptr; 
    
//   SendDebugMsg("\r\nCheckResult()..\r\n\0 ");
    
   if(( rx0_buff_len < 7) && (Found200 == FALSE))
   {
    //    SendDebugMsg("\r\n** CheckResult() - Too short response\r\n\0 ");
          return -2;    //short  to be ok
   }

    Timer0_Ticks = 7;
  
       delay_ms(1000);
       index = -1;  
       
//     ptr = strstrf( RxUart0Buf, "ERR"); //look in fuffer for 200
//     if(ptr != NULL)
//     {
//         SendDebugMsg ("ERROR found..!\r\n\0");               
//     }    
    
    
    if(SearchServerDataBase == TRUE)   //expecting modem opening msg
    {
         ptr = strstrf( RxUart0Buf, "APPRO"); //expect APPROVED101
         if(ptr != NULL)
         {
            // SendDebugMsg ("APPROVED, open gate..\r\n\0"); 
             
              index = (ptr - RxUart0Buf) + 8;    // index point to relay index digit in buffer (OPEN102)
              ActiveRelay =  RxUart0Buf[index]-0x30;   // make it bin
              index++;                                //point to period value (2 gigits)
              Relay_period =  ((RxUart0Buf[index++]-0x30) * 10 + ( RxUart0Buf[index]-0x30));  //100mS clock ticks (sec*10)  
              if(( Relay_period < 0) || ( Relay_period > 15))
               Relay_period = 2;    //default
               else
               {
                    if(Relay_period == 0) 
                     Relay_period = 0.1;  //short for Hamama
               }
              if( ActiveRelay == 1)
                  OpenRelay1(); // 
              else  OpenRelay2();  
           
                sprintf(ComBuf,"6\r\nOPENED\r\n");   //notify server  
                BytesToSend = 11; //12 + i;
                TransmitBuf(0);  
                                 
                delay_ms(Relay_period * 1000); //ms
                  
                 if( ActiveRelay == 1)
                 CloseRelay1();
                 else   CloseRelay2();    
                                          
          }
            else
        {    
              ptr = strstrf( RxUart0Buf, "REJE");
              if(ptr != NULL)
             {
                 SendDebugMsg ("REJECTED..\r\n\0");                                                
             }
        }  
                                                               
     }
             
    // if hasnt find - return -1, means no data got back
     else if ((index == -1) && (Found200 == FALSE))   //no 200 from server
     {
        return -1;
     }
//    else    //200 found - sccess
//    {      
//      
//       //  ok = Pharse_params_struct(RxUart0Buf, 0);  //look for list data - lengh   
//       //   ok = Pharse_Server_Response(RxUart0Buf, 0);  //200{"OK"} 
//          
//         if(ListUpdateNeeded == TRUE) //list update requsted from server
//         {
//         
////             if(ListSize > 0)       //set in  Pharse_params_struct()     200{"L":0195}
////             {
////                  return 2;     //
////             }
//         }
//          
//        
//         }
             
      ServerResponseTimeOut = 40;          //shorter than WD
      TimeLeftForWaiting = 40;

       return 1;
 //   return index;
}

/*
// if eMobileCntryCode & eMobileNetCode are integers:
BYTE IntToStr(BYTE * to, int tmp)
{
    BYTE m[3];
    BYTE j, k, i = 0;

    // seperate each numbers into digits
    while (tmp > 0)
    {
        k = tmp % 10;
        m[i++] = k + 48;
        tmp = tmp / 10;
    }
    if (i == 1)
        m[i++] = 48;
    j = 0;
    //reverse the string
    do
    {
        i--;
        to[j++] = m[i];
    }
    while (i > 0);
    return j;
}
*/
//void SendOperatorSelection()
//{
////    if (eNotInUse == 0)
////        eNotInUse = 1;
//    if (bExtReset == TRUE) //|| (eUseCntrCode == 1) || ((eUseCntrCode == 0) && (eOperatorType != '5')))
//        SendATCmd(AT_COPS_AUTO);
//    else
////      if (eOperatorType == '5')
//        if (eUseCntrCode == 1)
//        {
//            BYTE i, n;
//            //build the cops command  from country+network codes
//            n = CopyFlashToBuf(ComBuf, AT_COPS_MAN);
//            ComBuf[n++] = '"';
//            i = 0;
//            while (eMobileCntryCode[i] != '#')
//            {
//                ComBuf[(int)i+n] = eMobileCntryCode[i];
//                i++;
//            }
//            n += i;
//            i = 0;
//            while (eMobileNetCode[i] != '#')
//            {
//                ComBuf[(int)i+n] = eMobileNetCode[i];
//                i++;
//            }
//            // if eMobileCntryCode & eMobileNetCode are integers
////            i = IntToStr(&ComBuf[n], eMobileCntryCode);
////            n += i;
////            i = IntToStr(&ComBuf[n], eMobileNetCode);
//            n += i;
//            ComBuf[n++] = '"';
//            ComBuf[n++] = '\r';
//            ComBuf[n++] = '\n';
//            BytesToSend = n;
//            TransmitBuf(0);
//        }
//}

void SendStartDial()
{
    BYTE i, n;
    //build the cops command  from country+network codes  
    
    
           
    
    n = CopyFlashToBuf(ComBuf, AT_TCP_OPN);
#ifdef SIM800
      
 //   n++;
    ComBuf[n++] = '"';
    i = 0;
    while ((eIPorURLval1[i] != '#') && (i < 32))
    {
        ComBuf[(int)i+n] = eIPorURLval1[i];
        i++;
    }
    n += i;
    ComBuf[n++] = '"';
     ComBuf[n++] = ',';
     ComBuf[n++] = '"';
     cpu_e2_to_MemCopy(&ComBuf[n], ePORTval1, 4);
     n += 4;
      ComBuf[n++] = '"';
#else
    cpu_e2_to_MemCopy(&ComBuf[n], ePORTval1, 4);
     n += 4;
    ComBuf[n++] = ',';
    ComBuf[n++] = '"';
    i = 0;
    while ((eIPorURLval1[i] != '#') && (i < 32))
    {
        ComBuf[(int)i+n] = eIPorURLval1[i];
        i++;
    }
    n += i;
    ComBuf[n++] = '"';

#endif

    ComBuf[n++] = '\r';
    ComBuf[n++] = '\n';
    BytesToSend = n;
    TransmitBuf(0);

   // ShowHexString(ComBuf);     //Danny- send to monitor
}


//1,0,0080,"crea-cell.com"


//void SendStartDial_test()
//{
//    BYTE i;
//   char str[] = "AT#SD=1,0,8180,\"54.149.4.152\"\r\n\0 ";   //32
//
//   for(i = 0; i < 31; i++)
//   {
//      ComBuf[15] = str[i];
//   }
////   ComBuf[15] = = "\"";
////    ComBuf[28] = ="\"";
////    ComBuf[29] = = '\r';
////    ComBuf[30] = = '\n';
//
//    BytesToSend = 31;
//    TransmitBuf(0);
//   // ShowHexString(ComBuf);     //Danny- send to monitor
//}
void SendPDPCntDef()
{
    BYTE i, n;
    //build the cops command  from country+network codes
    n = CopyFlashToBuf(ComBuf, DEF_PDP_CNTXT);
    ComBuf[n++] = '"';
    i = 0;
    while ((eAPN[i] != '#') && (i < 32))
    {
        ComBuf[(int)i+n] = eAPN[i];
        i++;
    }
    n += i;
    ComBuf[n++] = '"';
    ComBuf[n++] = '\r';
    ComBuf[n++] = '\n';
    BytesToSend = n;
    TransmitBuf(0);
   // ShowHexString(ComBuf);     //Danny- send to monitor
}

BYTE GetNextModemTask()
{

   
        
    if (modemCurTask == TASK_NONE)
    {     
         //  SendDebugMsg("Modem TASK_NONE..\r\n\0 ");
          if((RING_PULSE_ACTIVE == TRUE )) // Ring detedted?  SMS
          {       
                  modemCurTask = TASK_MODEM_SMS_HANDLE;   
                  modemCurSubTask = SUB_TASK_MODEM_RECEIVED_SMS;
          }           
          else  
          if(ReDialNeeded == TRUE)    //connection closed - new connection with server needed- new dial
           {       
                    ReDialNeeded = FALSE;
                    modemCurTask = TASK_MODEM_CONNECT; 
                    modemCurSubTask = SUB_TASK_MODEM_CONNECT_START_DIAL; //SUB_TASK_MODEM_SEND_GET;   //re connect to server
           }
 
         else if( MODEM_GOT_IP == TRUE)  //modem has IP-no need to start again
         {      
             //   SendDebugMsg("none - MODEM_GOT_IP= TRUE..\r\n\0 ");
               if(SearchServerDataBase == TRUE)     //working with server
               {         
                        if(SearchDial == TRUE)
                        {       
                                SearchDial = FALSE;
                                modemCurTask = TASK_MODEM_POST; 
                                modemCurSubTask = SUB_TASK_MODEM_POST_DATA;   //send user data to be checked by server
                        }

               }
               else
               {
                   modemCurTask = TASK_MODEM_INIT;   
                       
                   modemCurSubTask =  SUB_TASK_INIT_MODEM_GET_COPS; //start connection with server 
                  LED2_ON; 
               }
         }   
        
         else
         {
                 modemCurTask = TASK_MODEM_INIT;
                 modemCurSubTask = SUB_TASK_INIT_MODEM_OK; //CHECK MODEM AND INIT  
                  #asm("sei");
             //   SendDebugMsg("to SUB_TASK_INIT_MODEM_OK\r\n\0 ");
         }
                initCnt = 0; 
        //        SendDebugMsg("Modem-task none..\r\n\0");  
               return  CONTINUE;
    }  
       
                 
     if ((bWaitForModemAnswer == TRUE) && (TimeLeftForWaiting == 0))       //important check
    {
        bWaitForModemAnswer = FALSE;
        ModemResponse = TASK_FAILED;
        ModemRepeatNeeded = TRUE;

        SendDebugMsg("\r\nModem answer - Wait time out..\r\n\0 ");
    }

    // if flag of end of rx received is on
     if (Modem_Message_Recieved == TRUE)                 //new msg in RX buf
    {    
      //  SendDebugMsg("\r\nModem answer -check..\r\n\0 ");
         Modem_Message_Recieved = FALSE;
          if(ConnectedToServer == TRUE)      //ver 54
          {             
            //  ServerResponseTimeOut = 70;
          }
         else 
         {   
           //  SendDebugMsg("goto ParseModemResponse()..\r\n\0 ");
                                 
         }
            ParseModemResponse(); 
            heat_time = 0;
    }
 
     
    if (heat_time > 0)
        return WAIT; 
  
  //---------------------------------------------------------
    switch (ModemResponse)
    {
        case NO_ANSWER:
            return WAIT;

        case TASK_COMPLETE:
        {    
          
          //   SendDebugMsg("in TASK_COMPLETE ..\r\n\0 "); 
            switch (modemCurTask)              
            {    
                      case TASK_MODEM_SMS_HANDLE:                    
                      switch (modemCurSubTask)
                      { 
                              case SUB_TASK_MODEM_RECEIVED_SMS: 
                              case SUB_TASK_MODEM_ALERT_SMS:
                                 
                                   modemCurTask = TASK_MODEM_CLOSE;
                                   modemCurSubTask = SUB_TASK_MODEM_ENDED ; 
                                   SendDebugMsg("complete SMS handling-to BLE..\r\n\0 "); 
                                 
                             break; 
                      }    
                      break;
            
                 case TASK_MODEM_INIT:  
                 //   SendDebugMsg("TASK_MODEM_INIT - TASK_COMPLETE..\r\n\0 "); 
                    switch (modemCurSubTask)
                    {
                        case SUB_TASK_INIT_MODEM_ON:
                  
                            modemCurSubTask = SUB_TASK_INIT_MODEM_IGN;
                        break;

                        case SUB_TASK_INIT_MODEM_IGN: 
                            
                              IGNIT_IO_OFF;         //end ignit pulse
                               Modem_Message_Recieved = FALSE;                                         
                               modemCurSubTask = SUB_TASK_INIT_MODEM_OK; 
                           //    SendDebugMsg("complete Modem ignit - to ok..\r\n\0 "); 
                               delay_ms(2000);
                        break;

                        case SUB_TASK_INIT_MODEM_OK:
                           //     SendDebugMsg("complete Modem OK - to RSSI..\r\n\0 ");
                                modemCurSubTask = SUB_TASK_INIT_MODEM_RSSI;  
                              //  heat_time = 70; //was 100 Danny - delay before rssi
                              delay_ms(2000);                     
                        break;  
                        
                        case SUB_TASK_INIT_MODEM_RSSI: //todo: check rssi and continue only if it over min

                                 modemCurSubTask = SUB_TASK_INIT_MODEM_REG;                        
                                 heat_time = 15; //delay before attach

                        break; 
                        
                          case SUB_TASK_INIT_MODEM_REG:
                    
                           //   delay_ms(700);  //5000 Danny                               
                               modemCurSubTask = SUB_TASK_INIT_MODEM_PARAMS;
                           //    SendDebugMsg("CREG  complete..\r\n\0 "); 
                              heat_time = 20;   

                        break;    
                          
                         case SUB_TASK_INIT_MODEM_PARAMS:  
                         
                               if(SearchServerDataBase == TRUE)
                           //   modemCurSubTask = SUB_TASK_MODEM_CONNECT_ATCH ;
                               modemCurSubTask = SUB_TASK_INIT_MODEM_GET_COPS; //need cops to be sent to server
                               else
                               {
                                   modemCurTask = TASK_MODEM_CLOSE;
                                   modemCurSubTask = SUB_TASK_MODEM_ENDED ; 
                                   ModemAlive = TRUE; 
                                   MODEM_GOT_IP = TRUE ;   //flag shows IP exist
                                   SendDebugMsg("complete Modem setting - to BLE..\r\n\0 "); 
                               }
                        break;
                        
                        
                        case SUB_TASK_INIT_MODEM_GET_COPS: //no need

                             
                            //   modemCurSubTask = SUB_TASK_MODEM_CONNECT_ATCH ; 
                                 modemCurSubTask = SUB_TASK_MODEM_CHK_ICCID ;       //test- go to sleep here
                        break;   
                        
                         case SUB_TASK_MODEM_CHK_ICCID:  
                                  
                                //   modemCurSubTask = SUB_TASK_MODEM_CONNECT_ACTV;                              
                               
                                     modemCurSubTask = SUB_TASK_MODEM_CONNECT_ATCH ;
                        break;
                        
                         
                           case SUB_TASK_MODEM_CONNECT_ATCH:
//
                               //   modemCurSubTask = SUB_TASK_INIT_MODEM_REG_GPRS ; no need
                                   modemCurSubTask = SUB_TASK_INIT_MODEM_SET_CIPMODE;    //cipmode=1 
                        break;
                        
                          case SUB_TASK_INIT_MODEM_REG_GPRS:
                          
                                delay_ms(700);  //5000 Danny
                                modemCurSubTask = SUB_TASK_INIT_MODEM_SET_CIPMODE;    //cipmode=1
                        break; 
                        
                         case SUB_TASK_INIT_MODEM_SET_CIPMODE:
                      
                            modemCurTask = TASK_MODEM_CONNECT;
                            modemCurSubTask = SUB_TASK_MODEM_CONNECT_PDP_DEF;

                        break;

                      

                        case  SUB_TASK_INIT_MODEM_COPS:
                           modemCurSubTask = SUB_TASK_INIT_MODEM_DELAY;

                           heat_time = 60; //delay before creg
                        break;



                        case SUB_TASK_INIT_MODEM_DELAY:
                              //  modemCurSubTask = SUB_TASK_INIT_MODEM_REG;
                              //   modemCurSubTask = SUB_TASK_INIT_MODEM_RSSI;                               
                             //   SendATCmd(AT_E0); //new                             
                                heat_time = 20; //delay before creg
                        break; 
                                                                      
                     
                    }
                break;

                case TASK_MODEM_CONNECT:
                    switch (modemCurSubTask)
                    {
                        case SUB_TASK_MODEM_CONNECT_DELAY:       //??????????????????????????????????????????
                           modemCurSubTask = SUB_TASK_MODEM_CONNECT_SETUP1 ;//SUB_TASK_MODEM_CONNECT_ATCH;
                            break; 
                            
                        case SUB_TASK_MODEM_CONNECT_PDP_DEF:
                                  modemCurSubTask = SUB_TASK_MODEM_CONNECT_SETUP1;//
                        break;

                        case SUB_TASK_MODEM_CONNECT_SETUP1:

                                    modemCurSubTask = SUB_TASK_MODEM_CONNECT_SETUP2;
                        break;

                        case SUB_TASK_MODEM_CONNECT_SETUP2:
                                   modemCurSubTask = SUB_TASK_MODEM_CONNECT_SETUP3;
                        break;

                        case SUB_TASK_MODEM_CONNECT_SETUP3:
                          
                                    modemCurSubTask = SUB_TASK_MODEM_CONNECT_ACTV;
                                //   modemCurSubTask = SUB_TASK_MODEM_CHK_ICCID;  // 
                        break;

//                        case SUB_TASK_MODEM_CHK_ICCID:  
//                                  
//                                   modemCurSubTask = SUB_TASK_MODEM_CONNECT_ACTV;
//                                //   modemCurSubTask = SUB_TASK_MODEM_CONNECT_ACTV;//SUB_TASK_MODEM_CONNECT_PDP_DEF;
//                                //    modemCurTask = TASK_MODEM_CLOSE; 
//                               //   modemCurSubTask = SUB_TASK_MODEM_ENDED ; 
//                        break;


                        case SUB_TASK_MODEM_CONNECT_ACTV:
                              
                                modemCurSubTask = SUB_TASK_MODEM_CONNECT_START_DIAL; 
                           //   modemCurTask = TASK_MODEM_CLOSE; 
                           //   modemCurSubTask = SUB_TASK_MODEM_ENDED ; 
                           //     MODEM_GOT_IP = TRUE ;   //flag shows IP exist
                           
                              

                        break;

                        case SUB_TASK_MODEM_CONNECT_START_DIAL:       
                          
                              modemCurTask = TASK_MODEM_POST;
                        //    modemCurSubTask = waitingTask;    //set to SUB_TASK_MODEM_POST_DATA at  Init_Modem_Vars();
                        //       modemCurSubTask = SUB_TASK_MODEM_POST_DATA;   //search in server  mode 
                              modemCurSubTask = SUB_TASK_MODEM_SEND_GET;       //get connected to sever for good....
                         //     modemCurSubTask = SUB_TASK_MODEM_ASK_LIST_UPDATE; 
                              MODEM_GOT_IP = TRUE ; 
                        break;
                    }
                break;
                case TASK_MODEM_POST:

                    switch (modemCurSubTask)
                    {    
                       case  SUB_TASK_MODEM_ASK_LIST_UPDATE:  
                       
                                modemCurTask = TASK_MODEM_POST;
                                modemCurSubTask = SUB_TASK_MODEM_WAIT_FOR_LIST;
                       break; 
                                                
                         case SUB_TASK_MODEM_WAIT_FOR_LIST:
                                Timer0_Ticks = 7;
                                dataSentOK = TRUE;
                                modemCurTask = TASK_MODEM_CLOSE;
                               modemCurSubTask = SUB_TASK_MODEM_CLOSE_PPP;                            
                              
                          break;

                         case SUB_TASK_MODEM_SEND_GET: 
                         
                                 Timer0_Ticks = 7;                                                     
                         
                                modemCurTask = TASK_MODEM_CLOSE;
                            //  modemCurSubTask = SUB_TASK_MODEM_CLOSE_PPP;                            
                                modemCurSubTask = SUB_TASK_MODEM_ENDED ;   //stay connected to server! 
                                Keep_Alive_timer = KeepAlivePeriod;   //set timer
                              
                         break;  
                         
                         case SUB_TASK_MODEM_POST_DATA:     //success post 

                                Timer0_Ticks = 7;
                                dataSentOK = TRUE;
                                modemCurTask = TASK_MODEM_CLOSE;
                            //    modemCurSubTask = SUB_TASK_MODEM_CLOSE_PPP;                            
                                modemCurSubTask = SUB_TASK_MODEM_ENDED ;   //stay connected to server!!

                        break;
                   
                       default:
                    }
                break;

                case TASK_MODEM_CLOSE:
                    switch (modemCurSubTask)
                    {
                        case  SUB_TASK_MODEM_CLOSE_PPP:
                            //   delay_ms(500);                  //test 9
                                modemCurSubTask = SUB_TASK_MODEM_CLOSE_TCP;
                        break;

                        case SUB_TASK_MODEM_CLOSE_TCP:
                             //   modemCurSubTask = SUB_TASK_MODEM_CLOSE_MDM;
                                modemCurSubTask = SUB_TASK_MODEM_ENDED;    //modem always alive!
                        break;

                        case SUB_TASK_MODEM_CLOSE_MDM:
                               modemCurSubTask = SUB_TASK_MODEM_OFF;
                        break;

                        case SUB_TASK_MODEM_OFF:  
                               modemCurSubTask = SUB_TASK_MODEM_ENDED;  
//                              modemCurTask = TASK_NONE;
//                              modemCurSubTask = TASK_NONE;
                        break;
                    }
                break;
            }
            failCnt = 0;
            return CONTINUE;
        }
 //------------------------------Failed section------------------------------------
        case TASK_FAILED:
        {

        //  SendDebugMsg("TASK failure..\r\n\0");
            failCnt++;    // count num of failures

               // if failed more than 2 times - quit
            if (failCnt >= nMaxFailuresNum)
            {
                switch (modemCurTask)
                {    
                
                   case TASK_MODEM_SMS_HANDLE: 
                   
                      switch (modemCurSubTask)
                      { 
                              case SUB_TASK_MODEM_RECEIVED_SMS: 
                              case SUB_TASK_MODEM_ALERT_SMS:
                                 
                                   modemCurTask = TASK_MODEM_CLOSE;
                                   modemCurSubTask = SUB_TASK_MODEM_ENDED ; 
                                   SendDebugMsg("SMS handling failure - abort it\r\n\0 "); 
                                 
                             break; 
                      }    
                     break;
                      
                    case TASK_MODEM_INIT:  
                        switch (modemCurSubTask)
                        {
                            case SUB_TASK_INIT_MODEM_OK:
                                // if try only once to jig the iggnition pulse - try again, else- switch off.
                             //    SendDebugMsg("SUB_TASK_INIT_MODEM_OK failure..\r\n\0 "); 
//                                if (initCnt < 2)
//                                    modemCurSubTask = SUB_TASK_INIT_MODEM_IGN; //SUB_TASK_INIT_MODEM_ON;
//                                else
                                {
                                  //  if (!bExtReset)
//                                  
//                                    modemCurTask = TASK_MODEM_CLOSE;
//                                    modemCurSubTask = SUB_TASK_MODEM_OFF; 
//                                    
//                                    ErrorType = 6;  
                                   ModemAlive = FALSE;
                                   modemCurTask = TASK_MODEM_CLOSE;
                                   modemCurSubTask = SUB_TASK_MODEM_ENDED ; 
                                   SendDebugMsg("Modem response failure - to BLE..\r\n\0 ");

                                }
                            break;


                            case SUB_TASK_INIT_MODEM_REG:
                                  modemCurTask = TASK_MODEM_CLOSE;
                                   modemCurSubTask = SUB_TASK_MODEM_ENDED ; 
                                   SendDebugMsg("REG failure - to BLE..\r\n\0 ");
                                    
//                                modemCurTask = TASK_MODEM_CLOSE;
//                                modemCurSubTask = SUB_TASK_MODEM_OFF;
//                                 ModemAgain = TRUE;
                                ErrorType = 5;


                          break;

                           case SUB_TASK_MODEM_CONNECT_ATCH:

                                      SendDebugMsg("GPRS failure .Close.\r\n\0");
                                       modemCurTask = TASK_MODEM_CLOSE;              //changed 010716
                                       modemCurSubTask =  SUB_TASK_MODEM_OFF; // SUB_TASK_MODEM_CLOSE_MDM ; //test 270616
                                       nFailureCntr++;
                                  //     ModemRepeatNeeded = TRUE;
                                 //      ModemAgain = TRUE;
                                 //      ErrorType = 9;

                                         modemCurSubTask = SUB_TASK_INIT_MODEM_REG_GPRS ;

                            break;


                          case SUB_TASK_INIT_MODEM_REG_GPRS:
                          
                                modemCurTask = TASK_MODEM_CLOSE;
                                modemCurSubTask = SUB_TASK_MODEM_OFF;

                                 ModemRepeatNeeded = TRUE;
                                 ModemAgain = TRUE;

                                ErrorType = 7;

                          break;

                            case SUB_TASK_INIT_MODEM_GET_COPS:
                                 modemCurTask = TASK_MODEM_CLOSE;
                                 modemCurSubTask = SUB_TASK_MODEM_OFF;
                            break;

                            case SUB_TASK_INIT_MODEM_PARAMS:
                                 modemCurTask = TASK_MODEM_CLOSE;
                                 modemCurSubTask = SUB_TASK_MODEM_ENDED ; 
                                 SendDebugMsg("complete Modem REG - to sleep..\r\n\0 ");
                            break;

                            case SUB_TASK_INIT_MODEM_RSSI: //todo: check rssi and continue only if it over min

                                SendDebugMsg("RSSI level failure- Abort.\r\n\0");                               
                                 
                                    modemCurTask = TASK_MODEM_CLOSE;
                                    modemCurSubTask = SUB_TASK_MODEM_OFF;
                                ModemRepeatNeeded = TRUE;
                                ModemAgain = TRUE;
                                ErrorType = 8;

                            break;

//                            case SUB_TASK_MODEM_CHK_ICCID:
//                                modemCurTask = TASK_MODEM_CONNECT;
//                                modemCurSubTask = SUB_TASK_MODEM_CONNECT_ATCH;
//                            break;
                        }
                    break;

                    case TASK_MODEM_CONNECT:
                        switch (modemCurSubTask)
                        {
//                            case SUB_TASK_MODEM_CONNECT_ATCH:
////                                 if (bExtReset == FALSE)
////                                    modemCurSubTask = SUB_TASK_MODEM_CONNECT_ACTV;  //SUB_TASK_MODEM_CONNECT_PDP_DEF;
////                                else
////                                    modemCurSubTask = SUB_TASK_MODEM_CONNECT_SETUP1;
//
//                                      SendDebugMsg("GPRS failure .Close.\r\n\0");
//                                       modemCurTask = TASK_MODEM_CLOSE;              //changed 010716
//                                       modemCurSubTask =  SUB_TASK_MODEM_OFF; // SUB_TASK_MODEM_CLOSE_MDM ; //test 270616
//                                       nFailureCntr++;
//                                       ModemAgain = TRUE;
//
//
//                            break;

                            case SUB_TASK_MODEM_CONNECT_SETUP1:   //210517
                           //  #ifdef SIM800
                                       SendDebugMsg("GPRS failure .Close.\r\n\0");
                                       modemCurTask = TASK_MODEM_CLOSE;              //changed 010716
                                       modemCurSubTask =  SUB_TASK_MODEM_OFF; // SUB_TASK_MODEM_CLOSE_MDM ; //test 270616
                                       nFailureCntr++;
                                       ModemAgain = TRUE;
                          //   #else
                          //      modemCurSubTask = SUB_TASK_MODEM_CONNECT_SETUP2;
                         //    #endif
                            break;

                            case SUB_TASK_MODEM_CONNECT_SETUP2:
                                modemCurSubTask = SUB_TASK_MODEM_CONNECT_SETUP3;
                            break;

                            case SUB_TASK_MODEM_CONNECT_SETUP3:

                                modemCurSubTask = SUB_TASK_MODEM_CHK_ICCID;
                            break;

                            case SUB_TASK_MODEM_CHK_ICCID:    //?????????????????????????
                                modemCurSubTask = SUB_TASK_MODEM_CONNECT_PDP_DEF;
                            break;

                            case SUB_TASK_MODEM_CONNECT_PDP_DEF:
                                modemCurSubTask = SUB_TASK_MODEM_CONNECT_ACTV;
                            break;

//                            case SUB_TASK_MODEM_CONNECT_IS_ACTV:
//                                modemCurTask = TASK_MODEM_CLOSE;
//                                modemCurSubTask = SUB_TASK_MODEM_CLOSE_MDM;   //SUB_TASK_MODEM_CLOSE_TCP
//                            break;

                            case SUB_TASK_MODEM_CONNECT_ACTV:
                                modemCurTask = TASK_MODEM_CLOSE;
                                modemCurSubTask = SUB_TASK_MODEM_OFF;   //SUB_TASK_MODEM_CLOSE_TCP
                                ErrorType = 4;
                            break; 
                            
                           

                            case SUB_TASK_MODEM_CONNECT_START_DIAL:      //xxx

                                  modemCurTask = TASK_MODEM_CLOSE;

                            //      modemCurSubTask = SUB_TASK_MODEM_CLOSE_MDM ; //test 270216
                                  modemCurSubTask = SUB_TASK_MODEM_OFF;
                                  nFailureCntr++;
                                 SendDebugMsg("Server CONNECT failure..\r\n\0");
                                  ModemAgain = TRUE;
                            break;
                        }
                    break;

                    case TASK_MODEM_POST: 
//                             SendDebugMsg("\r\nmodemCurSubTask = \0");  //?????????????????????????????????????????????
//                             PrintNum((long)modemCurSubTask); 

                        switch (modemCurSubTask)
                        {     
                           
                             
                                case SUB_TASK_MODEM_ASK_LIST_UPDATE: 
                                case SUB_TASK_MODEM_WAIT_FOR_LIST:   
                                
                                    SendDebugMsg("\r\nLIST-Failed to get proper server response.!! \r\n\0");
                                   
                                    Modem_Close_Connection();
                                    delay_ms(1000);
                                    Init_Modem_Vars();
                                   // heat_time = 50;
                               
                            break;  
                            
                           
                             
                            case SUB_TASK_MODEM_POST_DATA:
                            case SUB_TASK_MODEM_SEND_GET:
                      

                                 SendDebugMsg("\r\nFailed to get proper server response.!! \r\n\0");                          
                                  ModemRepeatNeeded = TRUE;         //for new trial of communication
                                                          
                                  Modem_Message_Recieved = FALSE;

                                  modemCurTask = TASK_MODEM_CLOSE;                               
                             //     modemCurSubTask = SUB_TASK_MODEM_CLOSE_PPP; 
                                  modemCurSubTask = SUB_TASK_MODEM_ENDED ; 
                                
                                     Timer0_Ticks = 6;
                            break;

                                                     

                            default:
                        }
                    break;
                    case TASK_MODEM_CLOSE:
                        switch (modemCurSubTask)
                        {
                            case  SUB_TASK_MODEM_CLOSE_PPP:
                                modemCurSubTask = SUB_TASK_MODEM_CLOSE_TCP;     //test jump to MDM
                              //   modemCurSubTask = SUB_TASK_MODEM_CLOSE_MDM;
                              //    modemCurSubTask = SUB_TASK_MODEM_OFF;
                            break;

                            case SUB_TASK_MODEM_CLOSE_TCP:
                            //    modemCurSubTask = SUB_TASK_MODEM_CLOSE_MDM;
                                //   modemCurSubTask = SUB_TASK_MODEM_OFF; 
                                  
                                   modemCurSubTask = SUB_TASK_MODEM_ENDED ; 
                                    MODEM_GOT_IP = FALSE;
                            break;

                            case SUB_TASK_MODEM_CLOSE_MDM:
                                modemCurSubTask = SUB_TASK_MODEM_OFF;

                            break;

                        }

                    break;
                }
                failCnt = 0;

            }
            else   // if (failCnt >= nMaxFailuresNum)
            {
                delay_ms(1000);
                // if fail on send data - change the read mod to 3 (send again the buffer)  
                
                if (modemCurSubTask == SUB_TASK_INIT_MODEM_OK)
                {
                    delay_ms(1000);                                                           
                }
                if (modemCurSubTask == SUB_TASK_INIT_MODEM_RSSI)
                  delay_ms(2000);
                if (modemCurSubTask == SUB_TASK_INIT_MODEM_REG)
                    delay_ms(3000);                    //was 4000 Danny

                 if (modemCurSubTask == SUB_TASK_INIT_MODEM_REG_GPRS)
                    delay_ms(3000);                    //was 4000 Danny

                if (modemCurSubTask == SUB_TASK_MODEM_CONNECT_START_DIAL)        //  (modemCurSubTask == SUB_TASK_MODEM_CONNECT_ACTV) ||
                {
                    delay_ms(3000);
                    nFailureCntr++;
                }

                if (modemCurSubTask == SUB_TASK_MODEM_CONNECT_ACTV)
                    delay_ms(1000);

                 if (modemCurSubTask ==  SUB_TASK_MODEM_POST_DATA)
                 {
                      Modem_Message_Recieved = FALSE;
                      return WAIT;
                 } 
                 if (modemCurSubTask == SUB_TASK_MODEM_ASK_LIST_UPDATE)
                 {
                      Modem_Message_Recieved = FALSE;
                      return WAIT;
                 } 
                if (modemCurSubTask == SUB_TASK_MODEM_WAIT_FOR_LIST)
                 {
                      Modem_Message_Recieved = FALSE;
                      return WAIT;
                 } 
                  if (modemCurSubTask == SUB_TASK_MODEM_SEND_GET)
                 {
                      Modem_Message_Recieved = FALSE;
                      return WAIT;
                 } 
            }
        }
        return CONTINUE;
        break;
    }
}

void  ModemMain()
{
    BYTE res,i,k;
     char plusplus[] = "+++"; 
    char  ATO_[] = "ATO\r\n\0";

         res = GetNextModemTask();
         if (res == WAIT)
         return; 
         
//         if(heat_time > 0)  //for internal delays 280619
//         return;

    switch (modemCurTask)               
    {
        case TASK_MODEM_SMS_HANDLE: 
           switch (modemCurSubTask)
          {
             case SUB_TASK_MODEM_RECEIVED_SMS : 
                  nMaxFailuresNum = 1;
                 
                     
                           RING_PULSE_ACTIVE = FALSE;                                                                                                                                           
                           if( ServerSMSneeded == TRUE)
                           {
                              i =  SendSMS2Server();
                           }  
                           else i = CheckSMSMsg(0); 
                       //   SendDebugMsg("debug--end CheckSMSMsg()\r\n\0"); 
                                 
                           if(i)
                          {
                               ModemResponse = TASK_COMPLETE;                                                                             
                          }   
                             
                          else
                          {
                                SendDebugMsg("SMS read failed..\r\n\0"); 
                               ModemResponse = TASK_FAILED; 
                                DelSMS();        //delete sms from memory  
                           }
                          Modem_Message_Recieved = FALSE;  
                          ENABLE_RX_INT_UART0(); 
                         
                         
              break; 
                  
                    case SUB_TASK_MODEM_ALERT_SMS: 
                           nMaxFailuresNum = 1;
                          if( DIGITAL_IN_ACTIVE == TRUE)
                          {   
                               DIGITAL_IN_ACTIVE = FALSE;  
                              SendDebugMsg("Sensor Active-Alert by SMS..\r\n\0");
                              PCICR=(0<<PCIE3) | (0<<PCIE2) | (0<<PCIE1) | (0<<PCIE0);
                              PCIFR=(0<<PCIF3) | (0<<PCIF2) | (0<<PCIF1) | (0<<PCIF0);
 
                               SendMsgBySMS(51); 
                               PCMSK0 = 0;
//                               delay_ms(1000);
                               Modem_Message_Recieved = FALSE; 
                             
                          }    
                     
                         ModemResponse = TASK_COMPLETE;  
                  break; 
                  
                                    
          }
                      
        break; // case TASK_MODEM_SMS_HANDLE
        
        case TASK_MODEM_INIT:
            switch (modemCurSubTask)
            {
                case SUB_TASK_INIT_MODEM_ON:

                 //    SendDebugMsg("Modem Ignition..\r\n\0");
                 //    SetModemPwrOn();
                     ModemAgain =FALSE;
                break;

                case SUB_TASK_INIT_MODEM_IGN:  
                
                    SendDebugMsg("Modem Ignition..\r\n\0");
                    TimeLeftForWaiting = 0;
                 //    heat_time = 70; 
                     SetTimer1_100ms();
                     IGNIT_IO_ON; //PORTC.2 = 1;   //ignition pulse            
                     ModemIgnit();
                     ModemResponse = TASK_COMPLETE;                                                               
               

                break;

                case SUB_TASK_INIT_MODEM_OK:
                    cEndMark = '\0';
                    nMaxWaitingTime = 20;   // wait max 2.5 sec for answer
                    nMaxFailuresNum = 2;
                    bNeedToWait4Answer = TRUE;                   
                    SendATCmd(AT_E0);   
                 //     ModemInit(); 
                 //   TimeLeftForWaiting = 70;
                

                break;
                
                case SUB_TASK_INIT_MODEM_RSSI:
                    longAnswerExpected = 0;
                    nMaxWaitingTime = 20;
                    nMaxFailuresNum = 40;
                    bNeedToWait4Answer = TRUE; 
                    
                  //   ModemInit();    //
                    //ask modem RSSI with network host
                    SendATCmd(AT_CSQ);
                break; 
                
               
                case SUB_TASK_INIT_MODEM_REG:    
                     nMaxWaitingTime = 20;
                    nMaxFailuresNum = 20;           //was 15 Danny -7 * 3 = 21 Sec max waiting time  
                    bNeedToWait4Answer = TRUE; 
                    SendATCmd(AT_IsModemReg);
                       delay_ms(200);
                   //    ModemResponse = TASK_COMPLETE;
                break; 
                
               
                   case SUB_TASK_INIT_MODEM_PARAMS:
                       longAnswerExpected = 1;
                        nMaxWaitingTime = 30; 
                        
                         ModemInit();    
                         Modem_Close_Connection();
                         ModemResponse = TASK_COMPLETE;
               
                break;   
                
                  case SUB_TASK_INIT_MODEM_GET_COPS:
                    nMaxFailuresNum = 2;
                    SendATCmd(AT_COPS_ASK);                     
                    delay_ms(100);
                break;    
                 
                 case SUB_TASK_MODEM_CHK_ICCID:   
                          SendDebugMsg("CHK_ICCID..\r\n\0"); 
                         nMaxWaitingTime = 30;
                         nMaxFailuresNum = 1;
                         SendATCmd(AT_CCID);    //
                break;
                
                  case SUB_TASK_MODEM_CONNECT_ATCH:
                    nMaxWaitingTime = 30;   // wait max 2.5 sec for answer
                    nMaxFailuresNum = 3;
                    bNeedToWait4Answer = TRUE;
                    SendATCmd(GPRS_ATTACH);    //AT+CGATT=1\r\n\0";
                     ServerResponseTimeOut = 90;

                break;
                
                 case SUB_TASK_INIT_MODEM_REG_GPRS:
                    nMaxFailuresNum = 20;
                   bNeedToWait4Answer = TRUE;          //was 15 Danny -7 * 3 = 21 Sec max waiting time
                     SendATCmd(AT_IsModemRegGPRS);
                    ServerResponseTimeOut = 70;
                break;  
                
                 case SUB_TASK_INIT_MODEM_SET_CIPMODE:
                    longAnswerExpected = FALSE;
                    nMaxWaitingTime = 30;
                    nMaxFailuresNum = 5;
                    bNeedToWait4Answer = TRUE;

                 //  if(MODEM_TYPE == SIM800)
                   {
                       SendATCmd(AT_CIPMODE);  //transparent momde
                       delay_ms(500);  
                       ModemResponse = TASK_COMPLETE;
                   }
                break;  
               
               
                
                  
//                 case SUB_TASK_INIT_MODEM_COPS:
                    //treat leds:
//                    if (!bExtReset)
//                        TurnOnLed(LED_1, SUCCESS);
                    //select the  operator
               //     SendOperatorSelection();     Danny - no need at Creacell
                break;

               
            }
        break;
        case TASK_MODEM_CONNECT:

//         SendDebugMsg("ModemMain-TASK_MODEM_CONNECT\r\n\0");


            switch (modemCurSubTask)
            {


               case SUB_TASK_MODEM_CONNECT_SETUP1:

                    nMaxWaitingTime = 60;   // wait max 5 sec for answer
                    nMaxFailuresNum = 5;
                  
                      SendATCmd(CIICR);   //SIM800
                break;

               case SUB_TASK_MODEM_CONNECT_SETUP2:
               #ifndef SIM800
                    SendATCmd(DEF_QULT_REQ_PROF);   //AT+CGQREQ=1,0,0,0,0,0

                #endif
                break;

               case SUB_TASK_MODEM_CONNECT_SETUP3:
                #ifndef SIM800
                      SendATCmd(DEF_SCKT_CNFG);     //"AT#SCFG=1,1,500,30,150,3
                #endif
                break;  
                
                 case SUB_TASK_MODEM_CONNECT_PDP_DEF:
                         nMaxWaitingTime = 30;
                         nMaxFailuresNum = 1;
                         SendPDPCntDef();
                         delay_ms(1500);
                         ServerResponseTimeOut = 70;
                         

                break;

//                case SUB_TASK_MODEM_CHK_ICCID:   
//                          SendDebugMsg("CHK_ICCID..\r\n\0"); 
//                         nMaxWaitingTime = 30;
//                         nMaxFailuresNum = 1;
//                         SendATCmd(AT_CCID);    //
//                break;

 
                case SUB_TASK_MODEM_CONNECT_ACTV:
                    longAnswerExpected = FALSE;      //150116 test
                    nMaxWaitingTime = 50;  //wait max 10 sec
                    nMaxFailuresNum = 8;    //was 10-Danny

                 #ifndef SIM800
                    if(failCnt == 3)
                    {
                          SendATCmd(DE_ACTIVATE_CNTXT);   // AT#SGACT=1,0
                    }
                 #endif

                  //   delay_ms(1000);
                     SendATCmd(ACTIVATE_CNTXT);
                    delay_ms(2500);                //150116 test
                    ServerResponseTimeOut = 40; 
                     ModemResponse = TASK_COMPLETE; //tttestttttttttttttttttttttttttttttttttttttttttt
                break;

                case SUB_TASK_MODEM_CONNECT_START_DIAL:
                      ServerComOn = FALSE;
                      nMaxWaitingTime = 30;  //120 wait max 10 (20)  sec    dannny
                      nMaxFailuresNum = 1;

                      Timer0_Ticks = 7;
               //        BatLevel_ON();
                       SendStartDial();                                           
                 //   SendStartDial_test();
                      delay_ms(100);      //150116 test
                    //   ServerResponseTimeOut = 30;   //???????????????????????
                      
                break;
            }
        break;
        case TASK_MODEM_POST:


          //  cEndMark = '#';
              cEndMark = '\0';

            nMaxWaitingTime = 260;  // wait max 26 (30) sec fot response
            bPostAnswered = FALSE;

            switch (modemCurSubTask)
            {    
                  case SUB_TASK_MODEM_ASK_LIST_UPDATE:
                    
                      SendDebugMsg("Ask if List.. \r\n\0");
                      bWaitForModemAnswer = TRUE; 
                       Timer0_Ticks = 30; 
                  // if(ListUpdateNeeded == TRUE) 
                      SendPostInfo(3);            //ask server for updated list 
                     
                      delay_ms(1000);
//                       if(ModemResponse == TASK_FAILED)
//                       {
//                                SendDebugMsg("Faild getting server response. \r\n\0");
//                                break;
//                       }
                
                  break;     
                  
                  case SUB_TASK_MODEM_WAIT_FOR_LIST:    
                  
                           SendPostInfo(2);       //ack sending list 
                           k = RxUpdateFile();    //receive file from server
                           if(k)                 //success
                           {     
                                //send ack to server here
                                ModemResponse = TASK_COMPLETE; 
                                  ModemResponse = NO_ANSWER; 
                                  TimeLeftForWaiting = 50;
                           } 
                           else
                           {
                                 ModemResponse = TASK_COMPLETE;  //???????????????????????   
                                 ModemResponse = NO_ANSWER;
                                 TimeLeftForWaiting = 50;
                           }
                          
                  break;  
                  
                   case SUB_TASK_MODEM_SEND_GET:  
                   
                           nMaxFailuresNum = 1;    //test
                           Timer0_Ticks = 12;    //extra time to wait for end of msg -1 tick=70mS                
                           SendPostGET(); 
                            delay_ms(1000);
                           if(ModemResponse == TASK_FAILED)
                           {
                                SendDebugMsg("Faild sending post to server.!\r\n\0");
                                break;
                           }
                           else
                           {      
                                  
                              //    SendDebugMsg("\r\nsearch request has sent..\r\n\0");
                             //   SendDebugMsg("Wait for server response 40 Sec. max..\r\n\0");
                                 ServerResponseTimeOut = 40;    //wait for kando server up to 40 sec.
                                 TimeLeftForWaiting = 41;
                                 ModemResponse = NO_ANSWER;

                            }
                   break;
                  
                  case SUB_TASK_MODEM_POST_DATA:

                      nMaxFailuresNum = 1;    //test 
                      nMaxWaitingTime = 40; 
                     Timer0_Ticks = 12;    //extra time to wait for end of msg -1 tick=70mS                 
                   
//                     SendPostData();
                  
                    if(SearchServerDataBase == TRUE)//ask server to search number in data base 
                    {                                                             
                         SendPostInfo(5);
                                        
                    }  
                    
                  //   ENABLE_RX_INT_UART0(); 
                   //  delay_ms(5000);
                                                  
                   if(ModemResponse == TASK_FAILED)
                   {
                        SendDebugMsg("Faild sending post to server.!\r\n\0");
                        break;
                   }
                   else
                   {      
                          
                      //    SendDebugMsg("\r\nsearch request has sent..\r\n\0");
                     //   SendDebugMsg("Wait for server response 40 Sec. max..\r\n\0");
                         ServerResponseTimeOut = 40;    //wait for kando server up to 40 sec.
                         TimeLeftForWaiting = 41;
                         ModemResponse = NO_ANSWER;

                    }
                    
                    break;
            }
        break; //TASK_MODEM_POST

        case TASK_MODEM_CLOSE:

            nMaxFailuresNum = 2;
            nMaxWaitingTime = 30;  // wait max 4 sec for response
            cEndMark = '\0';

            switch (modemCurSubTask)
            {
                 case  SUB_TASK_MODEM_CLOSE_PPP:

                    bNeedToWait4Answer = TRUE;
                    nMaxWaitingTime = 20;
                    nMaxFailuresNum = 1;
                    SendSModemString(plusplus, 3);
                    delay_ms(1500);            //????
                    TimeLeftForWaiting = 30;
                
                    ModemResponse = TASK_COMPLETE;

                break;

                              
                   case SUB_TASK_MODEM_CLOSE_TCP:
               //    SendDebugMsg("at CLOSE_TCP\r\n\0");
                    nMaxWaitingTime = 30;
                    SendATCmd(AT_TCP_CLS);   //AT+CIPCLOSE=1 close socket - SIM800 
                                         
                     delay_ms(4000);
                     ModemResponse = TASK_COMPLETE;
                break;

                case SUB_TASK_MODEM_CLOSE_MDM:
                    SendDebugMsg("at CLOSE_MDM..\r\n\0");
                //   nMaxFailuresNum = 2;
                   nMaxFailuresNum = 1;
                   nMaxWaitingTime = 25;  // wait max 4 sec for response
                   SendATCmd(MODEM_SHDN); 
                    MODEM_GOT_IP = FALSE;
                   
//                   if(ClockUpdated == FALSE)
//                   {
//                         i =  RTC_Update_by_Modem();
//                         if(i)
//                            SendATCmd(MODEM_SHDN);
//                         else
//                         {
//                          //   SendDebugMsg("MODEM_OFF..\r\n\0");
//
//                          //   SetModemPwrOff();
//                              ModemResponse = TASK_FAILED;    //send it to next task
//                         }
//                 }


                break;

                case SUB_TASK_MODEM_OFF:

                SendDebugMsg("at MODEM_OFF..\r\n\0");
                

                    SendATCmd(MODEM_SHDN);  //HE910  
                    MODEM_GOT_IP = FALSE;
                    delay_ms(2000);               
                                
                 //   if(ModemRepeatNeeded == TRUE)     //repeat
                     ModemRepeatCount++;

                     ConnectedToServer = FALSE;
                     ServerComOn = FALSE;
                     ModemAgain = TRUE;
               
    //---------------------------------------------------------------
                  if(( ModemAgain == TRUE) &&(ModemRepeatCount < 3))
                  {
                         ModemRepeatCount++;
                         ModemAgain = FALSE;
                         ErrorType = 0;
                        
                         SendDebugMsg("Modem re init..\r\n\0");
                         delay_ms(2000);
                  }
                  else  
                  {
                          if(ModemRepeatCount == 3)  //reset counter for next com
                          ModemRepeatCount = 0;
                  }   
                   ModemResponse = TASK_COMPLETE;
  
                 break; 
  //-------------------------------------------------------------------                
                 case  SUB_TASK_MODEM_ENDED: 
                    
//                       ServerResponseTimeOut = 0; 
//                       TimeLeftForWaiting = 0; 
                                                                                                                                     
                      if( ATO_needed == TRUE)   // no redial needed - checked in modem task 
                       {  
                           ATO_needed = FALSE;   
                           
//                           UART0_WriteMsg (ATO_);   //reconnect to server to send info                              
//                           UART0_WriteMsg (ATO_);                          
//                           i =  ChkNodemRespons("CONN","-",20);
                           
                           i = Modem_Server_Reconnect();                             
                           if(!i)
                           {  
                                  SendATCmd(MODEM_SHDN); 
                                  delay_ms(1000);
                                  MODEM_GOT_IP = FALSE;                                                   
                                  #asm("jmp 0");     //reset unit
                           } 
                           else
                           {
                                toDoList = DO_BLE; //back to main and back to BLE
                                ENABLE_PA2_INT();    //RING  ----------
                           }  
                                                                       
                       } 
                       else 
                       if( MODEM_GOT_IP == FALSE)
                       {
                            Init_Modem_Vars(); //go back to start modem
                       }   
                       else
                       {
                             toDoList = DO_BLE; //back to main and back to BLE
                              ENABLE_PA2_INT();    //RING  ----------
                       } 
                                                                                                                                                                
                    
                       LED1_OFF;
                       LED2_OFF;   
                       RingCounter = 0; 
                       rx0_buff_len = 0;                                      
                       #asm("sei")
                    
                      //  SendDebugMsg("MODEM session ended....\r\n\0");
                 break;
            }
        break;
        default:
    }
    timeCnt = 0;


}

//char Pharse_Server_Response(char *str, unsigned int index)
//{
//
////   char p;
//   char *ptr;
//      
//  // p = index; 
//   
//   ptr = strstrf(str, "OK");    //look for OK   -need key?
//   if(ptr != NULL)
//   {
//        SendDebugMsg("Server Response = OK.\r\n\0");  
//        return 1;
//   }
//   else
//   {
//         ptr = strstrf(str, "REJ");
//         if(ptr != NULL)
//         {
//             SendDebugMsg("Server Response = REJECT.\r\n\0");              
//         } 
//        
//   } 
//   return 0;
//      
////  do
////   {
////        while((str[p] != '"') && (str[p] != '}'))
////        p++;
////
////        if(str[p] != '}')              //p point to '"'
////        {
////                p++;                    //skip " - point to a key val
////                chr = str[p];           //keep key char  
////                                           
////                switch (chr)            //check the char
////                {
////    //                case '0':
////    //                break;
////                 }
////        } while((str[p] != '}') && ( p < MAX_RX0_BUF_LEN));  
////     } 
//     
//              
//}

//#define 0x01 ALERT_1 // kando buttle state: 0 - Empty, 1 - Full
//#define 0x20 RESET_BOTTLE_STATE // 0 - set bottle state as empty, 1 - full

//#define 0x40 RELAY1_STATE // PUMP is connected to relay1: 0 - turn pump off, 1 - turn pump on
//#define 0x41 RELAY2_STATE // 0 - relay2 off, 1 - relay2 on
//
////Sensor TH-levels (from device to server - on quary request, or from server to device update values)
//#define 0x60 TEMP_TH // values: <TH MAX>
//#define 0x61 PH_TH   // values: <PH MIN><PH_MAX><PH_BOTTLE_MIN><PH_BOTTLE_MAX>
//#define 0x62 EC_TH   // values: <EC_MIN><EC_MAX><EC_BOTTLE_MIN><EC_BOTTLE_MAX>
//#define 0x63 WATER_LEVEL // values: <WATER_LEVEL_HIGHT>, unit:cm

// *str = {"60":50,"61":[11,400,89,0]}
//210 {"60":400,"61":[0,150,0,150],"62":[1365,4369],"70":1,"41":90}

//210{"40":180,"60":400,"61":[30,100,50,110],"62":[1250,1875],"63":[-1,-1,-1,-1],"64":[-1,-1,-1,-1],"70":1}

//index point to begininh of str ({)
/*
char Pharse_params_struct(char *str, unsigned int index)
{
      char i,chr, cnt, sSDI;
       int val = 0;;
      unsigned char WLcount, index1, index2, index3, index4;
      unsigned int p; 
      int PUMP_MAX_LIMIT[MAX_SEN_NUM];                                               //\"66\":[10000,32767,6000,32767,32767,32767],
   sSDI = 0xFF;
   p = index;

  do
   {
        while((str[p] != '"') && (str[p] != '}'))
        p++;

        if(str[p] != '}')       //p point to '"'
        {
            p++;                    //skip " - point to a key val
            chr = str[p];           //keep the char
            sSDI = 255;

              index1 = index2 = 0xFF;
               WLcount = 0;

            switch (chr)            //check the char
            {
//                case '0':
//                break;

                 case '1':          
                       chr = str[(int)p + 1];  //check second char of key
                       switch (chr)            //check second char
                      {
                          case '0':          //key = 10  unit type

                               SendDebugMsg("Set unit type\r\n\0");
                                        
                              val = 0;
                              p += 4;       //points to value
                              val = pStr2Bin (str, p); 
                              if((val >= 1) && (val < 4))
                              eUnit_Type = val; 
                              else eUnit_Type = 1; // default vakue
                            

                          break;
                      }

                break;  // case '2':

                case '2':          //bottle state
                       chr = str[(int)p + 1];  //check second char of key
                       switch (chr)            //check second char
                      {
                          case '0':          //key = 20

                               SendDebugMsg("Reset Bottle State\r\n\0");
                                        //key = 20
                              val = 0;
                              p += 4;       //points to value
                              val = pStr2Bin (str, p);

                              if(val == 1)
                              {
                              ///
                              }

                          break;
                      }

                break;  // case '2':

                case '4':
                          chr = str[(int)p + 1];  //check second char
                          p += 4;       //points to value -

                       switch (chr)            //check the char
                      {
                           case '0':
                           break;
//                         case '1':               ////key = 41 -PUMP timing
//                                      chr = str[p]; 
//                                      if(chr == '[')   //new units pump mechanism -get 3 values  250318 
//                                      {
//                                              p++;
//                                              cnt = 0;  
//                                                                                                                                             
//                                              do{  
//                                                  
//                                                     val = pStr2Bin (str, p);
//                                                       switch (cnt)
//                                                       {
//                                                              case 0:
//                                                              	if(val > 255)
//										                 		val = 255;    //limit time to 255 sec
//                                                                 #asm("cli")
//                                                                   ePUMP_HEAT_TIME = val ;   //store in eeprom location. temp is first sensor
//                                                                 #asm("sei")
//                                                                     SendDebugMsg("FW Pump timing setting\r\n\0");
//                                                              break;
//
//                                                               case 1:
//                                                                    	if(val > 30)
//											                      	val = 30;    //
//                                                                   #asm("cli")
//                                                                      ePUMP_BACKWARDS_DURATION = val;   //bw timing address 0xF0
//                                                                    #asm("sei") 
//                                                                     SendDebugMsg("BW Pump timing setting\r\n\0");                                               
//                                                              break;
//
//                                                               case 2: 
//                                                                   	if(val > 5)
//											                    	val = 5;    //limit pump atempts quant.
//                                                                    #asm("cli")
//                                                                    ePUMP_ATTEMPS = val;   //pump atempts quant.
//                                                                    #asm("sei")
//                                                              break;
//                                                       } 
//                                                       while((str[p] != ',') && (str[p] != ']'))  //look for next value
//                                                       p++;
//                                                       p++;         //point to first char of next value
//                                                       cnt ++;      //values count
//
//                                                  }while (cnt < 3);
//                                          } 
//                                           else    
//                                          {                                            
//                                                val = pStr2Bin (str, p);
//                                                 SendDebugMsg("Old pump timing setting\r\n\0");   
//                                                if(val > 255)
//												val = 255;    //limit time to 255 sec
//                                               #asm("cli")
//                                                   ePUMP_HEAT_TIME = val ;   //store in eeprom location. temp is first sensor 
//                                                   ePUMP_BACKWARDS_DURATION = 0;     //old dogem - no BW time
//                                                   ePUMP_ATTEMPS = 1;
//                                               #asm("sei")                                      
//                                          } 
//                          break;

                           case '2':       //key = 42
                                      //    p += 4; 
                                          val = pStr2Bin (str, p);
                                         SendDebugMsg("Relay 1 EN/DIS\r\n\0");
                                  #asm("cli")
                                //  eRelay1Enabled = val ;   //store in eeprom location. temp is first sensor
                                  #asm("sei")
                                //  Relay1Enabled = val ;
                             break;

//                         case '3':       //key = 43
//                                   //      p += 4;  
//                                          val = pStr2Bin (str, p);
//                                  #asm("cli")
//                                  eRelay2Enabled = val ;   //store in eeprom location. temp is first sensor
//                                  #asm("sei")
//                                  PumpEnabled = val ;
//                         break;

                       
                      }
                break;    //case 4

                case '6':               //first char of key is 6

                     chr = str[(int)p + 1];  //check second char
                     switch (chr)
                    {
                         case '0':
                               SendDebugMsg("Temperature High Tresh setting\r\n\0");               //temp high TH
                               val = 0;
                               p += 4;       //points to value - max temp
                               val = pStr2Bin (str, p);   //temp high TH

                                 for(i=0; i< NumSensors; i++)
                                  {
                                     if(( SensorType[i] == AT_B) || (SensorType[i] == AT))
                                     {
                                         sSDI = 0;
                                         break;
                                     }
                                      else if  (( SensorType[i] == COMBO4_SDI12) || (SensorType[i] == COMBO_5TE) ||( SensorType[i] == COMBO2_PH_SDI12) ||\
                                     ( SensorType[i] == COMBO4_485)||(SensorType[i] == COMBO_EC_485))
                                     {
                                          sSDI = 1;
                                          break;
                                     }
                                  }

                                 if(i < NumSensors)      //i has index of the sensor in list
                                 {
                                     #asm("cli")
                                     if(sSDI == 0)
                                     {
                                         MAX_LIMIT[i] = val;   //store in eeprom location.
                                         MIN_LIMIT[i] = -32768;;    //negativ
                                         PUMP_MIN_LIMIT[i] = -32768;;

                                     }

                                      else  if(sSDI == 1)       //SDI sensor
                                      {
                                         MAX_LIMIT[(int)i + 1] = val;   //store in proper array location. temp is second sensor
                                         MIN_LIMIT[(int)i + 1] = -32768;;    //negativ
                                         PUMP_MIN_LIMIT[(int)i + 1] = -32768;;
                                      }
                                     #asm("sei")


                                 }
                              break;   //case 0


                          case '1':      //key for  PH_TH   "61":[-32768,32767,-32768,32767]
                        //   SendDebugMsg("PH Tresh setting\r\n\0");
                            for(i=0; i< NumSensors; i++)
                           {
                                 if(( SensorType[i] == COMBO2_PH_SDI12) ||( SensorType[i] == PH)||(SensorType[i] == COMBO_PH_485))
                                 {
                                     sSDI = 0;
                                     break;
                                 }
                                 else if (( SensorType[i] == COMBO4_SDI12) || ( SensorType[i] == COMBO4_485))
                                 {
                                      sSDI = 1;
                                      break;
                                 }
                           }
                           if(i < NumSensors)   //PH sensor found
                           {

                              p += 5;       //points to first value - min ph
                              cnt = 0;
                              val = 0;
                                do{
                                   val = pStr2Bin (str, p);

                                   switch (cnt)
                                  {

                                      case 0:
                                            #asm("cli")
                                           if(sSDI == 0)
                                               MIN_LIMIT[i] = val;  //PH value is first in comb
                                           else if(sSDI == 1)
                                                MIN_LIMIT[(int)i+2] = val;    //PH value is third in combo
                                              SendDebugMsg("PH  Low Tresh setting\r\n\0");
                                            #asm("sei")
                                      break;

                                       case 1:
                                           #asm("cli")
                                             if(sSDI == 0)
                                               MAX_LIMIT[i] = val;  //store in eeprom location.
                                           else if(sSDI == 1)
                                                 MAX_LIMIT[(int)i+2] = val;    //store in eeprom location. temp is first sensor
                                            #asm("sei")
                                              SendDebugMsg("PH  High Tresh setting\r\n\0");
                                      break;

                                       case 2:
                                            #asm("cli")
                                            if(sSDI == 0)
                                               PUMP_MIN_LIMIT[i] = val;  //store in eeprom location.
                                            else if(sSDI == 1)
                                                 PUMP_MIN_LIMIT[(int)i+2] = val;   //store in eeprom location. temp is first sensor
                                             #asm("sei")
                                              SendDebugMsg("PH Pump Low Tresh setting\r\n\0");
                                      break;
                                       case 3:
                                            #asm("cli")
                                             if(sSDI == 0)
                                               PUMP_MAX_LIMIT[i] = val;  //store in eeprom location.
                                           else if(sSDI == 1)
                                                PUMP_MAX_LIMIT[(int)i+2] = val;   //store in eeprom location. temp is first sensor
                                             #asm("sei")
                                             SendDebugMsg("PH Pump Hgh Tresh setting\r\n\0");
                                      break;


                                   }
                                    #asm("sei")
                                    while((str[p] != ',') && (str[p] != ']'))  //look for next value
                                      p++;
                                       p++;    //point to first char of next value
                                       cnt ++;

                               }while (cnt < 4);
                           }
                         break;   //case 1

                         case '2':     //EC_TH    ,"62":[32767,32767]
                           for(i=0; i< NumSensors; i++)
                           {
                                 if(( SensorType[i] == EC_K0) || (SensorType[i] == EC_K)||(SensorType[i] == COMBO_EC_485))
                                 {
                                    sSDI = 0;
                                     break;
                                 }
                                  else if  (( SensorType[i] == COMBO4_SDI12) || ( SensorType[i] == COMBO_5TE) ||\
                                  ( SensorType[i] == COMBO2_EC_SDI12) ||  ( SensorType[i] == COMBO4_485))
                                  {
                                     sSDI = 1;
                                     break;
                                  }
                           }
                            //if i< NumSensors i has index of sensor in list of sensors
                           if(i < NumSensors)   //PH sensor found
                           {
                              p += 5;       //points to first value - max ec
                              cnt = 0;
                              val = 0;

                            do{

                               val = pStr2Bin (str, p);
//
                                  switch (cnt)       //parameter index
                                  {
                                      
                                      case 0:
                                             if(sSDI == 0)
                                           {    
                                                 #asm("cli")
                                                 MAX_LIMIT[i] = val;    //store in eeprom location.
                                                 MIN_LIMIT[i] = -32768;
                                              //   SendDebugMsg("EC High Tresh setting\r\n\0");
                                                 #asm("sei")
                                           }
                                           else if(sSDI == 1)
                                           {     
                                                 #asm("cli")
                                                 MAX_LIMIT[i] = val;     //store in eeprom location. temp is first sensor
                                                 MIN_LIMIT[i] = -32768;;
                                              //    SendDebugMsg("EC High Tresh setting\r\n\0");

                                               #asm("sei")
                                           }
                                            SendDebugMsg("EC High Tresh setting\r\n\0");

                                      break;

                                      case 1:
                                            if(sSDI == 0)
                                           {     
                                                 #asm("cli")
                                                 PUMP_MAX_LIMIT[i] = val;    //store in eeprom location.
                                                 PUMP_MIN_LIMIT[i] = 0x8000;;    //store in eeprom location.
                                                 #asm("sei")
                                           }
                                           else if(sSDI == 1)
                                           {     
                                                 #asm("cli")
                                                 PUMP_MAX_LIMIT[i] = val;      //store in eeprom location. temp is first sensor
                                                 PUMP_MIN_LIMIT[i] = 0x8000;;    //store in eeprom location.
                                                 #asm("sei")
                                              //    PrintNum((long)val);
                                           }
                                              SendDebugMsg("EC Pump High Tresh setting\r\n\0");
                                      break;

                                      default:
                                  }

                              
                               val = 0;
                            while((str[p] != ',') && (str[p] != ']')) // look for next value
                            p++;
                            p++;    //point to first char of next value

                           cnt ++;
                           }while (cnt < 2);
                          }
                         break;   //case 2


                          case '3':      //63 - WATER_LEVEL   "63":[32767,-3268,32767,-32768]

                           for(i=0; i< NumSensors; i++)  //find sensors loc
                           {
                                  if(( SensorType[i] == WLV) ||( SensorType[i] == WLV_U)||( SensorType[i] == WLV_PULSTAR))
                                 {
                                     WLcount++;

                                     if(WLcount == 1)
                                     if(index1 == 0xFF)
                                     index1 = i;           //save index of sensor in list

                                      if(WLcount == 2)
                                      if(index2 == 0xFF)
                                      index2 = i;
                                 }
                           }
                           if(WLcount > 0)   //WL sensor found
                           {

                              p += 5;       //points to first value - min ph
                              cnt = 0;
                              val = 0;

                              do{
                                   val = pStr2Bin (str, p);
                                   switch (cnt)
                                  {
                                      case 0:

                                      //MIN value and MAX value are swaped due to meaurement mehtod in which water level
                                      //measured from top of SHUCHA
                                          //  if(val >= 0)
                                            {
                                                #asm("cli")
                                         //     MIN_LIMIT[index1] = val;  //
                                            MAX_LIMIT[index1] = val;  //store in eeprom location.
                                                #asm("sei")
                                                SendDebugMsg("WL Low vlaue saved\r\n\0");
                                             }
                                      break;

                                       case 1:

                                        //   if(val > -1)
                                           {
                                               #asm("cli")
                                           //       MAX_LIMIT[index1] = val;  //store in eeprom location.
                                                MIN_LIMIT[index1] = val;  //PH value is first in comb
                                                #asm("sei")
                                                SendDebugMsg("WL High value saved\r\n\0");

                                            }
                                      break;

                                        case 2:
                                        //    if(val > -1)
                                            {
                                                #asm("cli")
                                              //     MIN_LIMIT[index2] = val;  //PH value is first in comb
                                              //      MAX_LIMIT[index2] = val;  //PH value is first in comb

                                                     PUMP_MAX_LIMIT[index1] = val;    //06/09/16 overflow
                                                #asm("sei")
                                                 SendDebugMsg("WL OverFlow value saved\r\n\0");
                                             }
                                      break;

                                        case 3:
//                                           // if(val > -1)
//                                            {
//                                                #asm("cli")
//                                              //     MAX_LIMIT[index2] = val;  //PH value is first in comb
//                                                   MIN_LIMIT[index2] = val;  //PH value is first in comb
//                                                #asm("sei")
//                                                 SendDebugMsg("WL 2 High Tresh setting\r\n\0");
//                                             }
                                        break;

                                   }

                                    while((str[p] != ',') && (str[p] != ']'))  //look for next value
                                     p++;
                                     p++;    //point to first char of next value
                                     cnt ++;

                               }while (cnt < 4);
                           }

                         break;
                         //{"41":44,"60":380,"61":[0,100,0,110],"62":[500,1500],"63":[-1,-1,-1,-1],"64":[-100,800,-100,800],"70":1}
                          case '4':      //64 key for ORP   "64":[-32768,32767,-32768,32767]

                            for(i=0; i< NumSensors; i++)
                           {
                               
                                if  (( SensorType[i] == COMBO4_SDI12) ||  ( SensorType[i] == COMBO4_485))
                                 {
                                      sSDI = 1;
                                      break;      //keep i value as index
                                 } 
                                 
                                  else   if(( SensorType[i] == COMBO2_PH_SDI12) ||( SensorType[i] == PH)||(SensorType[objToMsr] == COMBO_PH_485))
                                 {
                                     sSDI = 0;
                                     break;
                                 }
                           }
                           if(i < NumSensors)   //PH sensor found
                           {

                              p += 5;       //points to first value - min ph
                              cnt = 0;
                              val = 0;

                                do{
                                   val = pStr2Bin (str, p);

                                   switch (cnt)
                                  {

                                      case 0:
                                         if(val != -1)
                                         {
                                                #asm("cli")
                                               if(sSDI == 0)
                                                   MIN_LIMIT[(int)i+1] = val;  //ORP value is second in comb
                                               else if(sSDI == 1)
                                                    MIN_LIMIT[(int)i+3] = val;    //ORP value is fourth in combo

                                                #asm("sei")   
                                                SendDebugMsg("ORP min value set.\r\n\0");
                                             //     PrintNum((long)val);
                                          }
                                      break;

                                       case 1:
                                        if(val != -1)
                                         {
                                               #asm("cli")
                                                 if(sSDI == 0)
                                                   MAX_LIMIT[(int)i+1] = val;  //store in eeprom location.
                                               else if(sSDI == 1)
                                                     MAX_LIMIT[(int)i+3] = val;    //store in eeprom location. temp is first sensor
                                                #asm("sei") 
                                                SendDebugMsg("ORP max value set.\r\n\0");
                                              //    PrintNum((long)val);
                                          }
                                       break;

                                        case 2:
                                         if(val != -1)
                                         {
                                               #asm("cli")
                                               if(sSDI == 0)
                                                   PUMP_MIN_LIMIT[(int)i+1] = val;  //ORP value is second in comb
                                               else if(sSDI == 1)
                                                    PUMP_MIN_LIMIT[(int)i+3] = val;    //ORP value is fourth in combo   
                                                  #asm("sei")   
                                                      SendDebugMsg("ORP pump min value set.\r\n\0");
                                                  //      PrintNum((long)val);
                                               
                                          }
                                          break;

                                       case 3:
                                         if(val != -1)
                                         {
                                                #asm("cli")
                                               if(sSDI == 0)
                                                   PUMP_MAX_LIMIT[(int)i+1] = val;  //ORP value is second in comb
                                               else if(sSDI == 1)
                                                    PUMP_MAX_LIMIT[(int)i+3] = val;    //ORP value is fourth in combo

                                                #asm("sei") 
                                                 SendDebugMsg("ORP pump max value set.\r\n\0"); 
                                              //   PrintNum((long)val);
                                          }
                                         break;


                                   }
                                   
                                    while((str[p] != ',') && (str[p] != ']'))  //look for next value
                                     p++;
                                     p++;    //point to first char of next value
                                     cnt++;

                               }while (cnt < 4);

                             } 
                             break;

                      case '5':      //65 - Tensiomters
                           WLcount = 0;
                           for(i=0; i< NumSensors; i++)  //find sensors loc
                           {
                                 if( SensorType[i] == TNS)
                                 {
                                     WLcount++;       //just counter available for use.

                                     if(WLcount == 1)
                                     index1 = i;           //save index of sensor in list

                                      else if(WLcount == 2)
                                      index2 = i;

                                      else if(WLcount == 3)
                                      index3 = i;

                                       else if(WLcount == 4)
                                      index4 = i;
                                 }
                           }
                           if(WLcount > 0)   //TNS sensor found
                           {

                              p += 5;       //points to first value - min ph
                              cnt = 0;
                             // val = -1;

                              do{
                                   val = pStr2Bin (str, p);
                                   switch (cnt)
                                  {
                                      case 0:

                                            if(val > -1)
                                            {
                                                #asm("cli")

                                                MAX_LIMIT[index1] = val;  //store in eeprom location.
                                                #asm("sei")
                                        //        SendDebugMsg("Tens1 Alert Value updated\r\n\0");
                                             }
                                      break;

                                       case 1:
                                           if(val > -1)
                                           {
                                               #asm("cli")
                                                MAX_LIMIT[index2] = val;  //store in eeprom location.

                                                #asm("sei")
                                          //      SendDebugMsg("Tens2 Alert Value updated\r\n\0");

                                            }
                                      break;

                                        case 2:
                                            if(val > -1)
                                            {
                                                #asm("cli")

                                                MAX_LIMIT[index3] = val;  //PH value is first in comb
                                                #asm("sei")
                                          //       SendDebugMsg("Tens3 Alert Value updated\n\0");
                                             }
                                      break;

                                        case 3:
                                            if(val > -1)
                                            {
                                                #asm("cli")

                                                MAX_LIMIT[index4] = val;  //PH value is first in comb
                                                #asm("sei")
                                          //       SendDebugMsg("Tens4 Alert Value updated\n\0");
                                             }
                                           break;  
                                   }

                                    while((str[p] != ',') && (str[p] != ']'))  //look for next value
                                     p++;
                                     p++;    //point to first char of next value
                                     cnt++;

                               }while (cnt < WLcount);
                        }
                          break;
                         //==============================================================
//                           case '6':      //key for COD x 3   "66":[13,32767,32767,32767,50,60]
//                              SendDebugMsg("COD Tresh setting\r\n\0");
//                            for(i=0; i< NumSensors; i++)
//                           {
//                                 if(( SensorType[i] == COMBO_COD_CARBO)||(SensorType[i] == COMBO_COD_SPECTRO)||(SensorType[i] == COMBO_COD_ISCAN))
//                                 {                                    
//                                     break;     // i point to COMBO_COD 
//                                     
//                                 }
//                               
//                           } 
//                           if((SensorType[i] == COMBO_COD_SPECTRO)||( SensorType[i] == COMBO_COD_CARBO))
//                             sSDI = 0;
//                           else  if( SensorType[i] == COMBO_COD_ISCAN)
//                             sSDI = 1; 
//                           else  sSDI = 255;
//                           
//                           if(sSDI < 255)   //COD sensor found
//                           {
//                              p += 5;       //points to first value - min ph
//                              cnt = 0;
//                              val = 0;
//                              do{
//                                   val = pStr2Bin (str, p);
//
//                                   switch (cnt)
//                                  {
//                                      case 0:
//                                            #asm("cli")                                         
//                                                MAX_LIMIT[i] = val;  //cod value is first in comb0 
//                                             //   SendDebugMsg("COD High Tresh setting\r\n\0");
//                                             //   PrintNum((long)val);                                             
//                                            #asm("sei")
//                                      break;
//
//                                       case 1:
//                                            #asm("cli")                                        
//                                                 PUMP_MAX_LIMIT[i] = val;    //cod pump limit
//                                            #asm("sei")
//                                           //  SendDebugMsg("COD PUMP High Tresh setting\r\n\0"); 
//                                            //  PrintNum((long)val);
//                                      break;
//
//                                       case 2: 
//                                          
//                                             #asm("cli") 
//                                               if( sSDI == 0)  //                                          
//                                                MAX_LIMIT[(int)i+1] = val;   //bod max 
//                                               
//                                             #asm("sei")
//                                          
//                                      break;
//                                       case 3:
//                                              
//                                            #asm("cli") 
//                                                if( sSDI == 0)  //                                          
//                                                PUMP_MAX_LIMIT[(int)i+1] = val;   //bod pump max
//                                            #asm("sei")
//                                          
//                                      break; 
//                                       case 4:
//                                            #asm("cli") 
//                                              if( sSDI == 0)         //No ISCAN
//                                                 MAX_LIMIT[(int)i+2] = val;   ////TSS max    
//                                              else if( sSDI == 1)
//                                                 MAX_LIMIT[(int)i+1] = val;   //TSS iscan second snsor    
//                                            #asm("sei")
//                                         
//                                      break; 
//                                       case 5:
//                                            #asm("cli") 
//                                               if( sSDI == 0)
//                                                  PUMP_MAX_LIMIT[(int)i+2] = val;   ////TSS max    
//                                              else if( sSDI == 1)
//                                                  PUMP_MAX_LIMIT[(int)i+1] = val;   ////TSS iscan second snsor                                          
//                                              
//                                             #asm("sei")
//                                          
//                                      break;
//                                   }
//                                    #asm("sei")
//                                    while((str[p] != ',') && (str[p] != ']'))  //look for next value
//                                      p++; 
//                                      
//                                      p++;    //point to first char of next value
//                                      cnt++;
//
//                              }while (cnt < 6);
//                           }
//                           break;  //case 66 - COD sensor 
                           
//                           case '7':      //case 67 - COD clean time
//                                   p += 4;   
//                                   val = pStr2Bin (str, p);
//                                  #asm("cli")
//                                  eCOD_CLEAN_DURATION = val;    //store in eeprom location.
//                                  #asm("sei")
//                                  SendDebugMsg("COD clean time = \0");
//                                  PrintNum((long)val);
//                           break;
                           
                           case '8':       //H2S
                                             
                                   for(i=0; i< NumSensors; i++)
                                   {
                                         if( SensorType[i] == H2S)                                                                               
                                             break;       //i as sensor index                                                                            
                                   } 
                                                                     
                                   if(i < NumSensors)   //H2S sensor found
                                   {
                                         //    SendDebugMsg("H2S Tresh setting\r\n\0");
                                              p += 5;       //points to first value - max ec
                                              cnt = 0;
                                            
                                        do{

                                                  val = pStr2Bin (str, p);       
                                                  switch (cnt)       //parameter index
                                                  {
                                                      
                                                      case 0:                                                 
                                                                 #asm("cli")
                                                                 MAX_LIMIT[i] = val;    //store in eeprom location.
                                                                 #asm("sei")                                                                                         
                                                                 SendDebugMsg("H2S High Tresh setting\r\n\0");

                                                      break;

                                                      case 1:
                                                         
                                                                 #asm("cli")
                                                                 PUMP_MAX_LIMIT[i] = val;    //store in eeprom location.                                                
                                                                 #asm("sei")                                                                                                    
                                                                 SendDebugMsg("H2S Pump High Tresh setting\r\n\0");
                                                      break;                                              
                                                  }
                                   
                                                       val = 0;
                                                    while((str[p] != ',') && (str[p] != ']')) // look for next value
                                                    p++;
                                                    p++;    //point to first char of next value

                                                   cnt++;
                                       }while (cnt < 2);
                                  }
                           break; 
                           
                           case '9':

                           break;                     
                    }      
                     

                 break;  //case 6

                case '7':

                       chr = str[(int)p + 1];  //check second char of key
                       switch (chr)            //check second char
                      {
                          case '0':          //key = 70

                              val = 0;
                              p += 4;       //points to value
                              val = pStr2Bin (str, p);
                              if(val == 1)
                              {
                               //      SendDebugMsg("Back To Normal Alert ENABLED\r\n\0");
                              }
                               else
                              {
                                    
                              }
                          break;

                            case '1':          //key = 71  measure interval multiplier    "60": -1

                              val = 0;
                              p += 4;       //points to value
                              val = pStr2Bin (str, p);
                        //   if(((val > 0) && (val < 5)) || (val == 6) || (val == 12) || (val == 24))
                              if((((val % 5) == 0) &&((60 % val) == 0)) ||(val == 120))
                              {
                                        cpue2_interval_1 =(char) (val / 5);
                                        SendDebugMsg("\r\nInterval set - \0");
                                      
                              }
                              else  SendDebugMsg("\r\nIlligal Interval value - \0");
                                PrintNum((long)val);
                          break;

                           case '2':      //case 72  COMMUNICATION params

                                SendDebugMsg("Communication params setting\r\n\0");


                                  p += 5;       //points to first value - max ec
                                  cnt = 0;
                                  val = 0;
                               do{

                                 val = pStr2Bin (str, p);
                                 switch (cnt)       //parameter index
                                {
                                      #asm("cli")
                                      case 0:
                                          eStartConnectionH = val;
                                      break;

                                      case 1:
                                          eConnectionInDay = val;
                                      break;

                                       case 2:
                                          eConnectIntervalH = val;
                                       break;
                                  }

                                #asm("sei")
                               val = 0;
                               while((str[p] != ',') && (str[p] != ']'))  //look for next value
                                p++;

                                p++;    //point to first char of next value
                               cnt++;
                           }while (cnt < 3);
                         break;   //case 72 
                         
                         case '3':   //unit type setting
                            
                              p += 4;       //points to value
                              val = pStr2Bin (str, p);
                              if((val > 0) && (val < 4))
                              {
                                        eUnit_Type =(char) val;
                                        SendDebugMsg("Unit type set..\r\n\0");
                              }
                              else  SendDebugMsg("Illigal unit type value..\r\n\0");
                         break;  
                         
                          case '4':          //key = 74  measure interval multiplier
                              
                              p += 4;       //points to value
                              val = pStr2Bin (str, p);
                             if((val == -1) || ((val >= 0) && (val <= 20)))
                              {
                                     //   eHandleExceptionCode =(char) val ;                                         
                                        SendDebugMsg("Exception handling code set..\r\n\0");
                              }
                              else  SendDebugMsg("Illigal Exception handling code value..\r\n\0");
                              PrintNum((long)val);
                          break; 
//                          
//                           case '5':     //TEMP_HUMIDITY temp 2 tresholds
//                            for(i=0; i< NumSensors; i++)
//                           {
//                                 if( SensorType[i] == TEMP_HUMIDITY)
//                                 {
//                                    sSDI = 0;
//                                     break;
//                                 }
//                                
//                           }
                            //if i< NumSensors i has index of sensor in list of sensors
                           if(i < NumSensors)   //PH sensor found
                           {
                              p += 5;       //points to first value - max ec
                              cnt = 0;
                              val = 0;

                             do
                             {

                               val = pStr2Bin (str, p);
//
                                  switch (cnt)       //parameter index
                                  {
                                      
                                      case 0:
                                             if(sSDI == 0)
                                           {    
                                                 #asm("cli")
                                                 MAX_LIMIT[i] = val;    //store in eeprom location.
                                                 MIN_LIMIT[i] = -32768;
                                              //   SendDebugMsg("EC High Tresh setting\r\n\0");
                                                 #asm("sei")
                                           }
                                         
                                            SendDebugMsg("Temperature High Tresh setting\r\n\0");

                                      break;

                                      case 1:
                                            if(sSDI == 0)
                                           {     
                                                 #asm("cli")
                                                 PUMP_MAX_LIMIT[i] = val;    //store in eeprom location.
                                                 PUMP_MIN_LIMIT[i] = 0x8000;;    //store in eeprom location.
                                                 #asm("sei")
                                           }
                                           else if(sSDI == 1)
                                           {     
                                                 #asm("cli")
                                                 PUMP_MAX_LIMIT[i] = val;      //store in eeprom location. temp is first sensor
                                                 PUMP_MIN_LIMIT[i] = 0x8000;;    //store in eeprom location.
                                                 #asm("sei")
                                              //    PrintNum((long)val);
                                           }
                                              SendDebugMsg("EC Pump High Tresh setting\r\n\0");
                                      break;

                                      default:
                                  }

                              
                               val = 0;
                            while((str[p] != ',') && (str[p] != ']')) // look for next value
                            p++;
                            p++;    //point to first char of next value

                             cnt ++;
                             }while (cnt < 2);
                          }
                          break; 
                          
//                          case '6':    //76 Athentication key string
//                                   p += 5;       //points to string  key string
//                                   for(i = 0; i < 64; i++)
//                                   {      
//                                      eAuth_Key[i] = str[p++];  //save key into eeprom                                          
//                                   }                             
//                                 //  DISABLE_RX_INT_UART2();     //dont let it interfer
//                                 //  Timer0_Ticks = 7;
//                                   SendDebugMsg("Athentication key saved..\r\n\0");
//                          break;
//                          
//                          case '7':       //77 Athentication Secret string
//                                   p += 5;       //points to string  key string
//                                   for(i = 0; i < 64; i++)
//                                   {      
//                                      eAuth_Secret[i] = str[p++];  //save key into eeprom                                          
//                                   }                             
//                                 //  DISABLE_RX_INT_UART2();     //dont let it interfer
//                                 //  Timer0_Ticks = 7;
//                                   SendDebugMsg("Athentication Secret saved..\r\n\0");
//                          break;
                       }
                break;

                case '8':        //reset unit
                       chr = str[(int)p + 1]; 
                       switch (chr)            //check second char
                      {
                          case '0':          //key = 80

                              val = 0;
                              p += 4;       //points to value
                              val = pStr2Bin (str, p);
                              if(val == 1)
                              {

                                  //    eRESTORE_DATA_POINTERS = RELEASE_POINTERS;   //dont restore pointers from eeprom
                                 
                                     //   ResetPumpFlags();  //at Measure.c
                                            IsAlertActivated = FALSE;      //updated 320815 for Tzaci request
                                         
//                                             FlagsStatus =  eFLAGS_STATUS;
//                                             SetStatusReg(IS_ALERT_NEEDED , 0);
//                                             eFLAGS_STATUS = FlagsStatus;

                                      SeverResetCommand = TRUE;
                               //       SendDebugMsg("RESETing unit by server..\r\n\0");
                              }

                          break; 
                          

   //-----------                     -----update FW----------------------- 
   //200{"90":"18/04/24, 07:37:01:+12","81":"1ba90843-acc8-4201-bf20-53c797c7bdc5"}
//                            case '1':    //81
//                                    
//                                   p += 5;       //points to string   66db8ceb-fcf7-4fba-a95e-4cb8dace32cf
//                                   for(i = 0; i < 36; i++)
//                                   {         //get uuid
//                                      sUUID[i] = str[p++];
//                                      eUUID[i] = sUUID[i];       //into eeprom as well for further use
//                                   }
//                                   UpdateFileOK = FALSE;           //true if file received ok
//                                 //  UpdateSession = FALSE;         //set in RXint
//                                   FirmwareUpdateTime = TRUE;
//                                   notification_index = 0;
//                                   DISABLE_RX_INT_UART2();     //dont let it interfer
//
//                                   Timer0_Ticks = 7;
//                                   SendDebugMsg("FOTA request..\r\n\0");
//                            break;
                          //--------------------------------------------------
                       }
                break;

//                case '9':     //not here - special func
//                          chr = str[(int)p + 1];  //check second char of key
//                       switch (chr)
//                      {
//                          case '0':           //"90": [16/11/26,13:52:23:+03]
//                                p += 6;
//                                RTC_Update_by_Server( str, p);
//
//                          break;
//                       }
//                break;
              default:
            }
         }
   }   while((str[p] != '}') && ( p < MAX_RX0_BUF_LEN));     //while not end of string   MAX_RX0_BUF_LEN)

//if(FirmwareUpdateTime == TRUE)  //different treatment
//   return 2;                    //handle firmware update
   return 1;
}
*/

 char RTC_Update_by_Modem(void)
 {
   char clkBuf[6];
   char clkBuf1[6];
   int tmp;
   char i, j;
 // bit ModemReadOK = FALSE;

       i = 0;
       j = 0;

            RxUart0Buf[2] = '\0';
            ENABLE_RX_INT_UART0();
             delay_ms(500);

            SendATCmd(AT_CCLK);       //get +CCLK: "05/11/21,01:47:44+00"  format from modem
            delay_ms(600);            //    +CCLK: "19/06/26,10:47:36+12"
            DISABLE_RX_INT_UART0();       //keep data  
          
            
            while((RxUart0Buf[++i] != '+') && (i < 12)) ;
            if((i < 12) && (RxUart0Buf[(int)i + 1] == 'C'))    //we have \r\n\0+CCLK as response
          //   if((RxUart0Buf[2] == '+') && (RxUart0Buf[3] == 'C'))   //we have \r\n\0+CCLK as response
             {

                     SendDebugMsg("Read Modem clock OK.. \r\n\0");   //+CCLK: "19/07/24,10:12:12+12"             

                    clkBuf[0]= ((RxUart0Buf[(int)i+8]-0x30)*10)+(RxUart0Buf[(int)i+9] - 0x30);    //year
//                     SendDebugMsg("year result: \0");
//                     PrintNum((long)clkBuf[0]);  
 
                     clkBuf[1]= ((RxUart0Buf[(int)i+11]-0x30)*10)+(RxUart0Buf[(int)i+12] - 0x30);  //month
                  //   PrintNum((long)clkBuf[1]);
                      clkBuf[2]= ((RxUart0Buf[(int)i+14]-0x30)*10)+(RxUart0Buf[(int)i+15 ]- 0x30); //day
                  //    PrintNum((long)clkBuf[2]);
                       clkBuf[4]= ((RxUart0Buf[(int)i+17]-0x30)*10)+(RxUart0Buf[(int)i+18] - 0x30);  //hour
                   //    PrintNum((long)clkBuf[4]);
                        clkBuf[5]= ((RxUart0Buf[(int)i+20]-0x30)*10)+(RxUart0Buf[(int)i+21 ]- 0x30);  //minute
                   //     PrintNum((long)clkBuf[5]);

                          TimeZone =  ((RxUart0Buf[(int)i+26]-0x30)*10) + (RxUart0Buf[(int)i+27 ]- 0x30);

                          if(RxUart0Buf[(int)i+25] == '-')
                          TimeZone *= -1;
                          if(eTimeZone != TimeZone)
                          eTimeZone = TimeZone;

                      //    i = 0;
                
                        
                  if(( clkBuf[0]>=18) && (clkBuf[0]<23))   //year in range
                  {                       
                         rtc_get_timeAll(clkBuf1);

                       tmp =   clkBuf1[5]- clkBuf[5];   //if abs(tmp) <= 3 - OK
                       tmp *= tmp;          // make it positive

                       if((clkBuf1[0] == clkBuf[0]) &&(clkBuf1[1] == clkBuf[1])&&\
                        (clkBuf1[2] == clkBuf[2]) && (clkBuf1[4] == clkBuf[4])&&\
                        (tmp < 10))
                        {
                            SendDebugMsg("*** Unit time is OK ***\r\n\0");
                        }
                        else
                        {
                            rtc_set_timeAll(clkBuf);                            
                            SendDebugMsg("*** Unit time initialized with network time ***\r\n\0");
                        }

                         j++;
                 //       CurrentDay = clkBuf[2];    //save day for inspection later
                   }
                   else  //if year bad
                   {
                        SendDebugMsg("Fail: YEAR value not valid..\r\n\0");
                      //  #asm("wdr") 
                         ENABLE_RX_INT_UART0();
                         return 0;
                   }

               }
               else
               {
                       SendDebugMsg("Check Clock: No answer..\r\n\0");
                       ENABLE_RX_INT_UART0();
                       return 0;
               }
                 ENABLE_RX_INT_UART0();
             return 1;

  }
//200{"16/08/16,14:01:14+12"}         //27

//200{"90": "16/08/16, 12:12:53:+00"}     //kanso format
//200{"90": "16/09/12, 10:13:25:+12"}
  //update clock by server 100716
char RTC_Update_by_Server( char *str, int ptr)
 {
   char clkBuf[6];
 //  char clkBuf_1[6];
   int tmp,i, p;

      //   SendDebugMsg("\r\nRTC_Update_by_Server().. \r\n\0");
       p = ptr;
       p = 0;
       i = 0;
                  do{
                       if (str[p] == '"')  //look for three "
                       i++;
                       p++;
                     }  while((i < 3) &&( p < 13));

                   if(p == 13)
                   {
                       SendDebugMsg("\r\nFailed: CLOCK string not valid.! \r\n\0");
                        return 0;
                   }

                   tmp = 0;
                   i = p ;
                   while ((str[i] != '"') && (tmp < 23))  //look for 4th "
                   {
                      i++;
                      tmp++;
                   }

                    if(tmp == 23)     //string not omplete
                    {
                             SendDebugMsg("\r\nCLOCK string not complete..ignored! \r\n\0");
                              return 0;
                    }

                        //collect date/time values
                         clkBuf[0]= ((str[p]-0x30) * 10) + (str[p+1]-0x30);    //year
                     
                        //PrintNum((long)clkBuf[0]);
                         p += 3;

                         clkBuf[1]= ((str[p]-0x30) * 10) + (str[p+1]-0x30);  //month
//                       PrintNum((long)clkBuf[1]);
                         p += 3;
                         clkBuf[2]= ((str[p]-0x30) * 10) + (str[p+1]-0x30);; //day
//                       PrintNum((long)clkBuf[2]);
                         p += 4;
                         clkBuf[4]= ((str[p]-0x30) * 10) + (str[p+1]-0x30);  //hour

//                       PrintNum((long)clkBuf[4]);
                         p += 3;
                         clkBuf[5]= ((str[p]-0x30) * 10) + (str[p+1]-0x30);  //minute
//                        PrintNum((long)clkBuf[5]);
                          p += 7;
                          TimeZone =  ((str[p]-0x30) * 10) + (str[p+1]-0x30);   //time zone
                          p--;
                          if(str[p] == '-')
                          TimeZone *= -1;
                          if(eTimeZone != TimeZone)
                          eTimeZone = TimeZone;
                              rtc_set_timeAll(clkBuf);

                             SendDebugMsg("\r\n** Unit clock initialized by Server **\r\n\0");

                        //     SetAlarmTiming(2);     //set alarm in 2 minutes as WD in case modem failure
                           //  EIFR |= (1<<INTF2) ;
                         //    ENABLE_CLOCK_INT(); // enable external WD on interrupt2 //Danny
//                         }

                        for(i=0; i< 7; i++)
                        {
                            if(str[++p] == '}')     //end - no params update in jason string
                            break;
                        }
                        if(i < 7)
                        return 2;   //no update paams
                        return 1;  //need to read update params

  }


//{"60":400,"61":[60,92,50,98],"62":[1125,1250],"70":1}
//210 {"60":400,"61":[0,150,0,150],"62":[1365,4369],"70":1,"41":90}

//char Pharse_SDIparams_struct(char *str, char index)
//{
//      char i,p,chr, cnt;
//      unsigned int val = 0;;
//
//
//   p = index;
//  do
//   {
//        while((str[p] != '"') && (str[p] != '}'))
//        p++;
//
//        if(str[p] != '}')       //p point to '"'
//        {
//            p++;                    //skip " - point to a key val
//            chr = str[p];           //keep the char
//
//            switch (chr)            //check the char
//            {
//                case '0':
//                break;
//
//                case '2':
//                       chr = str[p + 1];  //check second char of key
//                       switch (chr)            //check second char
//                      {
//                          case '0':          //key = 20
//                           SendDebugMsg("Reset Bottle State\r\n\0");
//                              val = 0;
//                              p += 4;       //points to value
//                              val = pStr2Bin (str, p);
//
//                              if(val == 1)
//                               ResetPumpFlags();
//
//                          break;
//                      }
//
//                break;
//
//                case '4':
//                          chr = str[p + 1];  //check second char
//                           val = 0;
//                            p += 4;       //points to value - relay duration
//                           val = pStr2Bin (str, p);
//
//                       switch (chr)            //check the char
//                      {
//                         case '0':
//                         break;
//
//                         case '1':                //key=41
//                               SendDebugMsg("Relay 2 timing setting\r\n\0");
//
//                             #asm("cli")
//                             ePUMP_HEAT_TIME = val ;   //store in eeprom location. temp is first sensor
//                             #asm("sei")
//
//                         break;
//
//                         case 2:
//                                 SendDebugMsg("Relay 1 EN/DIS\r\n\0");
//                                  #asm("cli")
//                                  eRelay1Enabled = val ;   //store in eeprom location. temp is first sensor
//                                  #asm("sei")
//                                  Relay1Enabled = val;
//                         break;
//
//                         case 3:
//                                  SendDebugMsg("Relay 2 EN/DIS\r\n\0");
//                                  #asm("cli")
//                                  eRelay2Enabled = val ;   //store in eeprom location. temp is first sensor
//                                  #asm("sei")
//                                  Relay2Enabled = val;
//                         break;
//                       }
//                break;
//
//                case '6':               //first char of key is 6
//
//                     chr = str[p + 1];  //check second char
//                     switch (chr)
//                    {
//                         case '0':          //key for TEMP_TH
//                               SendDebugMsg("Temperature High Tresh setting\r\n\0");
////                              _putchar1 ('0');
////                               _putchar1 (' ');
//                              val = 0;
//                              p += 4;       //points to value - max temp
//                              val = pStr2Bin (str, p);
//
//                                 #asm("cli")           //val is holding binari value
//                                  MAX_LIMIT[1] = val;   //SDI combo. temp is second sensor
//                                  #asm("sei")
////                              }
//                          break;
//
//                         // {"60":500,"61":[0,150,0,150],"62":[750,875],"70":0,"41":90}
//
//                          case '1':   //   key for  PH_TH
//
//                              p += 5;       //points to first value - min ph
//                              cnt = 0;
//                              val = 0;
//                         do{
//
//                               val = pStr2Bin (str, p);
//                               switch (cnt)
//                              {
//                                  #asm("cli")
//                                  case 0:
//                                      MIN_LIMIT[2] = val;
////                                       SendDebugMsg("MIN_LIMIT[2]\r\n\0");
////                                       PrintNum(iLastMsr[val]);
//                                  break;
//                                   case 1:
//                                      MAX_LIMIT[2] = val;
////                                       SendDebugMsg("MAX_LIMIT[2]\r\n\0");
////                                        PrintNum(iLastMsr[val]);
//                                  break;
//                                   case 2:
//                                      PUMP_MIN_LIMIT[2] = val;
////                                       SendDebugMsg("PUMP_MIN_LIMIT[2]\r\n\0");
////                                        PrintNum(iLastMsr[val]);
//                                  break;
//                                   case 3:
//                                      PUMP_MAX_LIMIT[2] = val;
////                                       SendDebugMsg("PUMP_MAX_LIMIT[2]\r\n\0");
////                                        PrintNum(iLastMsr[val]);
//                                  break;
//
//                                  default:
//                              }
//                                #asm("sei")
//                                val = 0;
//                                while((str[p] != ',') && (str[p] != ']'))  //look for next value
//                                p++;
//                                p++;    //point to first char of next value
//                               cnt ++;
//
//                           }while (cnt < 4);
//                         break;
//
//                         case '2':     //EC_TH
//
//                          SendDebugMsg("EC High Tresh setting\r\n\0");
//                              p += 5;       //points to first value - max ec
//                              cnt = 0;
//                              val = 0;
//                         do{
//
//                                 val = pStr2Bin (str, p);
//                                 switch (cnt)       //parameter index
//                                {
//                                      #asm("cli")
//                                      case 0:
//                                          MAX_LIMIT[0] = val;
//
//                                      break;
//
//                                      case 1:
//                                          PUMP_MAX_LIMIT[0] = val;
//
//                                      break;
//
//                                      default:
//                                  }
////                              }
//                                #asm("sei")
//                               val = 0;
//                            while((str[p] != ',') && (str[p] != ']'))  //look for next value
//                            p++;
//                            p++;    //point to first char of next value
//
//                           cnt ++;
//                           }while (cnt < 2);
//                         break;   //case 2
//                   //???     break;
//
//                         case '3':      //WATER_LEVEL
//                         break;
//                    }
//
//                break;  //case 6
//
//                 case '7':
//
//                       chr = str[p + 1];  //check second char of key
//                       switch (chr)            //check second char
//                      {
//
//                          case '0':          //key = 70
//                           SendDebugMsg("Get BackToNormal Alert param\r\n\0");
//                              val = 0;
//                              p += 4;       //points to value
//                              val = pStr2Bin (str, p);
//                              if(val == 1)
//                              {
//                                   eBackToNormalAlertEnabled = 1 ;     //stasus byte  ???
//                                    BackToNormalAlertEnabled = TRUE ;
//                              }
//                              else
//                              {
//                                      eBackToNormalAlertEnabled = 0;     //stasus byte  ???
//                                      BackToNormalAlertEnabled = FALSE;
//                              }
//
//                            break;
//
//                            case '2':     //COMMUNICATION params
//
//                              SendDebugMsg("Communication params setting\r\n\0");
//                                  p += 5;       //points to first value - max ec
//                                  cnt = 0;
//                                  val = 0;
//                               do{
//
//                                 val = pStr2Bin (str, p);
//                                 switch (cnt)       //parameter index
//                                {
//                                      #asm("cli")
//                                      case 0:
//                                          eStartConnectionH = val;
//                                      break;
//
//                                      case 1:
//                                          eConnectionInDay = val;
//                                      break;
//
//                                       case 2:
//                                          eConnectIntervalH = val;
//                                       break;
//
//
//                                  }
//
//                                #asm("sei")
//                               val = 0;
//                               while((str[p] != ',') && (str[p] != ']'))  //look for next value
//                                p++;
//
//                                p++;    //point to first char of next value
//                               cnt ++;
//                           }while (cnt < 3);
//                         break;   //case 2
//
//                        }
//                 break;
//
//              default:
//            }
//         }
//   }   while(str[p] != '}');     //while not end of string
//
//   return 1;
//}
 //make params as binary
 int pStr2Bin (char *str, char p)
{
        unsigned int val = 0;
        char MINUS = 0;

          while((str[p] != ',') &&  (str[p] != ']') && (str[p] != '}')) // , or ] or } are end of value','
          {
                if(str[p] == '-')
                {
                   MINUS = 1;
                }
                else
                {
                    val *= 10;
                    val += (str[p] - 0x30);
                }
                  p++;
          }
          if(MINUS == 1)
          return (val * -1);
          return val;

}
////tttttessssttttttt only for battery
//#ifndef MODEM_EXT_PWR
//void  TestPower(char dir)
//{
//      if(dir == 1)
//      {
//          DDRD.4 = 1;
//          PORTD.4 = 1;
//      }
//      else
//      {
//            PORTD.4 = 0;
//      }
//}
//#endif
//=======================================================================================

 void CloseSuccessfulCom(void)
 {
          

               ModemRepeatCount = 0;
               ModemAgainCount = 0;
               ModemRepeatNeeded = FALSE;

               ComFailureCounter = 0;

              bPostAnswered = TRUE;
               bConnectOK = TRUE;

              if(Found200 == FALSE)
              SendDebugMsg("\r\nDebug-Found200 = FALSE.. \r\n\0");

               ConnectedToServer = FALSE;
               ErrorType = 0;
               Found200 = FALSE;
               ModemAgain =  FALSE;

            
                SendDebugMsg("\r\n * Server Communication Ended Succesfully..*\r\n\0 ");   //Danny for debug
//              SendDebugMsg("\r\n String lengh: \0 ");
//              PrintNum((long)JasonLengh)
 }


void ModemForgetOldCop(void)
{
     SetAlarmTiming(3);
     SendATCmd(AT_CRSM);
     delay_ms(1000);
     SendATCmd(AT_COPS_AUTO);
      delay_ms(1000);

      modemCurTask = TASK_MODEM_INIT;
      modemCurSubTask = SUB_TASK_INIT_MODEM_DELAY;
      ModemResponse = TASK_COMPLETE;
      Modem_Message_Recieved = FALSE;
}

#endif MODEM_MANAGER_C



